---
id: 01HE5624EDM53Z0CGBBHC0R4A4
---
[[Youtube]]

# [Bobsi - Modular Systems in Unity Boost Scalability & Reusability 🚀](https://youtu.be/qfLbfPNhnj8?si=RHE5ozXOJo3amu06)

<iframe width="560" height="315" src="https://www.youtube.com/embed/qfLbfPNhnj8?si=RHE5ozXOJo3amu06" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Github Repo Files](https://github.com/BobsiUnity/Modular-weapon-showcase)