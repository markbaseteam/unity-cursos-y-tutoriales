---
created: 2023-10-09T14:39:33 (UTC -04:00)
source: https://www.youtube.com/playlist?list=PLcRSafycjWFepsLiAHxxi8D_5GGvu6arf
author: Sunny Valley Studio
id: 01HCAVV6Q3C42WYDM4CHENB5TF
---
[[Youtube]]
# [Sunny Valley Studio - Grid Placement System in Unity 2022](https://www.youtube.com/playlist?list=PLcRSafycjWFepsLiAHxxi8D_5GGvu6arf)

> ## Excerpt
> In this Unity tutorial start creating a Grid Placement System. First we will use Grid component to calculate a cell position for our mouse pointer position t...

---
<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=AJsMh5MzlBncZOzs&amp;list=PLcRSafycjWFepsLiAHxxi8D_5GGvu6arf" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


# CONTENIDOS 
1. Unity Grid Building System P1 - Calculating Cell Position
2. Showing grid on a map in Unity - Grid Placement System P2
3. Unity Placing Objects - Grid Placement System P3
4. Placement Collision Detection - Grid Placement System in Unity P4
5. Placement Preview - Grid Placement System in Unity P5
6. Refactoring To state Pattern - Grid Placement System P6
7. Removing Objects - Grid Placement System P7
