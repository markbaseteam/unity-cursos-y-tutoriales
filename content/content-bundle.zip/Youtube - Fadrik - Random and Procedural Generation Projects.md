---
id: 01HDVXHTK8TA4WTDKKPY84FS6V
---
[[Youtube]]

# [Fadrik - Random and Procedural Generation Projects](https://youtube.com/playlist?list=PL0aV5id64zH2Em_BUxVzc98F_PCUhn4Lq&si=qmMI50CvN6-3mID7)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=qmMI50CvN6-3mID7&amp;list=PL0aV5id64zH2Em_BUxVzc98F_PCUhn4Lq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
