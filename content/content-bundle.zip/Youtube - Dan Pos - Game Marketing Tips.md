---
id: 01HED7VD83NXZ9SP9X3APY2V29
---
[[Youtube]]

# [Dan Pos - Game Marketing Tips](https://youtube.com/playlist?list=PL-hj540P5Q1h2qr1OxamBfmYJaDUSiRbm&si=LhoffFUfozkqVF7j)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=LhoffFUfozkqVF7j&amp;list=PL-hj540P5Q1h2qr1OxamBfmYJaDUSiRbm" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. How To Make Your Indie Game Stand Out On Social Media | Game Marketing Tips
2. How To Make Your Indie Game Stand Out - Indie Game Marketing Tips
3. TikTok For Indie Devs - How Many Wishlist's Did Our Indie Game Get After Going Viral?
4. Commercial Indie Dev? Don't Fall For This Key Scam!
