---
id: 01HEDSGKFWA2JHH0E60VG9CG2X
---
[[Youtube]]

# [Sunny Valley Studio - Csharp for Unity](https://youtube.com/playlist?list=PLcRSafycjWFcj9Eh3TRwCz7GlLFXSO4YB&si=zyy8EHYvSawBmpJx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=zyy8EHYvSawBmpJx&amp;list=PLcRSafycjWFcj9Eh3TRwCz7GlLFXSO4YB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

