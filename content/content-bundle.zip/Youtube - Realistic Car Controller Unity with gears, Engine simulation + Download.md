---
id: 01HE4QEHR3BB23W3KJZPP6F3KR
---
[[Youtube]]

# [Nanousis Development - Realistic Car Controller Unity with gears, Engine simulation + Download](https://youtube.com/playlist?list=PL0JXhw1odpJLTRBDdv4ybtYkuD1lEcF-N&si=ixlacsJb4DQ-ON9L)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ixlacsJb4DQ-ON9L&amp;list=PL0JXhw1odpJLTRBDdv4ybtYkuD1lEcF-N" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Github Repo Files](https://github.com/Nanousis/NanousisCarController)

## CONTENIDOS
1. How to: Car Controller Unity + Camera + Github link
2. Create mobile UI Buttons for ANY Controller Unity! + Github link
3. Car controller tutorial #2: Car Engine Audio(realistic) in Unity + GitHub link
4. Realistic Car Controller Unity with gears, Engine simulation + Download
5. Unity Car controller: Tire mark trails and brake lights + Download
6. Making a Drift Game, Drifting Score, Github
7. How to use the New Input System 2.0 in Unity
8. Parts Manager / Car Customization in Unity + Free Download
