---
id: 01HFFJM3W113J8W7C7SXSG7WS0
---
[[Youtube]]

# [Coding With Unity - Level Up System](https://youtube.com/playlist?list=PLJWSdH2kAe_J5uhoBdzQdbulPkvLLqpfK&si=vJuC7ybc70EccObL)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=vJuC7ybc70EccObL&amp;list=PLJWSdH2kAe_J5uhoBdzQdbulPkvLLqpfK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
