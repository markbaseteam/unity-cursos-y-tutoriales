---
id: 01HEC0XF046WVKC9ABRHDK0ZYJ
---
[[Youtube]]

# [Sasquatch B Studios - A Better Way to Code Your Characters in Unity | Finite State Machine | Tutorial](https://www.youtube.com/watch?v=RQd44qSaqww)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/RQd44qSaqww" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
