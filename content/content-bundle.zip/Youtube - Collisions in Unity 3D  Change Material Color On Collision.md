---
id: 01HE6NQNS3MCRB4GD40PA5VWP0
---
[[Youtube]]

# [Kapil Singh - Collisions in Unity 3D || Change Material Color On Collision](https://www.youtube.com/watch?v=cHr16zZS7Ys&pp=ygUfcnVudGltZSBjaGFuZ2UgcGh5c2ljcyBtYXRlcmlhbA%3D%3D)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/cHr16zZS7Ys" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
