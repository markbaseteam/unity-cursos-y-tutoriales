---
id: 01HB1RZB1BJXZ8J7XGKYEP0FK5
---
# [Code Monkey C# Basics to Advanced](https://youtube.com/playlist?list=PLzDRvYVwl53t2GGC4rV_AmH7vSvSqjVmz&si=iRjs_sFPfvtdPzYk)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=iRjs_sFPfvtdPzYk&amp;list=PLzDRvYVwl53t2GGC4rV_AmH7vSvSqjVmz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
