---
id: 01HFQC32MCK0FF9YXJKMSCSWC0
---
[[Youtube]]

# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 1 | Project Set Up](https://www.youtube.com/watch?v=V1kNrsdVqWs&t=8s)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/V1kNrsdVqWs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 2 | Manually Adding Players to Game](https://www.youtube.com/watch?v=G5PCPdNPS70)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/G5PCPdNPS70" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 3 | Removing Players from Game](https://www.youtube.com/watch?v=7iLqWipmcWg)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/7iLqWipmcWg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 4 | Implementing A Gameplay Loop](https://www.youtube.com/watch?v=XWbBoQCMqhI)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/XWbBoQCMqhI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 5 | Adding a Responsive HUD](https://www.youtube.com/watch?v=hRWIr-2eg-A)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/hRWIr-2eg-A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 6 | Creating a Dynamic Camera](https://www.youtube.com/watch?v=jakqb3fx83Q)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/jakqb3fx83Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Dan Pos - Make a Local Multiplayer Game in Unity 2021 | Part 7 | Making a Smarter Spawner](https://www.youtube.com/watch?v=5Gz4f9yuUdU)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/5Gz4f9yuUdU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
