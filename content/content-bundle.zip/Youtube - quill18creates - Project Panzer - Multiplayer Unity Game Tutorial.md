---
id: 01HEDT4AHKPQJ2NJGP18K23JHN
---
[[Youtube]]

# [quill18creates - Project Panzer - Multiplayer Unity Game Tutorial](https://youtube.com/playlist?list=PLbghT7MmckI4x0t04ZfVdk7zLJsNTzFIX&si=PoachCsP_JirBLg3)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=PoachCsP_JirBLg3&amp;list=PLbghT7MmckI4x0t04ZfVdk7zLJsNTzFIX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS

