---
id: 01HE7N3HGERBT6RC4F4DTTRRG3
---
[[Youtube]]

# [Flaroon - Generating Procedural Biomes in Unity](https://www.youtube.com/watch?v=aZyrimErjJ0&pp=ygUMYmlvbWVzIHVuaXR5)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/aZyrimErjJ0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
