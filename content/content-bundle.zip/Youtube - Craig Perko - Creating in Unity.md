---
id: 01HDMC6GDJD0VK0V0H4RGQXFRR
---
[[Youtube]]

# [Craig Perko - Creating in Unity](https://youtube.com/playlist?list=PLW2i42bgplOn15dwBuPoEjeFsqyFQZx-c&si=9MUE3GKACUH-sSBY)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9MUE3GKACUH-sSBY&amp;list=PLW2i42bgplOn15dwBuPoEjeFsqyFQZx-c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
