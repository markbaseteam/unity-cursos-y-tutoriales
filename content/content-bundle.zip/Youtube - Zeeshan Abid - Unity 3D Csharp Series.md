---
id: 01HEBHBRHVW9BS3H6XD7BQKWMY
---
[[Youtube]]

# [Zeeshan Abid - Unity 3D Csharp Series](https://youtube.com/playlist?list=PLwHcBesW02n2KAyOVPmyFpmwu4xwRU5Pm&si=bm2Aeq7xCsB1IlOF)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=bm2Aeq7xCsB1IlOF&amp;list=PLwHcBesW02n2KAyOVPmyFpmwu4xwRU5Pm" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Special Unity 3D Tutorials](https://youtube.com/playlist?list=PL514AC9D1DEB285F8&si=pbhz6vatqyVOZUzs)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=pbhz6vatqyVOZUzs&amp;list=PL514AC9D1DEB285F8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

