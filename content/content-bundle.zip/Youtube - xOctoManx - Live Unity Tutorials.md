---
id: 01HECS67189XFG3FNT514JF37H
---
[[Youtube]]

# [xOctoManx - Live Unity Tutorials](https://youtube.com/playlist?list=PLj0TSSTwoqAziJuuUEj-w9Zwj0sDMadC-&si=DZZcOYonS3UoxxDl)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=DZZcOYonS3UoxxDl&amp;list=PLj0TSSTwoqAziJuuUEj-w9Zwj0sDMadC-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Unity Tutorial: Procedural Fish Like Animations | OctoMan
2. Unity Tutorial: Collision Detection | OctoMan
3. Unity Tutorial: Planning a Project | OctoMan
4. Unity Tutorial: Casual Games - Plants Vs Zombies | OctoMan
5. Unity Tutorial: Simple Casual Kids Games - Shoot Something? | OctoMan
6. Unity Tutorial: Chu Chu Rocket Like Puzzle Games| OctoMan
7. Unity Tutorial: Endless Runner Game - Unlimited Ski | OctoMan
8. Unity Tutorial: Endless Runner Game - Unlimited Ski #2 | OctoMan
9. Unity Tutorial: Delivery Games - Pizza Driver | OctoMan
10. Unity Tutorial: 2D Point and Click Drawers with Smooth Animations | OctoMan
