---
id: 01HE52M4GQJQAEA1VZFGCM0K0V
---
[[Youtube]]

# [Dapper Dino - Writing Shaders In Unity](https://youtube.com/playlist?list=PLS6sInD7ThM3giqACaYCBtIhkMNucqmna&si=BX8YIuFNVuj3QvVE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BX8YIuFNVuj3QvVE&amp;list=PLS6sInD7ThM3giqACaYCBtIhkMNucqmna" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
