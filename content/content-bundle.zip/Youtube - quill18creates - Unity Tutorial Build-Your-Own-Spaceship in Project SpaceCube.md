---
id: 01HE0QB3WFVAAQMXSJ5CG0CV3Y
---
[[Youtube]]

# [quill18creates - Unity Tutorial: Build-Your-Own-Spaceship in Project SpaceCube](https://youtube.com/playlist?list=PLbghT7MmckI7bOsluDRYoAyzf9R7NwILD&si=LFaEwBRRc2oSFjsQ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=LFaEwBRRc2oSFjsQ&amp;list=PLbghT7MmckI7bOsluDRYoAyzf9R7NwILD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
