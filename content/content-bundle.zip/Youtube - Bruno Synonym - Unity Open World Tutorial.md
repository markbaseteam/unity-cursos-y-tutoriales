---
id: 01HCMP2MX6BPV294A5SWNZ85D4
---
[[Youtube]]

# [Bruno Synonym - Unity Open World Tutorial](https://youtube.com/playlist?list=PLcgPQKP6JpS2ISZPYeh0NNpty_gAjOQjB&si=u9hW7Ib7gXeP19Ii)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=u9hW7Ib7gXeP19Ii&amp;list=PLcgPQKP6JpS2ISZPYeh0NNpty_gAjOQjB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
Unity Open World #1 - Getting Started
Unity Open World #2 - Ground
Unity Open World #3 - Third Person Character
Unity Open World #4 - Importing Mixamo Characters
Unity Open World #5 - Third Person Camera Setup
Unity Open World #6 - Limit Camera Rotation
Unity Open World #7 - Basic Character Movement
Unity Open World #8 - Camera Relative Movement Input
Unity Open World #9 - Animation Controller
Unity Open World #10 - Animation Blend Tree
Unity Open World #11 - Animation Controller Script
Unity Open World #12 - Animation Controller Script
Unity Open World #13 - Character Rigidbody
Unity Open World #14 - Toggle Run
Unity Open World #15 - Smooth Speed Transition
Unity Open World #16 - Smooth Speed Transition
Unity Open World #17 - Smooth Rotation Towards Movement Direction
Unity Open World #18 - Toggle Crouch
Unity Open World #19 - Toggle Sprint
Unity Open World #20 - Sync Walk Animation & Movement Speed
Unity Open World #21 - Sync Run Animation & Movement Speed
Unity Open World #22 - Sync Walk Start & Stop Animations
Unity Open World #23 - Footstep Sounds Event
Unity Open World #24 - Remove Duplicate Footstep Sounds Event With Blendtrees
Unity Open World #25 - Sync Crouch Blendtree with Speed
Unity Open World #26 - Dynamic Footstep sounds based on movement speed
