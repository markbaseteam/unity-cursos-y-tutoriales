---
id: 01HECHW21GEKA2J1WEBQFTV8A9
---
[[Youtube]]

# [LlamAcademy - AI Tutorial Series in Unity - NavMeshes, NavMeshAgents, and Configuring Enemies](https://youtube.com/playlist?list=PLllNmP7eq6TSkwDN8OO0E8S6CWybSE_xC&si=-YuqherPtW-hiPsV)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=-YuqherPtW-hiPsV&amp;list=PLllNmP7eq6TSkwDN8OO0E8S6CWybSE_xC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDOS 
1. Enemy Behavior Tree AI FULL IMPLEMENTATION (AI Tree) | AI Series Part 48 | Unity Tutorial
2. Enemy State Machine AI FULL IMPLEMENTATION | AI Series 47 | Unity Tutorial
3. Which AI Behavior Framework Should You Use? | AI Series 46
4. Visualize a NavMesh, In Game! | AI Series 45 | Unity Tutorial
5. Better Enemy Chasing with Intercept Courses | AI Series 44 | Unity Tutorial
6. Find when a NavMeshLink will be Taken | AI Series 43 | Unity Tutorial
7. Root Motion NavMeshAgent Animation | AI Series Part 42 | Unity Tutorial
8. Hit Moving Targets with Projectiles | AI Series Part 41 | Unity Tutorial
9. Jobs System Line of Sight Checking | AI Series Part 40 | Unity Tutorial
10. Ragdoll on Death NavMeshAgents | AI Series Part 39 | Unity Tutorial
11. NavMeshAgent Avoidance in Depth - 5 Key Takeaways for Optimal Avoidance | AI Series Part 32
12. How to Show a Path to a Target | AI Series Part 31 | Unity Tutorial
13. Moving AND Rotating NavMesh Platforms | AI Series Part 30 | Unity Tutorial
14. Hiding AI - Take Cover Behind World Geometry | AI Series Part 29 | Unity Tutorial
15. Moving NavMesh Platforms! YES You CAN! AI Series Part 28 | Unity Tutorial
16. Surround AI - Circle a Target | AI Series Part 27 | Unity Tutorial
17. RTS-Style Drag Select, Click to Select/Deselect, and Movement | AI Series Part 26 | Unity Tutorial
18. NavMeshModifier and NavMeshModifierVolume In Depth | AI Series Part 25 | Unity Tutorial
19. Enemy Skills by Example - AoE Poison Gas Skill | AI Series Part 24 | Unity Tutorial
20. Enemy Skills by Example - Instant-Cast Ice Lance | AI Series Part 23 | Unity Tutorial
21. Enemy Skills by Example - Channeled Fire Breath | AI Series Part 22 | Unity Tutorial
22. Enemy Skills by Example - Jump Attack | AI Series Part 21 | Unity Tutorial
23. Weighted Random Enemy Spawning | AI Series Part 20 | Unity Tutorial
24. Round Spawning and Scaling Up Enemies | AI Series Part 19 | Unity Tutorial
25. Burst Spawn Enemies at a Location | AI Series Part 18 | Unity Tutorial
26. 99.94% CPU Time Reduction on Runtime NavMesh Generation | AI Series Part 14.5 | Unity Tutorial
27. NavMeshLink Traversal by Area Type | AI Series Part 17 | Unity Tutorial
28. Connect NavMeshes on Additively Loaded Scenes | AI Series Part 16 | Unity Tutorial
29. Spawn and Manage Enemies on a Procedural NavMesh | AI Series Part 15 | Unity Tutorial
30. Bake a NavMesh Area Around the Player - Runtime Baking Part 2 | AI Series Part 14 | Unity Tutorial
31. Procedural Level and NavMesh Generation | AI Series Part 13 | Unity Tutorial
32. Shortest Path Considering Obstacles | AI Series Part 12
33. How to Make a State Machine for Enemy AI | AI Series Part 11 | Unity Tutorial
34. Flying NavMeshAgents! | AI Series Part 10 | Unity Tutorial
35. ScriptableObject-based Attack Configurations | AI Series Part 9 | Unity Tutorial
36. How to Make Homing Projectile-shooting AI | AI Series Part 8 | Unity Tutorial
37. How to Make a Ranged Attacking Enemy | AI Series Part 7 | Unity Tutorial
38. Make NavMeshAgents Attack Nearby Targets | AI Series Part 6 | Unity Tutorial
39. ScriptableObject-based Enemy Types | AI Series Part 5 | Unity Tutorial
40. Spawn and Place NavMeshAgents on a NavMesh at Runtime | AI Series Part 4 | Unity Tutorial
41. Sync Animator and NavMeshAgent States | AI Series Part 3 | Unity Tutorial
42. NavMeshLink in Unity - Adding Jumping to NavMeshAgents | AI Series Part 2 | Unity Tutorial
43. NavMesh Basics - Introduction to the NavMeshSurface | AI Series Part 1 | Unity Tutorial
