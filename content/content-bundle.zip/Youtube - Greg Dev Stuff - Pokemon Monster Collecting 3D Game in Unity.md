---
id: 01HE0TYCTW7JAK1VMJA4P38RK8
---
[[Youtube]]

# [Greg Dev Stuff - Pokemon Monster Collecting 3D Game in Unity Tutorial](https://youtube.com/playlist?list=PL0GUZtUkX6t7V7I3tKixJUoz7GCuNVtjC&si=2KNbcT6tknng81DH)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=2KNbcT6tknng81DH&amp;list=PL0GUZtUkX6t7V7I3tKixJUoz7GCuNVtjC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
