---
id: 01HDSHN5HF0KH8S704RTKWJA1F
---
[[Youtube]]

# [Code Monkey - Learn Unity Beginner/Intermediate 2023 (FREE COMPLETE Course - Unity Tutorial)](https://www.youtube.com/watch?v=AmGSEH7QcDg&t=26s&pp=ygUSaW4gZ2FtZSBoZWxwIHVuaXR5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/AmGSEH7QcDg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
