---
id: 01HDH9EQBQ8G6G0SF1E002VXHN
---
[[Youtube]]

# [Profe TIC - Curso de Unity Completo](https://youtube.com/playlist?list=PLNFqyZnKIlCLIJCLnqRnbXroq0X_qCY6x&si=vPTYmqs5O9BBXpju)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=vPTYmqs5O9BBXpju&amp;list=PLNFqyZnKIlCLIJCLnqRnbXroq0X_qCY6x" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
