---
id: 01HFQA4YEF59B3QVRH0GVV1YVJ
---
[[Youtube]]

# [Marc Teyssier - Connect Arduino to Unity](https://youtube.com/playlist?list=PLt-5n3K_vUZeiJ1U5RBgEIBroh8imzu1E&si=VAXLDOWtw2sIH38w)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=VAXLDOWtw2sIH38w&amp;list=PLt-5n3K_vUZeiJ1U5RBgEIBroh8imzu1E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Connect Arduino to Unity in less than 1 minute - Uduino
2. Fade an LED from Unity to Arduino - Uduino Video Tutorial
3. Read a digital button from Arduino to Unity - Uduino Tutorial
4. Blink an LED from Unity to Arduino - Uduino Video Tutorial
5. Read an analog Input from Arduino to Unity - Uduino Video Tutorial
6. Use a IMU Gyroscope in Unity (6DOF MPU-6050) - Video Tutorial using Uduino
7. Extend an existing Library - Using an Encoder in Unity - Uduino tutorial
8. Control a Servo from Unity - Easy Uduino Tutorial
9. Control RGB LED strip (Neopixel) from Unity - Extend an existing Library - Uduino tutorial
10. Easy Unity Arduino WiFi connection - Uduino Wifi Plugin Tutorial
