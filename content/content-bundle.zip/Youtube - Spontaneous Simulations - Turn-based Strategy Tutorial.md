---
id: 01HECR8NTKVC50X9Y1ES49F0Z6
---
[[Youtube]]

# [Spontaneous Simulations - Turn-based Strategy Tutorial](https://youtube.com/playlist?list=PLHz55xdsTaf5KHOAxJ41aNcq1zjdECdo8&si=psYbZ444Mp3L5K4x)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=psYbZ444Mp3L5K4x&amp;list=PLHz55xdsTaf5KHOAxJ41aNcq1zjdECdo8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. How I design and prepare for new gaming projects.Follow these steps before starting big game project
2. Create custom tiles with preview thumbnails in Unity. Turn-base Strategy Tutorial pt1
3. A trick to fix incorrectly sorted overlapping tiles in Unity
4. Draw Seamless Roads at Runtime with Custom Road Tile in Unity - Turn-based strategy tutorial - pt2
5. One pathfinder to solve them all!Code pathfinding for grid or node based movements (Tilemap example)
6. Create your custom Tech Tree or Skill Tree editor inside inspector using Unity - Strategy Tutorials
7. Create Scriptableobjects in Batches - Mass Scriptableobject creation from sprites - Tutorial
8. Pathfinding with connected regiments- Imperial Ambitions Progress Vid01
9. How to plan out your game project using Class Diagram - Turn based strategy example - Unity Tutorial
10. Move Units on Command on Unity Tilemaps - turn-based strategy tutorial continued
11. Command Design Pattern For Turn-Based Strategy Games - Unity tutorial
12. Devvlog Imperial Ambitions
13. Create a windows UI system inside Unity - Unity tutorial
14. devlog 4: Diplomacy in Imperial Ambitions
15. Automated Generation Of UI Elements For ScriptableObjects - Unity tip
