---
id: 01HE724JJ6T983NGBQ15V5DK4C
---
[[Youtube]]

# [Unity - Packaging content with Addressable Assets | Open Projects Devlog](https://www.youtube.com/watch?v=XIHINtB2e1U)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/XIHINtB2e1U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
