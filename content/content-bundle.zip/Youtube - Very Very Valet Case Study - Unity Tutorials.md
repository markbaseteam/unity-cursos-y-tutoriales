---
id: 01HAWPVRMYQGYYJANYDQE8V6F0
---
[[Youtube]]

# [Very Very Valet](https://www.youtube.com/playlist?list=PL4BRBnD7vQtYa3xTD2uYviotFM17JPqM-)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PL4BRBnD7vQtYa3xTD2uYviotFM17JPqM-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
