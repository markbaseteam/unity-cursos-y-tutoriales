---
id: 01HECRHZFNVJKA3Q5YSCH5EE2A
---
[[Youtube]]

# [Greg Dev Stuff - Tactics RPG in Unity Episode 8 Map Highlight](https://youtube.com/playlist?list=PL0GUZtUkX6t4JrdjOoAF2ayH-ksVtgpqy&si=sxGuvJ6IuvR-z1ro)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=sxGuvJ6IuvR-z1ro&amp;list=PL0GUZtUkX6t4JrdjOoAF2ayH-ksVtgpqy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
