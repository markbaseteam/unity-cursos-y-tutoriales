---
id: 01HEBX6QMZD31MVY809KDDNMAT
---
[[Youtube]]

# [Immersive Limit - ClosestPoint and ContactPoint Collision in Unity](https://www.youtube.com/watch?v=ms6r59X6rRc)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/ms6r59X6rRc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
