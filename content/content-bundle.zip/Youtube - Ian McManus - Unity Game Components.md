---
id: 01HCG457FXC7R1FZ2NAS0HS7JD
---
[[Youtube]]

# [Ian McManus - Unity Game Components](https://youtube.com/playlist?list=PLkBiJgxNbuOV0uTyi-X369vIZJiphyTsH&si=uk0adw3ufe92WABJ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=uk0adw3ufe92WABJ&amp;list=PLkBiJgxNbuOV0uTyi-X369vIZJiphyTsH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
