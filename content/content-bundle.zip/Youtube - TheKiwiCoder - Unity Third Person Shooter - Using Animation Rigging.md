---
id: 01HE53FT4TZ0AE69MQVPPQ5DMF
---
[[Youtube]]

# [TheKiwiCoder - Unity Third Person Shooter - Using Animation Rigging](https://youtube.com/playlist?list=PLyBYG1JGBcd1E4CigRSDE9YdH8syiDY6-&si=A3XtCc3sjGCtRlyC)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=A3XtCc3sjGCtRlyC&amp;list=PLyBYG1JGBcd1E4CigRSDE9YdH8syiDY6-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
