---
id: 01HD7VRAR9SH2YQSHSWMKRPYFX
---
[[Youtube]]

# [BMo - Rethink Everything with Scriptable Object VARIABLES](https://www.youtube.com/watch?v=VFOGGml_N6g)

<iframe width="560" height="315" src="https://www.youtube.com/embed/VFOGGml_N6g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
