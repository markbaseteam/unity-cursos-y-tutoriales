---
id: 01HEC7P78X38FH52GAWFADD6E9
---
[[Youtube]]

# [Dev Enabled - Augmented Reality Playlist](https://youtube.com/playlist?list=PL9z3tc0RL6Z4WenhJiJieCcrPVNxYszod&si=BIczp4KdBr7k6EGj)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BIczp4KdBr7k6EGj&amp;list=PL9z3tc0RL6Z4WenhJiJieCcrPVNxYszod" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Augmented Reality Playlist Intro - Unity Augmented Reality/AR
2. Packaging and Testing ARFoundation Examples - Unity Augmented Reality/AR
3. AR Foundation Plane Tracking - Unity Augmented Reality/AR
4. AR Foundation Object Placement - Unity Augmented Reality/AR
5. AR Foundation Multiple Object Placement - Unity Augmented Reality/AR
6. AR Foundation Plane Tracking - Hiding Tracked Planes - Unity Augmented Reality/AR
7. AR Foundation Image Tracking - Unity Augmented Reality/AR
8. AR Foundation Improved Image Tracking - Multiple Objects/Images - Unity Augmented Reality/AR
9. Vuforia Image Tracking - Intro to Vuforia - Unity Augmented Reality/AR
10. Vuforia Image Tracking - Custom Image Database - Unity Augmented Reality/AR
