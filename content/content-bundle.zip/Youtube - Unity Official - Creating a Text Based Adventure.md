---
id: 01HDSK55ZQ5RTXHZRZMXEE2FMP
---
[[Youtube]]

# [Unity - Creating a Text Based Adventure](https://youtube.com/playlist?list=PLX2vGYjWbI0RfcpqpKlmLEy7NteIog8g4&si=FoRHemWWHgarcWT3)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=FoRHemWWHgarcWT3&amp;list=PLX2vGYjWbI0RfcpqpKlmLEy7NteIog8g4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Creating a Text Based Adventure - Introduction and Goals [1/8] Live 2017/3/22
- Creating a Text Based Adventure - Project Architecture Overview [2/8] Live 2017/3/22
- Creating a Text Based Adventure - Creating Rooms [3/8] Live 2017/3/22
- Creating a Text Based Adventure - Creating Exits [4/8] Live 2017/3/22
- Creating a Text Based Adventure - Text Input [5/8] Live 2017/3/22
- Creating a Text Based Adventure - Reacting To String Input [6/8] Live 2017/3/22
- Creating a Text Based Adventure - Input Actions And The Delegate Pattern [7/8] Live 2017/3/22
- Creating a Text Based Adventure - Questions and Answers [8/8] Live 2017/3/22
- Creating a Text Based Adventure Part 2 - Introduction and Goals [1/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Project Architecture and Review [2/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Displaying Item Descriptions [3/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Examining Items [4/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Taking Items [5/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Displaying Inventory [6/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Action Responses [7/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Preparing The Use Item Dictionary [8/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Creating The Use Action [9/10] Live 2017/3/29
- Creating a Text Based Adventure Part 2 - Displaying Inventory [10/10] Live 2017/3/29
