---
id: 01HECRN1RDPDZ89W4A9D8CJJ20
---
[[Youtube]]

# [Spontaneous Simulations - Water in Unity](https://youtube.com/playlist?list=PLHz55xdsTaf6aI6OcU6PWJ8JOSqOHXoTq&si=p7bQ8AMEIibjBD1Q)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=p7bQ8AMEIibjBD1Q&amp;list=PLHz55xdsTaf6aI6OcU6PWJ8JOSqOHXoTq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Can you simulate waves in Unity? Create realistic water effects using wave equation - Unity Tutorial
2. Use compute shaders to create water effect in Unity. Now you can simulate ripples of a moving boat!
3. Add buoyancy with Archimedes principle and simulate boats heaving over water - Unity tutorial
