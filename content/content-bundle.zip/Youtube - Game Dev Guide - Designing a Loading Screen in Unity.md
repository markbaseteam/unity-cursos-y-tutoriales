---
id: 01HEBJ36J0YA7K97BXTPACDASC
---
[[Youtube]]

# [Game Dev Guide - Designing a Loading Screen in Unity](https://www.youtube.com/watch?v=iXWFTgFNRdM)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/iXWFTgFNRdM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
