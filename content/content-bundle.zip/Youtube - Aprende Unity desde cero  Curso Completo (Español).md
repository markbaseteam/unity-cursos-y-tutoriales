---
id: 01HAWPVRW5BZTW4FD73DR8EP76
---
[[Youtube]]

# [Aprende Unity desde cero | Curso Completo (Español)](https://www.youtube.com/playlist?list=PL6dM-wegAFwiKysmU6xJuNO4MV6-dNO-f)


<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PL6dM-wegAFwiKysmU6xJuNO4MV6-dNO-f" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDO 
1. Aprende Unity desde cero | Curso Completo (Español)
2. ¿Qué es Unity y cómo instalarlo? | Curso de Unity [01]
3. Estructura y Configuración de un Proyecto en Unity | Curso de Unity [02]
4. ¿Cómo usar la Interface y ventanas de Unity? | Curso de Unity [03]
5. ¿Cómo navegar en una Escena de Unity? | Curso de Unity [04]
6. ¿Qué son los Assets en Unity y dónde conseguirlos? | Curso de Unity [05]
7. ¿Qué son los Packages en Unity y cómo instalarlos? | Curso de Unity [06]
8. ¿Cómo utilizar los Tags y Layers en Unity? | Curso de Unity [07]
9. ¿Cómo usar Cámaras en Unity? | Curso de Unity [08]
10. ¿Cómo iluminar una escena en Unity? | Curso de Unity [09]
11. ¿Cómo agregar Materiales en Unity? | Curso de Unity [10]
12. ¿Cómo trabajar con Audio o SFX? | Curso de Unity [11]
13. ¿Cómo hacer animaciones en Unity? | Curso de Unity [12]
14. ¿Cómo trabajar con Físicas? Colliders y Rigidbody | Curso de Unity [13]
15. ¿Qué son los Prefabs en Unity y como utilizarlos? | Curso de Unity [14]
16. ¿Cómo utilizar el Input en Unity? | Curso de Unity [15]
17. ¿Cómo crear una UI en Unity? | Curso de Unity [16]
18. Fundamentos de Programación en Unity C# | Curso de Unity [17]
19. ¿Cómo compilar un proyecto en Unity? Build | Curso de Unity [18]
