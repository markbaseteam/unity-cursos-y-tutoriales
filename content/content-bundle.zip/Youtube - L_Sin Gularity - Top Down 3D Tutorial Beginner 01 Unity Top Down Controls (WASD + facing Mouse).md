---
id: 01HDW691W3SDXSY41ZQ0DPGM5M
---
[[Youtube]]

# [L_Sin Gularity - Unity Top Down Controls (WASD + facing Mouse) Top Down 3D Tutorial Beginner 01](https://www.youtube.com/watch?v=QIaek6rlfBY)

<iframe width="560" height="315" src="https://www.youtube.com/embed/QIaek6rlfBY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>



