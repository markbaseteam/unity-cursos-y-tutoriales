---
id: 01HED0TXKBTNF7JBA316EDP5RF
---
[[Youtube]]

# [samyam - Unity Multiplayer - Netcode for GameObjects](https://youtube.com/playlist?list=PLKUARkaoYQT0tXlb37mY0eiLm9luEhxQJ&si=p9AgR6NeKOTHv3L_)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=p9AgR6NeKOTHv3L_&amp;list=PLKUARkaoYQT0tXlb37mY0eiLm9luEhxQJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
