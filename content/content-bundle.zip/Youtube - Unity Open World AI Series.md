---
id: 01HDZZHB76RKB02E9C0F5FM04G
---
[[Youtube]]

# [EngiGames - Unity Open World AI Series](https://youtube.com/playlist?list=PLetFbUN1HtXSF9V7c4IChH-I8BuPEotNu&si=ZzvbgYKfrfm3zCf1)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ZzvbgYKfrfm3zCf1&amp;list=PLetFbUN1HtXSF9V7c4IChH-I8BuPEotNu" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## REQUERIMIENTOS

- [Project Files](https://bitbucket.org/EngiGamesBitbucket/engigames_aiproject/src/master/)
- [XNode Github Repo](https://github.com/Siccity/xNode)
- [XNode Documentation](https://github.com/Siccity/xNode/wiki)

## CONTENIDOS
- Behaviour Tree Implementation
- Behaviour Tree Implementation Part 2
- Weapon Collisions
- Sensory System
- Stim Events
- Smart Terrain Points (Waypoint System)
- Smart Terrain Points (Waypoint System)
- Introduction to Emergent Behaviours - Unity
