---
id: 01HDPJ48495QWTWHSB3TCFZW6K
---
[[Youtube]]

# [Ludibyte Games - Aprende Unity desde cero | Curso Completo (Español)](https://youtube.com/playlist?list=PL6dM-wegAFwiKysmU6xJuNO4MV6-dNO-f&si=5bzLOlrBnR-FYV-z)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=5bzLOlrBnR-FYV-z&amp;list=PL6dM-wegAFwiKysmU6xJuNO4MV6-dNO-f" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
