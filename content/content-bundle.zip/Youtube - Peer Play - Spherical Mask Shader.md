---
id: 01HE7FZH3CBP0NZWP0PDD5Y78C
---
[[Youtube]]

# [Peer Play - Spherical Mask Shader](https://youtube.com/playlist?list=PL3POsQzaCw52iu1_P6CnM7oTctPuPu2MV&si=YxySc0SGSOnUBGkF)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=YxySc0SGSOnUBGkF&amp;list=PL3POsQzaCw52iu1_P6CnM7oTctPuPu2MV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Spherical Mask Shader - Unity CG/C# Tutorial [Part 1 - Shader Theory]
2. Spherical Mask Shader - Unity CG/C# Tutorial [Part 2 - Writing Shader]
3. Spherical Mask Shader - Unity CG/C# Tutorial [Part 3 - Add Emission]
4. pherical Mask Shader - Unity CG/C# Tutorial [Part 4 - Update Position]
