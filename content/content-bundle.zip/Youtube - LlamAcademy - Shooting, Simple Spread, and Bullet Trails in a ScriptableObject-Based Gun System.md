---
id: 01HECJ0GJ4M4F0KXY80WH4YPG6
---
[[Youtube]]

# [Youtube - LlamAcademy - Shooting, Simple Spread, and Bullet Trails in a ScriptableObject-Based Gun System](https://youtube.com/playlist?list=PLllNmP7eq6TQJjgKJ6FKcNFfRREe_L6to&si=f5IWlZyFTvjYyzgq)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=f5IWlZyFTvjYyzgq&amp;list=PLllNmP7eq6TQJjgKJ6FKcNFfRREe_L6to" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
1. Shooting, Simple Spread, and Bullet Trails in a ScriptableObject-Based Gun System | Unity Tutorial
2. Procedural Recoil and Bullet Spread | Gun Series 2 | Unity Tutorial
3. Damage Enemies and Objects with Guns | Gun Series 3 | Unity Tutorial
4. Animation-driven Reloading | Gun Series 4 | Unity Tutorial
5. Gun Sound Effects with an Audio Config ScriptableObject | Gun Series 5 | Unity Tutorial
6. Projectile Guns | Scriptable Object Gun Series 6 | Unity Tutorial
7. Accurate Aiming Options Discussed & Implemented | Gun Series 7 | Unity Tutorial
8. Dynamic Modifier System for Guns to Support Attachments | Gun Series 8 | Unity Tutorial
9. Explosive and Frost Round Configurations | Gun Series 9 | Unity Tutorial
10. Gun Attachment System | Gun Series 10 | Unity Tutorial
11. Runtime Gun Swapping | ScriptableObject-based Gun Series Part 11 | Unity Tutorial
12. Aiming with Inverse Kinematics (IK) and Animation Rigging | Gun Series 12 | Unity Tutorial
13. Bullet Penetration with Raycasts and Rigidbodies | Gun Series Part 13 | Unity Tutorial
14. Save and Load a Player Loadout | Gun Series Part 14 | Unity Tutorial
