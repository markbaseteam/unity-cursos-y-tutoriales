---
id: 01HED80JBVN621GS9C926J82Z8
---
[[Youtube]]

# [Dan Pos - Unity Tutorial - Unity Sci Fi Game](https://youtube.com/playlist?list=PL-hj540P5Q1hPXuhIV0uUAsSNsBop4449&si=KYxiRbL85cXLCylq)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=3q-Pk1KGwXy5xUTv&amp;list=PL-hj540P5Q1hPXuhIV0uUAsSNsBop4449" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Unity Tutorial - Spaceship Movement With Cinemachine & New Input System - Space Sim Series Ep 1
2. Unity Zero Gravity Movement Tutorial - FPS Rigidbody Movement - Sci Fi Game Series Ep 2
3. Unity Enter Spaceship / Vehicle Tutorial - Cinemachine Camera Switching - Sci Fi Game Series Ep 3
4. Unity Spaceship Lasers (Asteroid Mining Pt.1) - Sci Fi Game Series Ep 4
5. Unity Asteroid Spawning & Mining (Asteroid Mining Pt.2) - Sci Fi Game Series Ep 5
