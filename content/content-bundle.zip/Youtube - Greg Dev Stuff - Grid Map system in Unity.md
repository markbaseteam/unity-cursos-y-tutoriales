---
id: 01HE7J4W8ADWSBJQSXEPMB96AQ
---
[[Youtube]]

# [Greg Dev Stuff - Grid Map system in Unity](https://youtube.com/playlist?list=PL0GUZtUkX6t5m8nEcYtWsc5s1f7WRD265&si=TJRxjTZRI4XnEPGn)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=TJRxjTZRI4XnEPGn&amp;list=PL0GUZtUkX6t5m8nEcYtWsc5s1f7WRD265" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Grid Map system in Unity Episode 1 Tilemap setup
2. Grid Map system in Unity Episode 2 Tileset
3. Grid Map system in Unity Episode 3 Pathfinding
4. Grid Map system in Unity Episode 4 RuleTile and using Rule Tiles for Gridmap
5. Grid Map system in Unity Episode 5 How to save and load your tilemap at runtime and in the editor
6. Grid Map system in Unity Episode 6 Object on grid map
7. Grid Map system in Unity Episode 7 Character Move
8. Grid Map system in Unity Episode 8 Terrain move cost
