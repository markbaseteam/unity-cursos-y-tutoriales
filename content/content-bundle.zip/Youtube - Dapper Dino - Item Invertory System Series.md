---
id: 01HE52HD555V8STV4VRASMHSA4
---
[[Youtube]]

# [Dapper Dino - Item Invertory System Series](https://youtube.com/playlist?list=PLS6sInD7ThM2W9qpLv8VcD3gOiGJcr0lw&si=IqIhZU-uPeZO1Ld5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=IqIhZU-uPeZO1Ld5&amp;list=PLS6sInD7ThM2W9qpLv8VcD3gOiGJcr0lw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
How To Create An Item System - Part 1 - Item Data
How To Create An Item System - Part 2 - Inventory Logic
How To Create An Item System - Part 3 - Inventory UI Code
How To Create An Item System - Part 4 - Inventory UI Visuals
How To Create An Item System - Part 5 - Destroying Items
How To Create An Item System - Part 6 - Tooltip UI
How To Create An Item System - Part 7 - Hotbar Logic
How To Create An Item System - Part 8 - Hotbar UI Visuals
How To Create An Item System - Part 9 - What's Next?
