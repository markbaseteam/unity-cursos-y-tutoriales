---
id: 01HE9FDJ6AKV9DJZQZKV5N7HY4
---
[[Youtube]]

# [Chidre'sTechTutorials - Unity Essentials](https://youtube.com/playlist?list=PLdE8ESr9Th_vG4G8GpSd3RrvofCrDOuZB&si=SHBrE1S2p3EFpb46)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=SHBrE1S2p3EFpb46&amp;list=PLdE8ESr9Th_vG4G8GpSd3RrvofCrDOuZB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
