---
id: 01HE7GTC5M26EHZVGCH2KQF54Z
---
[[Youtube]]

# [Peer Play - Raymarching Shader](https://youtube.com/playlist?list=PL3POsQzaCw53iK_EhOYR39h1J9Lvg-m-g&si=nYL-Nqf2-3UmaQJG)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=nYL-Nqf2-3UmaQJG&amp;list=PL3POsQzaCw53iK_EhOYR39h1J9Lvg-m-g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
1. Raymarching Shader - Unity CG/C# Tutorial _Chapter[1] = "Shader Theory"; //PeerPlay
2. Raymarching Shader - Unity CG/C# Tutorial _Chapter[2] = "Camera Setup"; //PeerPlay
3. Raymarching Shader - Unity CG/C# Tutorial _Chapter[3] = "Sphere Tracing"; //PeerPlay
4. Raymarching Shader - Unity CG/C# Tutorial _Chapter[4] = "Lambertian Lighting"; //PeerPlay
5. Raymarching Shader - Unity CG/C# Tutorial _Chapter[5] = "Scene View Render"; //PeerPlay
6. Raymarching Shader - Unity CG/C# Tutorial _Chapter[6] = "Signed Distance Field"; //PeerPlay
7. Raymarching Shader - Unity CG/C# Tutorial _Chapter[7] = "Penumbra Shadows"; //PeerPlay
8. Raymarching Shader - Unity CG/C# Tutorial _Chapter[8] = "Ambient Occlusion"; //PeerPlay
9. Raymarching Shader - Unity CG/C# Tutorial _Chapter[9] = "Reflections"; //PeerPlay
10. Raymarching Shader - Unity CG/C# Tutorial _Chapter[10] = "Multiple Colors"; //PeerPlay
