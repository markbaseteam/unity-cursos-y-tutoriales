---
id: 01HEE5PAPJ6HR0MHBQ9C7140HD
---
[[Youtube]]

# [Rytech - How to make a Tower Defense in Unity](https://youtube.com/playlist?list=PLEvnA6UOOVbnOcpQFcW9eFCE1KQ6cdyVI&si=y6iZTLNIZW7d9zLV)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=y6iZTLNIZW7d9zLV&amp;list=PLEvnA6UOOVbnOcpQFcW9eFCE1KQ6cdyVI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Making the map
2. Making the gameloop
3. Spawning Enemies
4. Moving Enemies with the C# Job System
5. Placing Towers
6. Targeting Systems 1 (First, Close, Last)
7. Damaging Types 1 (Standard, Laser)
8. Damaging Types 2 (Flamethrower, Missile)
9. Player Economy System
