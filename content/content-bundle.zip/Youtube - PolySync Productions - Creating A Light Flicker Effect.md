---
id: 01HEA0XY9Q7CXXS96NXW0GNVGN
---
[[Youtube]]

# [PolySync Productions - Creating A Light Flicker Effect C#](https://www.youtube.com/watch?v=bzZeUI-HDq8&list=PLwxsYnXp470CyQHTsdsz43F7yUacLCd0k)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/bzZeUI-HDq8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
