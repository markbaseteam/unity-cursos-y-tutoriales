---
id: 01HECK378CA37NJYK5HCH9XBA4
---
[[Youtube]]

# [LlamAcademy - Bullet Projectile Effects and How to Implement VFX](https://youtube.com/playlist?list=PLllNmP7eq6TRy4IPYo31iGF1a5plxMJ7u&si=P55PhadCe7APROl8)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=P55PhadCe7APROl8&amp;list=PLllNmP7eq6TRy4IPYo31iGF1a5plxMJ7u" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
1. Hitscan Guns with Bullet Tracers | Raycast Shooting Unity Tutorial
2. Bouncing Bullets with Hitscan Guns | Unity Tutorial
3. Physically-Based Bullet Impact Effects | Unity Tutorial
4. Bullet Trails Using the TrailRenderer | Unity Tutorial
5. How to Make Homing Projectile-shooting AI | AI Series Part 8 | Unity Tutorial
