---
id: 01HDEACFW1189CM85VW1AWTYYM
---
[[Youtube]]

# [Sebastian Lague - Procedural Planets Generation in unity](https://youtube.com/playlist?list=PLFt_AvWsXl0cONs3T0By4puYy6GM22ko8&si=oZB6wli_fhyxRkO3)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=oZB6wli_fhyxRkO3&amp;list=PLFt_AvWsXl0cONs3T0By4puYy6GM22ko8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
