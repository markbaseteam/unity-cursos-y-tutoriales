---
id: 01HE2XMQXN7FVVJCCA01NN59YW
---
[[Youtube]]

# [Pixel Mystique Games - First Person Level Design in Unity (Tutorial Series)](https://youtube.com/playlist?list=PLs_yJ-RML1Ydr9OA5zwKnmGrBz7cXVqmM&si=Tp8SETefukbh3Ym_)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Tp8SETefukbh3Ym_&amp;list=PLs_yJ-RML1Ydr9OA5zwKnmGrBz7cXVqmM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Sketch & Layout | First Person Level Design in Unity (Part 1)
Player Controller Using Playmaker | First Person Level Design in Unity (Part 2)
Blockmesh | First Person Level Design in Unity (Part 3)
