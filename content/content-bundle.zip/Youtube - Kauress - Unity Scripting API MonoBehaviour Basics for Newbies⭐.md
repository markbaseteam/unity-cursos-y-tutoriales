---
id: 01HFQ0H1QG45TS76ZB6GAG7CZ4
---
[[Youtube]]

# [Kauress - Unity Scripting API MonoBehaviour Basics for Newbies⭐](https://youtube.com/playlist?list=PLhomwjbiyI27hnUsCSO6ai1-xOatgFppk&si=wobxH6KZRIsVOlZE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=wobxH6KZRIsVOlZE&amp;list=PLhomwjbiyI27hnUsCSO6ai1-xOatgFppk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Introduction ⭐
2. MonoBehaviour 🍩
3. Start()
4. Update() ☑️
5. FixedUpdate() ☑️
6. LateUpdate()☑️
7. LateUpdate()☑️
8. Awake() ☀️
9. OnEnable() 🕹️
10. OnDestroy() ⚔️
11. OnDisable() 🛡️
12. OnApplicationPause() 📱
13. OnApplicationFocus() 📱
14. OnApplicationQuit()📱
