---
id: 01HAWPVRVS49VKRYZJTA72ZNC7
---
[[Youtube]]

# [Beginner-friendly scripting tutorials](https://www.youtube.com/playlist?list=PLX2vGYjWbI0S9-X2Q021GUtolTqbUBB9B)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PLX2vGYjWbI0S9-X2Q021GUtolTqbUBB9B" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


## CONTENIDOS 
1. C# Scripts as Behaviour Components in Unity! - Beginner Scripting Tutorial
2. C# Variables And Functions in Unity! - Beginner Scripting Tutorial
3. C# Conventions and Syntax in Unity! - Beginner Scripting Tutorial
4. C# If Statements in Unity! - Beginner Scripting Tutorial
5. C# Loops in Unity! - Beginner Scripting Tutorial
6. C# Scope and Access Modifiers in Unity! - Beginner Scripting Tutorial
7. C# Awake and Start in Unity! - Beginner Scripting Tutorial
8. C# Update And Fixed Update in Unity! - Beginner Scripting Tutorial
9. C# Vector Maths in Unity! - Beginner Scripting Tutorial
10. C# Enabling and Disabling Components in Unity! - Beginner Scripting Tutorial
11. C# Activating GameObjects in Unity! - Beginner Scripting Tutorial
12. C# Translate and Rotate in Unity! - Beginner Scripting Tutorial
13. C# LookAt in Unity! - Beginner Scripting Tutorial
14. C# Destroy in Unity! - Beginner Scripting Tutorial
15. C# GetButton and GetKey in Unity! - Beginner Scripting Tutorial
16. C# GetAxis in Unity! - Beginner Scripting Tutorial
17. C# OnMouseDown in Unity! - Beginner Scripting Tutorial
18. C# GetComponent in Unity! - Beginner Scripting Tutorial
19. C# DeltaTime in Unity! - Beginner Scripting Tutorial
20. C# DataTypes in Unity! - Beginner Scripting Tutorial
21. C# Classes in Unity! - Beginner Scripting Tutorial
22. C# Instantiate in Unity! - Beginner Scripting Tutorial
23. C# Arrays in Unity! - Beginner Scripting Tutorial
24. C# Invoke in Unity! - Beginner Scripting Tutorial
25. C# Enumerations in Unity! - Beginner Scripting Tutorial
26. C# Switch Statements in Unity! - Beginner Scripting Tutorial
