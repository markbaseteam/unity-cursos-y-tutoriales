---
id: 01HAWPVRQJFT6RVC9JJVGWN5XT
---
[[Youtube]]

# [Unity Architecture for Noobs - Game Structure](https://www.youtube.com/watch?v=tE1qH8OxO2Y)

<iframe width="560" height="315" src="https://www.youtube.com/embed/tE1qH8OxO2Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
