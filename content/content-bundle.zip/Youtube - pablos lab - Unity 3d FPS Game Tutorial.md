---
id: 01HE6Q0WRE55QTJ2T9JB0MWJFM
---
[[Youtube]]

# [pablos lab - Unity 3d FPS Game Tutorial](https://youtube.com/playlist?list=PLhWBaV_gmpGUcM2kN_Nrzg6W_dLberx7H&si=zmesQiMvCxwXLTuA)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=zmesQiMvCxwXLTuA&amp;list=PLhWBaV_gmpGUcM2kN_Nrzg6W_dLberx7H" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
## CONTENIDOS
