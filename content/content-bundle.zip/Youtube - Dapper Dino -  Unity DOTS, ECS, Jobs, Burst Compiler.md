---
id: 01HE52NPR7GKP9QNTFHF6MEM4W
---
[[Youtube]]

# [Dapper Dino -  Unity DOTS, ECS, Jobs, Burst Compiler](https://youtube.com/playlist?list=PLS6sInD7ThM3L4AtxjixzA-3vRUjAssa4&si=tKY22rhNEjLBjpG6)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=tKY22rhNEjLBjpG6&amp;list=PLS6sInD7ThM3L4AtxjixzA-3vRUjAssa4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1 How To Get Started With DOTS In Unity 2019 (ECS, Jobs, Burst Compiler)
2 Creating A Spawning System With DOTS (ECS, Jobs, Burst Compiler)
3 Resources For Mastering DOTS (ECS, Jobs, Burst Compiler)
4 Upgrading To DOTS 0.4.0 - Unity Tutorial
5 Unity DOTS Physics - Handling Collisions - ECS
6 How To Deal Damage - Unity DOTS (ECS, Burst, Jobs)
7 How To Create A Blocking System - Unity DOTS (ECS, Burst, Jobs)
8 Elemental Resistances Tutorial - Unity DOTS (ECS, Burst, Jobs)
9 Elemental Resistances Tutorial - Unity DOTS (ECS, Burst, Jobs)
