---
id: 01HE4X2Y4VH2WGAKMWWDFVYPGK
---
[[Youtube]]

# [Omogonix - How to Make a Door System in Unity - Unity C# Tutorial](https://www.youtube.com/watch?v=1M1pMkKt6uo)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/1M1pMkKt6uo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
