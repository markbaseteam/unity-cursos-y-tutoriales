---
id: 01HDW6CDXDCSTVJ2V9RTGDHK4Q
---
[[Youtube]]

# [L_Sin Gularity - Unity AI Sight, Hearing, Memory, // Top Down 3D Tutorial Beginner 04](https://www.youtube.com/watch?v=TKlLdWmYjGg)

<iframe width="560" height="315" src="https://www.youtube.com/embed/TKlLdWmYjGg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
