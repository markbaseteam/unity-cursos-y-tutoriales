---
id: 01HF5J8SR80FA3WCWQ718J28MW
---
[[Youtube]]

# [Kevin Kaymak - Unity MMORPG Creating our own Server Network](https://youtube.com/playlist?list=PLnNyOhfshe_Ol4aUE9WM0YBG7P_wmt2hq&si=dY5FDbHWPQBMSX2P)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=dY5FDbHWPQBMSX2P&amp;list=PLnNyOhfshe_Ol4aUE9WM0YBG7P_wmt2hq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
Unity 3D Tutorial #1: MMORPG | Creating our own Server Network
Unity 3D Tutorial #2: MMORPG | Connect Client to our Server
Unity 3D Tutorial #3: MMORPG | Menu Manager
Unity 3D Tutorial #4: MMORPG | Login/Register & Save/Load Account
Unity 3D Tutorial #5: MMORPG | Matchmaking System
Unity 3D Tutorial #6: MMORPG | Send players on the battlefield
Unity 3D Tutorial #7: MMORPG | Get the player name
Unity 3D Tutorial #8: MMORPG | MySQL Database Connection
Unity 3D Tutorial #9: MMORPG | Timer: Execute Function every second
Unity 3D Tutorial #10: MMORPG | Clash Royale Elixir bar
Unity 3D | Networking Series # 1 - Your own dedicated Server
Unity 3D | Networking Series #2 - Your own .dll file
Unity 3D | Networking Series #3 - MySQL Game Database
Unity 3D | Networking Series #4 - Register your first Account
Unity 3D | Networking Series #5 - Login into your account
Unity 3D | Networking Series #6 - Network Movement and cleaning Project
Unity 3D | Networking Series #7 - Click To Move / Fixing Issues
