---
id: 01HDHA56354H229ZV1D7C59GSM
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Juego 4](https://youtube.com/playlist?list=PLNFqyZnKIlCIGfBOvh-ANb8ZwswHnQjh_&si=xvWR_mS2PDlFGWYx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=xvWR_mS2PDlFGWYx&amp;list=PLNFqyZnKIlCIGfBOvh-ANb8ZwswHnQjh_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
