---
id: 01HDH9PYEMSN5QZ9TGEHNFYB1F
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Introducción e Instalación](https://youtube.com/playlist?list=PLNFqyZnKIlCJ_G4w6lPKrWYH1fgSVdfV7&si=IbA8jqZxAiUntjg3)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=IbA8jqZxAiUntjg3&amp;list=PLNFqyZnKIlCJ_G4w6lPKrWYH1fgSVdfV7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
