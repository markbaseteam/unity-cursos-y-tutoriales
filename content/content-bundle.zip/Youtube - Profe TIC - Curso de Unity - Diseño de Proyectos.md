---
id: 01HDH9J8BHZP4RBD9PH7Z05YNB
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Diseño de Proyectos](https://youtube.com/playlist?list=PLNFqyZnKIlCKewAiyMx0d_NiShTxbwW4y&si=O2QxiyD_-AMiOECM)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=O2QxiyD_-AMiOECM&amp;list=PLNFqyZnKIlCKewAiyMx0d_NiShTxbwW4y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
