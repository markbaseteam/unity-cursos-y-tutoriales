---
id: 01HDW6CWDP3MREV6YRNRM5J7Y9
---
[[Youtube]]

# [L_Sin Gularity - Unity AI shooting the Player // Top Down 3D Tutorial Beginner 05](https://www.youtube.com/watch?v=K4f8eIRXzzM)

<iframe width="560" height="315" src="https://www.youtube.com/embed/K4f8eIRXzzM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
