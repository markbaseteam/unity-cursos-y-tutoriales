---
id: 01HED9ZE88XTH1S875AGZHWJCX
---
[[Youtube]]

# [Mike Dolan - Make a Space Sim in Unity Tutorial Series](https://youtube.com/playlist?list=PLxKA70A9e0z_OLOfF2HUWlFGUtN2-nGY_&si=zA667fKs_u4_aPmM)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=zA667fKs_u4_aPmM&amp;list=PLxKA70A9e0z_OLOfF2HUWlFGUtN2-nGY_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. How To Make a Space Sim in Unity - 3D Space Sky Box Tutorial
2. How To Make a Space Sim in Unity - Event Based Keyboard Input for Space Ship Control Tutorial
3. How To Make a Space Sim in Unity - Adding Mouse Controls to Steer a Space Ship Tutorial
4. How to Make a Space Sim in Unity - Adding C# Interface to Input, Inertia Sliding, Space Dust
5. Make a Space Sim in Unity Tutorial: Let's Add Some Lasers - Modular Weapon System
6. How to Make a Damage System in Unity: Make a Space Sim Tutorial
7. Build a Behavior Tree AI in Unity Part 1 - Making a Space Game Tutorial
8. Build a Behavior Tree AI in Unity Part 2 - Making a Space Game Tutorial
9. Build a Behavior Tree AI in Unity Part 3 - ATTACK - Making a Space Game Tutorial
10. Build a Behavior Tree AI in Unity Part 4 - Obstacle Avoidance - Making a Space Game Tutorial
