---
id: 01HDSN59XEJ5ASXCZJW10MQCPT
---
[[Youtube]]

# [Gooey GameDev - Unity Beginner 3Mins Tutorials](https://youtube.com/playlist?list=PLpJJK5wPGSdx9yqYdcRke698v54eYFCNG&si=YK-jy4fIKVyVIa3A)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=YK-jy4fIKVyVIa3A&amp;list=PLpJJK5wPGSdx9yqYdcRke698v54eYFCNG" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Unity How To C# - Invoke Function ( EP: 01 )
- Unity How To C# - Spawn Objects ( EP: 2 )
- Unity How To C# - Random Number Generator ( EP: 3 )
- Unity How To C# - Collision + Trigger ( EP: 04 )
- Unity How To C# - Load Scene ( EP: 5 )
- Unity How To C# - Post Processing ( EP: 6 )
- Unity How to C# - Moving Variables Between Scripts ( EP: 7 )
- Unity How To C# - While & For Loops ( EP: 8 )
- Unity How To C# - Coroutines ( EP: 9 )
- Unity How To C# - MoveTowards VS Lerp VS SmoothDamp ( EP: 10 )
- Unity How To C# - Raycast ( EP: 11 )
- Unity How To C# - Start Functions From Another Script ( EP: 12 )
- Unity How To C# - Arrays VS Lists ( EP: 13 )
