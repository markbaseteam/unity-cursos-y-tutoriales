---
created: 2023-10-09T14:42:48 (UTC -04:00)
tags: []
source: https://www.youtube.com/watch?v=8kv1RcBKcqY&list=PLcRSafycjWFcOugVOM7XfNI6eqDbvcIf_
author: Sunny Valley Studio
id: 01HCAVZM1P5WQVXXDRYTEMKTQV
---
[[Youtube]]

# [Sims like building system in Unity 2022 - YouTube](https://www.youtube.com/watch?v=8kv1RcBKcqY&list=PLcRSafycjWFcOugVOM7XfNI6eqDbvcIf_)

> ## Excerpt
> In this video I will be explaining how to create Sims like house building system in Unity. We will start with the basics of a grid placement system, talk abo...

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=VJmyx3rDnIxGo7kL&amp;list=PLcRSafycjWFcOugVOM7XfNI6eqDbvcIf_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

In this video I will be explaining how to create Sims like house building system in Unity. We will start with the basics of a grid placement system, talk about placing floor, walls and objects and talk a bit about the camera movement.  …

...más
