---
id: 01HAWPVRR49B51EE2R6BXRWT05
---
[[Youtube]]

# [Make a Unity Online Multiplayer RPG game (MMORPG)](https://www.youtube.com/playlist?list=PLbbmTaHgSifx0hVwr-t80T95llXgZW_jB)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLbbmTaHgSifx0hVwr-t80T95llXgZW_jB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

