---
id: 01HCR0T2PSS6H4KRH37VRW6XCJ
---
[[Youtube]]

# [Mike's Code 3D Survival Game Tutorial Unity](https://youtube.com/playlist?list=PLtLToKUhgzwnk4U2eQYridNnObc2gqWo-&si=ypze_TM-jUKodvtQ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ypze_TM-jUKodvtQ&amp;list=PLtLToKUhgzwnk4U2eQYridNnObc2gqWo-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
