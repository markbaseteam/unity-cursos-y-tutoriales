---
id: 01HE0QP2T4VWEPZG2CD8BP360E
---
[[Youtube]]

# [GameDevHQ - Learn to Program: C# Beginner Unity Tutorials](https://youtube.com/playlist?list=PLadYLGMfR6Lphpq1PZFo25_acWAEuoLh_&si=bDyjnmRpqOrUQXKz)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=bDyjnmRpqOrUQXKz&amp;list=PLadYLGMfR6Lphpq1PZFo25_acWAEuoLh_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Learn to Program with C# - Unity Beginner Tutorial Playlist!
Learn to Program with C# - VARIABLES - Beginner Unity Tutorial
Learn to Program with C# - IF/ELSE STATEMENTS- Beginner Unity Tutorial
Learn to Program with C# - LOGIC OPERATORS - Beginner Unity Tutorial
Learn to Program with C# - SWITCH STATEMENTS - Beginner Unity Tutorial
Learn to Program with C# - LOOPS (for, foreach, do, while) - Unity Beginner Tutorial
Learn to Program with C# - ARRAYS - Beginner Unity Tutorial
Learn to Program with C# - PRACTICAL - Beginner Unity Tutorial
