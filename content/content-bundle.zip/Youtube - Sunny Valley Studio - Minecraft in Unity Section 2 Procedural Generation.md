---
id: 01HE28WNHTCGEVDX3930VMB0PD
---
[[Youtube]]

# [Sunny Valley Studio - Minecraft in Unity Section 2 Procedural Generation](https://youtube.com/playlist?list=PLcRSafycjWFesScBq3JgHMNd9Tidvk9hE&si=TM8nE2QooFjc6kQp)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=TM8nE2QooFjc6kQp&amp;list=PLcRSafycjWFesScBq3JgHMNd9Tidvk9hE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Github Repo Files](https://github.com/SunnyValleyStudio/Unity-2020-Voxel-World-Tutorial-Section-2-starter-project)

## CONTENIDO 
Create MINECRAFT in Unity - S2 - P1 Intro
Create MINECRAFT in Unity - S2 - P2 Theory
Create MINECRAFT in Unity - S2 - P3 Refactoring
Create MINECRAFT in Unity - S2 - P4 Multi Octave Perlin noise
Create MINECRAFT in Unity - S2 - P5 Testing
Create MINECRAFT in Unity - S2 - P6 Chain Of Responsibility pattern P1
Create MINECRAFT in Unity - S2 - P7 Chain Of Responsibility pattern P2
Create MINECRAFT in Unity - S2 - P8 Stone Blocks
Create MINECRAFT in Unity - S2 - P9 Domain Warping
Create MINECRAFT in Unity - S2 - P10 Adding Player P1
Create MINECRAFT in Unity - S2 - P11 Adding Player P2
Create MINECRAFT in Unity - S2 - P12 Spawning the Player
Create MINECRAFT in Unity - S2 - P13 Refactoring World Script P1
Create MINECRAFT in Unity - S2 - P14 Refactoring World Script P2
Create MINECRAFT in Unity - S2 - P15 Creating infinite world
Create MINECRAFT in Unity - S2 - P16 Digging mechanic P1
