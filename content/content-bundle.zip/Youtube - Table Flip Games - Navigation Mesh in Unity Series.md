---
id: 01HE2RMP1N9GBCEJP12MDH71KF
---
[[Youtube]]

# [Table Flip Games - Navigation Mesh in unity Series](https://youtube.com/playlist?list=PL8lV_joQZ5sfqiNwoJcokJlcrgplW8uSs&si=aBSR-9NxtnDf_8ZE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=aBSR-9NxtnDf_8ZE&amp;list=PL8lV_joQZ5sfqiNwoJcokJlcrgplW8uSs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Navigation Mesh Basics | Unity AI Pathfinding (Part 1) | Table Flip Games
2. Navigation Mesh Obstacles | Unity AI Pathfinding (Part 2) | Table Flip Games
3. Building Simple AI Patrols | Unity AI Pathfinding (Part 3) | Table Flip Games
4. Dynamic AI Patrols | Unity AI Pathfinding (Part 4) | Table Flip Games
5. How Nav Mesh Links Work | Unity AI Pathfinding (Part 5) | Table Flip Games
6. Building Nav Mesh Links Manually | Unity AI Pathfinding (Part 6) | Table Flip Games
7. Nav Mesh Areas & Costs | Unity AI Pathfinding (Part 7) | Table Flip Games
8. Runtime Nav Mesh Baking | Unity AI Pathfinding (Part 8) | Table Flip Games
