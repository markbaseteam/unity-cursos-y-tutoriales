---
id: 01HFR1PFX2FVMX26PDHW1CG5MH
---
[[Youtube]]

# [Unity - Better Data with Scriptable Objects in Unity! (Tutorial)](https://www.youtube.com/watch?v=PVOVIxNxxeQ)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/PVOVIxNxxeQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
