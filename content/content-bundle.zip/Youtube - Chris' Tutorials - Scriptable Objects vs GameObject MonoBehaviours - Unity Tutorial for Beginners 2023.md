---
id: 01HFR1J5TBRM1630XHCDKP535D
---
[[Youtube]]

# [Chris' Tutorials - Scriptable Objects vs GameObject MonoBehaviours - Unity Tutorial for Beginners 2023](https://www.youtube.com/watch?v=XofEVlNmWlI)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/XofEVlNmWlI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
