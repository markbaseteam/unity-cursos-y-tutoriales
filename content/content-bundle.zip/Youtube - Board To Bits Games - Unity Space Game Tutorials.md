---
id: 01HDN7RVHR5RCGPJ2B9APMHCFC
---
[[Youtube]]

# [Board To Bits Games - Unity Space Game Tutorials](https://youtube.com/playlist?list=PL5KbKbJ6Gf982bozKUYrX9C4qN_IQYTXZ&si=65Lxc9VWMxK2A0Oj)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=65Lxc9VWMxK2A0Oj&amp;list=PL5KbKbJ6Gf982bozKUYrX9C4qN_IQYTXZ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
1. Visual Effects Tutorial: Black Hole Shader
2. Making a Custom Planet Ring in Unity
3. Realtime Mesh Editing (Planet Ring, Part 2)
4. Orbit Paths in Unity: Understanding Ellipses
5. Orbital Paths in Unity, Part 2: Making an Ellipse Class
6. Orbital Paths in Unity, Part 3: Making a Planet Orbit
