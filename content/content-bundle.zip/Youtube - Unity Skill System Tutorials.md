---
id: 01HE9D8F0VDMTT1JD77N47EDSM
---
[[Youtube]]

# [imn nam - Unity Skill System Tutorials](https://youtube.com/playlist?list=PLeJ9e4gM65HH_t7bJz94CD4qRnGTUy5mD&si=KDOEmszToUYSBvII)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=KDOEmszToUYSBvII&amp;list=PLeJ9e4gM65HH_t7bJz94CD4qRnGTUy5mD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
