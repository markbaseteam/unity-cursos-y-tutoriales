---
id: 01HE44FVTVMKFZ2D1ZJR2ABBSD
---
[[Youtube]]

# [Aggrovated Snail - GTA using Csharp](https://youtube.com/playlist?list=PLvLDB-mGAf7r-OcH_uyKQFv59CJkcKYMU&si=rvXGPHebiByrXHV5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=rvXGPHebiByrXHV5&amp;list=PLvLDB-mGAf7r-OcH_uyKQFv59CJkcKYMU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
