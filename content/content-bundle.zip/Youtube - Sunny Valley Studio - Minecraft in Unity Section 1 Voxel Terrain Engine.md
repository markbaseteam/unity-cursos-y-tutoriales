---
id: 01HE283133PJS76FY6X3RAGKJB
---
[[Youtube]]

# [Sunny Valley Studio - Minecraft in Unity Section 1 Voxel Terrain Engine](https://youtube.com/playlist?list=PLcRSafycjWFdYej0h_9sMD6rEUCpa7hDH&si=7OKy9pc1uGySJmdm)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=7OKy9pc1uGySJmdm&amp;list=PLcRSafycjWFdYej0h_9sMD6rEUCpa7hDH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

# [Github Repo Files](https://github.com/SunnyValleyStudio/Unity-2020-Voxel-World-Tutorial-Section-1-starter-project)

## CONTENIDO 
- Create MINECRAFT in Unity - Introduction
- Create MINECRAFT in Unity - S1 - P2 Theory
- Create MINECRAFT in Unity - S1 - P3 Project Setup
- Create MINECRAFT in Unity - S1 - P4 Block Type
- Create MINECRAFT in Unity - S1 - P5 Mesh Data
- Create MINECRAFT in Unity - S1 - P6 ChunkRenderer
- Create MINECRAFT in Unity - S1 - P7 Chunk class
- Create MINECRAFT in Unity - S1 - P8 Block Data SO
- Create MINECRAFT in Unity - S1 - P9 Block Data Manager
- Create MINECRAFT in Unity - S1 - P10 Block Helper
- Create MINECRAFT in Unity - S1 - P11 Rendering the terrain
