---
id: 01HDXDQCEAJX96SB1WVFNSF5HG
---
[[Youtube]]

# [Frank Eno 👾 XSGames - Unity tip: How to make a 3D Game Object clickable/touchable - for Beginners](https://www.youtube.com/watch?v=pfkQDGhd8_A)

<iframe width="560" height="315" src="https://www.youtube.com/embed/pfkQDGhd8_A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
