---
id: 01HE0R9J4ZWAD3CQ3MJDYXH7D1
---
[[Youtube]]

# [GameDevHQ - Designing Bloodborne Environments in Unity](https://youtube.com/playlist?list=PLadYLGMfR6Lo8WRizwqFn5s1cJbVqKcjt&si=CP2wcUbsNf0W8wvx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=CP2wcUbsNf0W8wvx&amp;list=PLadYLGMfR6Lo8WRizwqFn5s1cJbVqKcjt" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
