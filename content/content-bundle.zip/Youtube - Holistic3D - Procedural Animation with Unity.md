---
id: 01HFQAGVQG2XP0S6AH00WFTJ65
---
[[Youtube]]

# [Holistic3D - Procedural Animation with Unity](https://youtube.com/playlist?list=PLi-ukGVOag_3_Luxe7XPsmMoyENPOz63J&si=nfra4DNYGgUUuZ1g)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=nfra4DNYGgUUuZ1g&amp;list=PLi-ukGVOag_3_Luxe7XPsmMoyENPOz63J" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
