---
id: 01HEBZEEM43Q1HWF9H2XXZ2FP3
---
[[Youtube]]

# [OttoBotCode - Othello/Reversi Game in Unity](https://youtube.com/playlist?list=PLFk1_lkqT8MYNJmdfeEqtimRm1Yi_N__f&si=ercTzzoe6WeagPeQ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ercTzzoe6WeagPeQ&amp;list=PLFk1_lkqT8MYNJmdfeEqtimRm1Yi_N__f" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Othello/Reversi Game in Unity | Part 1 - Game Logic
Othello/Reversi Game in Unity | Part 2 - Scene Setup & Game Play
Othello/Reversi Game in Unity | Part 3 - User Interface
