---
id: 01HDPJ69MBC2FYXKNBWCGFP14T
---
[[Youtube]]

# [ForlornU - Unity Tutorials](https://youtube.com/playlist?list=PLn50fPaR26wJLQV1ptfXYec9phoC366my&si=D7PS2Jhgt_mFOYmo)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=D7PS2Jhgt_mFOYmo&amp;list=PLn50fPaR26wJLQV1ptfXYec9phoC366my" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## Contenidos 

- Generating a grid in unity 
- Camera shake in unity 3d based on distance 
- Projectile trajectory predictor - Unity physics and coding tutorial 
- Slow Motion | Bullet Time | Time Control in Unity 3d
