---
id: 01HE40SMQ880QQZNYD2JE1SM2H
---
[[Youtube]]

# [tutorialsEU - 🕹️Full Unity Course - Learn Coding in C# by Building Games](https://www.youtube.com/watch?v=1p29y6dvQiI)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/1p29y6dvQiI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
