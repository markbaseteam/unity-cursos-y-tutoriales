---
id: 01HEBP714DD1X4GBF6G6Q20Q9G
---
[[Youtube]]

# [Shaped by Rain Studios - How to make a Save & Load System in Unity | 2022](https://www.youtube.com/watch?v=aUi9aijvpgs)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/aUi9aijvpgs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
