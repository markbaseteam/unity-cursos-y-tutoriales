---
id: 01HFQ0QMKKBX1YYAWGE6V1G5YR
---
[[Youtube]]

# [Matt MirrorFish - Procedural Generation For Beginners](https://youtube.com/playlist?list=PLuldlT8dkudoNONqbt8GDmMkoFbXfsv9m&si=OjnGYpGgKCvbX0gn)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=OjnGYpGgKCvbX0gn&amp;list=PLuldlT8dkudoNONqbt8GDmMkoFbXfsv9m" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Pick a Random Item from an Array
2. Randomize Object Placement
3. Randomize Rotation
4. Procedural Spawning With Raycasts 
5. Prevent Overlap Spawns With Boxcasts In C# 
6. Spawn A Grid In C#
7. Position Variation 
8. Setting A Random Seed In Unity3d
9. Unity Procedural Forest
10. How To Combine Meshes
11. Random Colors And Materials In Unity
12. Generating Color Palettes With ScriptableObjects
13. Procedural Generation For Scene Colors
