---
id: 01HEA7FT41QMFXPPEWCX5CHZJN
---
[[Youtube]]

# [Angus Fan - Making a Turn Based Strategy Game in Unity](https://www.youtube.com/watch?v=MNSQWPhalGQ&t=9s)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/MNSQWPhalGQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
