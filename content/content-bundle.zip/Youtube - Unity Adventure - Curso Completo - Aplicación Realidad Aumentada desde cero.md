---
id: 01HEC9J026M08SCYJ3MSWF7F9M
---
[[Youtube]]

# [Unity Adventure - Curso Completo - Aplicación Realidad Aumentada desde cero](https://youtube.com/playlist?list=PLSc07dYXbtBmf2iF6GeWV_lvHaqLMJWdp&si=KXD-9av5FNfnWPjP)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=KXD-9av5FNfnWPjP&amp;list=PLSc07dYXbtBmf2iF6GeWV_lvHaqLMJWdp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. ¿Cómo crear una aplicación de Realidad Aumentada?
2. Diseño de Interfaz para Realidad Aumentada
3. Detección de planos y nube de puntos en Realidad Aumentada
4. ¿Cómo integrar Modelos 3D en Realidad Aumentada?
5. Posicionar Modelos 3D en Realidad Aumentada
6. Rotar y Seleccionar Modelos 3D en Realidad Aumentada
7. Fotos en Realidad Aumentada
8. Actualizar Contenido en Tiempo Real Realidad Aumentada
