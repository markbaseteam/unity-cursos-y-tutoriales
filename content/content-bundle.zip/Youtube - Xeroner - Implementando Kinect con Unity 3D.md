---
id: 01HE5EZZZ8V2MVVRYYNR621T36
---
[[Youtube]]

# [Xeroner - Implementando Kinect con Unity 3D](https://youtube.com/playlist?list=PLGlfxrSj1dRflUF3tknkcE2Xs9k7cMsre&si=2PLgj2YoMshwkIie)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=2PLgj2YoMshwkIie&amp;list=PLGlfxrSj1dRflUF3tknkcE2Xs9k7cMsre" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Curso de Kinect.- Conociendo Kinect
2. Curso de Kinect.- Camara a Color
3. Curso de Kinect - Camara de Profundidad
4. Curso de Kinect - Detectando Esqueletos
5. Curso de Kinect - Detectando Esqueletos (II)
6. Kinect Interactivo - Proyecto PowerPointKinect
7. Kinect Interactivo - Controles del Toolkit de Kinect
8. Prototipo 1.0 - Penales con Kinect y Unity 3D
9. Prototipo 1.0 - FaceTracking con KInect + Unity 3D
10. Curso Interactivo - Implementando Kinect con Unity 3D
