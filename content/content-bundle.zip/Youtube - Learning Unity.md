---
id: 01HAWPVRR8D8MYAKMK0VGQY5X9
---
[[Youtube]]

# [Learning Unity](https://www.youtube.com/playlist?list=PLOR58dWmZl3HdYGkuT72PHJqon-ZJeisp)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PLOR58dWmZl3HdYGkuT72PHJqon-ZJeisp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
