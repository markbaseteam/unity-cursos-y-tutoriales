---
id: 01HEBRJQQ2RR8FJHGGZWVYH7JC
---
[[Youtube]]

# [CodeLikeMe_Unity - Unity 4 Legged Animal Character Controller](https://youtube.com/playlist?list=PLhV8ko8eImFfpSKAxfPeXoJdtP9PgbBBS&si=AChckWw8F7gBRJTB)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=jQFGPgTBktW4QYqA&amp;list=PLhV8ko8eImFfpSKAxfPeXoJdtP9PgbBBS" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
