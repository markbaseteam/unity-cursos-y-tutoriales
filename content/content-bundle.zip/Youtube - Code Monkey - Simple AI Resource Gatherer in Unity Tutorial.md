---
id: 01HE3P0P0BN3VAQAG5A7K8S65K
---
[[Youtube]]

# [Code Monkey - Simple AI Resource Gatherer in Unity Tutorial](https://youtube.com/playlist?list=PLzDRvYVwl53t1vBNhjHANpXXz5M6EuT1q&si=I6mDmauyFrV9CFuL)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=I6mDmauyFrV9CFuL&amp;list=PLzDRvYVwl53t1vBNhjHANpXXz5M6EuT1q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Simple AI in Unity - Resource Gatherer Summary
2. Simple AI Resource Gatherer (Unity Tutorial)
3. Resource Storing - Simple AI Resource Gatherer (Unity Tutorial)
4. Resource Node Object - Simple AI Resource Gatherer (Unity Tutorial)
5. Player Control - Simple AI Resource Gatherer (Unity Tutorial)
6. Control Multiple Units - Simple AI Resource Gatherer (Unity Tutorial)
7. Resource Types: Gold, Wood - Simple AI Resource Gatherer (Unity Tutorial)
8. Resource Regeneration - Simple AI Resource Gatherer (Unity Tutorial)
9. Construct Tower - Simple AI Resource Gatherer (Unity Tutorial)
