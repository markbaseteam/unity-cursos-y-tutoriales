---
id: 01HE5ERZBFYD4DHPDHT8PQJJ3J
---
[[Youtube]]

# [Andrew - Kinect Depth](https://youtube.com/playlist?list=PLmc6GPFDyfw_Pouy2uRxVrEWFj4N1UOOp&si=TAs3uqoIEggtI2Wy)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=TAs3uqoIEggtI2Wy&amp;list=PLmc6GPFDyfw_Pouy2uRxVrEWFj4N1UOOp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
## CONTENIDOS
1. Kinect Depth Game in Unity - Setup (Pt. 1)
2. Kinect Depth Game in Unity - Depth Texture (Pt. 2)
3. Kinect Depth Game in Unity - Depth Handler (Pt. 3)
4. Kinect Depth Game in Unity - Rectangle (Pt. 4)
5. Kinect Depth Game in Unity - Trigger Points (Pt. 5)
6. Kinect Depth Game in Unity - Hit Detection (Pt. 6)
