---
id: 01HE9M3VA20VS67HNWH967BG04
---
[[Youtube]]

# [Considera Core - Unity C Idle Game Tutorial Series 2021 Edition](https://youtube.com/playlist?list=PLGSUBi8nI9v907UWXEXAi2wTtfUcBip1s&si=EbzaN57VCtGjtH8E)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=EbzaN57VCtGjtH8E&amp;list=PLGSUBi8nI9v907UWXEXAi2wTtfUcBip1s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
