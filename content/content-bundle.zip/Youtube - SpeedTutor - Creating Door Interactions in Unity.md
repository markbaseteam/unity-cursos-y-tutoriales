---
id: 01HE4XC9S0VHFSXDK6Y4S6YATE
---
[[Youtube]]

# [SpeedTutor - Creating Door Interactions in Unity](https://youtube.com/playlist?list=PLb34wPRpZdVdnGuSgOuwgbosbZYWy9z1Z&si=xt-WuTTaISTOVhj5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=xt-WuTTaISTOVhj5&amp;list=PLb34wPRpZdVdnGuSgOuwgbosbZYWy9z1Z" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. OPENING a DOOR with a KEY! (Unity Beginner Tutorial)
2. Door SOUNDS in Unity | Beginner Tutorial
3. Creating a HINGE DOOR in UNITY!
4. OPENING a DOOR in UNITY on TRIGGER EVENT
5. OPENING a DOOR in UNITY with a RAYCAST
6. OPENING a DOOR using a BUTTON
7. Create Interactive Doors in Unity Using Chat GPT
