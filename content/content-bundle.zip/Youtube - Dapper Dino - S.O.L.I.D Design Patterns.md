---
id: 01HE52V4JJE4EG3PH2SXHYPXFK
---
[[Youtube]]

# [Dapper Dino - S.O.L.I.D Design Patterns](https://youtube.com/playlist?list=PLS6sInD7ThM21gSGGFC1mQBL9nqlmUQOo&si=mPa6MX2s_SI2yrYX)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=mPa6MX2s_SI2yrYX&amp;list=PLS6sInD7ThM21gSGGFC1mQBL9nqlmUQOo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
