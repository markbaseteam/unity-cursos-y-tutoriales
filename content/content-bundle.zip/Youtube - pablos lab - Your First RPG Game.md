---
id: 01HE6Q4ZKGS7GFHY9HRHQ5EDP0
---
[[Youtube]]

# [pablos lab - Your First RPG Game](https://youtube.com/playlist?list=PLhWBaV_gmpGUHdmZttLq0uPrCAKO3beZT&si=BsvYv6oC8w880K5o)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BsvYv6oC8w880K5o&amp;list=PLhWBaV_gmpGUHdmZttLq0uPrCAKO3beZT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Beginner's Unity Tutorial - Your First RPG Game (01)
2. Character Controller in Unity - Your First RPG Game (02)
3. Adding Gravity In Unity - Your First RPG Game (03)
4. Animations In Unity - Your First RPG Game (04)
5. 3rd person view in Unity gta V style - Your First RPG Game (05)
6. NPC characters in unity - Your First RPG Game (06)
7. NPC character combat-states in unity - Your First RPG Game (07)
8. Mele Combat - Your First RPG Game (08)
9. Mele Damage and stats - Your First RPG Game (09)
10. Free Unity Project - RPG style (npc attack and animations)(Free Download)
11. Sword / Mele Combat in Unity - Build an RPG Game
12. Rifle Combat in Unity - Build an RPG Game
