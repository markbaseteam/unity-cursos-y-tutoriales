---
id: 01HDH97R4ABRJYF72NX1AG212W
---
[[Youtube]]

# [Danisable Programacion - Mi primer juego en Unity 3D!](https://youtube.com/playlist?list=PLAzlSdU-KYwWUmphk3FjFmEFcRscHAEy2&si=jC3oWNdV_MjUcRAx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=jC3oWNdV_MjUcRAx&amp;list=PLAzlSdU-KYwWUmphk3FjFmEFcRscHAEy2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
