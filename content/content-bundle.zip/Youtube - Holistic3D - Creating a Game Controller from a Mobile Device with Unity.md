---
id: 01HFQA2N56RPX4FMA5VC6VMEYQ
---
[[Youtube]]

# [Holistic3D - Creating a Game Controller from a Mobile Device with Unity: Part 1](https://www.youtube.com/watch?v=TvqQJgj2XMM)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/TvqQJgj2XMM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Holistic3D - Creating a Game Controller from a Mobile Device with Unity: Part 2](https://www.youtube.com/watch?v=O7Gd58wMZns)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/O7Gd58wMZns" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
