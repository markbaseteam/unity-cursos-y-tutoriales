---
id: 01HDTM849VVFXMR7XNZHCKC29B
---
[[Youtube]]

# [Justus Foran -  Make a Racing Game](https://youtube.com/playlist?list=PLFez0-FXADy3tefElNBynXUFSAzLxYcmx&si=CX8ChyJJo-qrrYnv)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=G_TKKJuNFSEBAvqY&amp;list=PLFez0-FXADy3tefElNBynXUFSAzLxYcmx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# CONTENIDO 
1. Make a Racing Game Part 1 The Track Unity Tutorial beginner game development
2. Make a Unity racing game part 2 Track Setup (Unity Tutorial)
3. Make a Lap Timer with Bolt (Unity Tutorial)
4. Speedometer setup with Bolt for Unity - Racing Game developer series #4
5. Make a Countdown Timer with Unity using Bolt
6. Unity Bolt Racing Game Mechanics tutorial
7. Unity Car AI made easy!
8. Great Garage Scene for my racing game
9. Swap Model in Unity with Visual Scripting
10. Unity Tutorial - Sound Design for Everyone!
11. Unity money system - tutorial for currency
12. Simple Race Car Position System - Unity tutorial
13. Polished UI (no bugs) by indie game dev - Unity Tutorial
14. Polished Gameplay - Unity Racing Game Tutorial
15. Painless Particle System - Sparks - Unity tutorial
16. Unity Cinemachine beginners guide - tutorial
17. Camera Shake - Very easy with Cinemachine in Unity
18. Make a cutscene in Unity - Tutorial
19. Getting good game feel from my racing game
20. Avoid this massive problem when you build your game in Unity
