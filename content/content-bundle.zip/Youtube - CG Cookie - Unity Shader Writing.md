---
id: 01HDX815KHPFAZEZHW53PBCGRM
---
[[Youtube]]

# [CG Cookie - Unity Shader Writing](https://youtube.com/playlist?list=PLV4HCa5XqFT02gZOZ_Jb_A66wqDhZMCkN&si=QEC_QlM7Ay6vck69)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=QEC_QlM7Ay6vck69&amp;list=PLV4HCa5XqFT02gZOZ_Jb_A66wqDhZMCkN" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Fundamentals - 1 Introduction
- Fundamentals - 1 Theory 
- Fundamentals - 1 Practical 
- Lambert - 2 Intro 
- Lambert - 2 Theory 
- Lambert - 2 Practical 
- Specular- 3 Intro
- Specular- 3 Theory 
- Specular- 3 Practical 
- Rim Lighting- 4 Intro 
- Rim Lighting- 4 Theory 
- Rim Lighting- 4 Practical 
- Multiple Lights - 5 Intro 
- Multiple Lights - 5 Theory 
- Multiple Lights - 5 Practical 
- Textures - 6 Intro 
- Textures - 6 Theory 
- Textures - 6 Practical 
- Normal Maps - 7 Intro 
- Normal Maps - 7 Theory 
- Normal Maps - 7 Practical 
- Additional Maps - 8 Intro 
- Additional Maps - 8 Theory 
- Additional Maps - 8 Practical 
- Optimization - 9 Intro 
- Optimization - 9 Theory 
- Optimization - 9 Practical 
