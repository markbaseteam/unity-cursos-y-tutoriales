---
id: 01HF5GEMVFZFY4SS8N1A9XYE81
---
[[Youtube]]

# [The Tutorial Chef - Unity MMORPG](https://youtube.com/playlist?list=PLJFgzBCcspK8p7Hxu2OLh-f-x0PBsIGjH&si=A5Ax8ZJsadRw-_XG)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=A5Ax8ZJsadRw-_XG&amp;list=PLJFgzBCcspK8p7Hxu2OLh-f-x0PBsIGjH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Unity Tutorial MMORPG #1 | Project Introduction
2. Unity Tutorial MMORPG #2 | Creating the Projects
3. Unity Tutorial MMORPG #3 | ConnectionHandler
4. Unity Tutorial MMORPG #4 | PackageParser P.1
5. Unity Tutorial MMORPG #5 | PackageParser P.2
6. Unity Tutorial MMORPG #6 | Package Implementations
7. Unity Tutorial MMORPG| Network ShowCase
8. Unity Tutorial MMORPG #7 | Masterserver ConfigurationService
9. Unity Tutorial MMORPG #8 | Masterserver Dispatcher
10. Unity Tutorial MMORPG #9 | Masterserver ConnectionHandler P.1
11. Unity Tutorial MMORPG #10 | Masterserver ConnectionHandler P.2
12. Unity Tutorial MMORPG #11 | Database Configuration
13. Unity Tutorial MMORPG #12| Masterserver Mainfile
14. Unity Tutorial MMORPG #13| Networkservice P.1
15. Unity Tutorial MMORPG #14| Networkservice P.2
16. Unity Tutorial MMORPG #15 | Client P.1
17. Unity Tutorial MMORPG #16 | Client P.2
18. Unity Tutorial MMORPG #17 | Client P.3
19. Unity Tutorial MMORPG #19 | Client P.5 and Starting The Server
20. Unity Tutorial MMORPG #18 | Client P.4
21. Unity Tutorial MMORPG #20 | Realm Selection
22. Unity Tutorial MMORPG #21 | Framework Explanation
23. Unity Tutorial MMORPG #22 | CharCreation P.1 Preparing UMA
24. Unity Tutorial MMORPG #23 | ClientConnectionDispatcher P.1
25. Unity Tutorial MMORPG #24 | ClientConnectionDispatcher P.2
26. Unity Tutorial MMORPG #25 | Client UMA UI P.1
27. Unity Tutorial MMORPG #26 | Client UMA UI P.2
28. Unity Tutorial MMORPG #27 | Client UMA Character Creator P.1
29. Unity Tutorial MMORPG #28 | Client UMA Character Creator P.2
30. Unity Tutorial MMORPG #29 | Client UMA Character Creator Colorpicker
31. Unity Tutorial MMORPG #30 | Client UMA Save Character to Database P.1
32. Unity Tutorial MMORPG #31 | Client UMA Save Character to Database P.2
33. Unity Tutorial MMORPG #32 | Client UMA Save Character to Database P.3
34. Unity Tutorial MMORPG #33 | Changing the Networking Part P.1
35. Unity Tutorial MMORPG #34 | Changing the Networking Part P.2
36. Unity Tutorial MMORPG #35 | Changing the Networking Part P.3
37. Unity Tutorial MMORPG #36 | Changing the Networking Part P.4
38. Unity Tutorial MMORPG #37 | Error Message System
39. Unity Tutorial MMORPG #38 | UMA Charselection P.1
40. Unity Tutorial MMORPG #39 | UMA Charselection P.2
41. Unity Tutorial MMORPG #40 | UMA Charselection P.3
42. Unity Tutorial MMORPG #41 | UMA Charselection P.4
43. Unity Tutorial MMORPG #42 | UMA Charselection P.5
44. Unity Tutorial MMORPG #43 | UMA Charselection P.6
45. Unity Tutorial MMORPG | Error Correction
46. Unity Tutorial MMORPG | Summary
47. Unity Tutorial MMORPG | XAMPP and PHPMYADMIN
