---
id: 01HE2KBGM7X64MAC7YMXX3KY5S
---
[[Youtube]]

# [Unity Official - Using Cinemachine](https://youtube.com/playlist?list=PLX2vGYjWbI0TQpl4JdfEDNO1xK_I34y8P&si=aBDqhLCwH9Pw7K3p)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=aBDqhLCwH9Pw7K3p&amp;list=PLX2vGYjWbI0TQpl4JdfEDNO1xK_I34y8P" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 



## CONTENIDOS
1. Using Cinemachine: Getting Started
2. Using Cinemachine: Track & Dolly
3. Using Cinemachine: State Driven Cameras
4. Using Cinemachine: Free Look
5. Using Cinemachine: Clear Shot
6. Using Cinemachine: Post Processing
7. Using Cinemachine: Cinemachine 2D
