---
id: 01HE0TMSF6AXXBX8E3SSCSEFSN
---
[[Youtube]]

# [Greg Dev Stuff - Action RPG like Path of Exile in Unity](https://youtube.com/playlist?list=PL0GUZtUkX6t7uOBy-F_do5YI_2FnS2ol5&si=zhSXiRME91xQSvdf)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=zhSXiRME91xQSvdf&amp;list=PL0GUZtUkX6t7uOBy-F_do5YI_2FnS2ol5" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
