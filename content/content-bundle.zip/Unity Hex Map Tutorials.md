---
id: 01HAWPVRWYP6GNT8CEY5JNE0AR
---
[[Artículos]]

# [Unity Hex Map Tutorials](https://catlikecoding.com/unity/tutorials/hex-map/)
# Hex Map

A series about hexagon maps. Lots of strategy games use them.

There is now also the [Hex Map project](https://catlikecoding.com/unity/hex-map/), which modernizes Hex Map and uses URP.

1. [Creating a Hexagonal Grid](https://catlikecoding.com/unity/tutorials/hex-map/part-1/)
2. [Blending Cell Colors](https://catlikecoding.com/unity/tutorials/hex-map/part-2/)
3. [Elevation and Terraces](https://catlikecoding.com/unity/tutorials/hex-map/part-3/)
4. [Irregularity](https://catlikecoding.com/unity/tutorials/hex-map/part-4/)
5. [Larger Maps](https://catlikecoding.com/unity/tutorials/hex-map/part-5/)
6. [Rivers](https://catlikecoding.com/unity/tutorials/hex-map/part-6/)
7. [Roads](https://catlikecoding.com/unity/tutorials/hex-map/part-7/)
8. [Water](https://catlikecoding.com/unity/tutorials/hex-map/part-8/)
9. [Terrain Features](https://catlikecoding.com/unity/tutorials/hex-map/part-9/)
10. [Walls](https://catlikecoding.com/unity/tutorials/hex-map/part-10/)
11. [More Features](https://catlikecoding.com/unity/tutorials/hex-map/part-11/)
12. [Saving and Loading](https://catlikecoding.com/unity/tutorials/hex-map/part-12/)
13. [Managing Maps](https://catlikecoding.com/unity/tutorials/hex-map/part-13/)
14. [Terrain Textures](https://catlikecoding.com/unity/tutorials/hex-map/part-14/)
15. [Distances](https://catlikecoding.com/unity/tutorials/hex-map/part-15/)
16. [Pathfinding](https://catlikecoding.com/unity/tutorials/hex-map/part-16/)
17. [Limited Movement](https://catlikecoding.com/unity/tutorials/hex-map/part-17/)
18. [Units](https://catlikecoding.com/unity/tutorials/hex-map/part-18/)
19. [Animating Movement](https://catlikecoding.com/unity/tutorials/hex-map/part-19/)
20. [Fog of War](https://catlikecoding.com/unity/tutorials/hex-map/part-20/)
21. [Exploration](https://catlikecoding.com/unity/tutorials/hex-map/part-21/)
22. [Advanced Vision](https://catlikecoding.com/unity/tutorials/hex-map/part-22/)
23. [Generating Land](https://catlikecoding.com/unity/tutorials/hex-map/part-23/)
24. [Regions and Erosion](https://catlikecoding.com/unity/tutorials/hex-map/part-24/)
25. [Water Cycle](https://catlikecoding.com/unity/tutorials/hex-map/part-25/)
26. [Biomes and Rivers](https://catlikecoding.com/unity/tutorials/hex-map/part-26/)
27. [Wrapping](https://catlikecoding.com/unity/tutorials/hex-map/part-27/)

Enjoying the [tutorials](https://catlikecoding.com/unity/tutorials/)? Are they useful?

**Please support me on [Patreon](https://www.patreon.com/catlikecoding) or [Ko-fi](https://ko-fi.com/catlikecoding)!**

[](https://www.patreon.com/catlikecoding "support me on Patreon")[](https://ko-fi.com/catlikecoding "support me on Ko-fi")

**[Or make a direct donation](https://catlikecoding.com/unity/tutorials/donating.html)!**
made by [Jasper Flick](https://catlikecoding.com/jasper-flick/)