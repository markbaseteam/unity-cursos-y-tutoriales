---
id: 01HAWPVSB4VWHRY8A3HCFSB81S
---
[[Youtube]] 
[[Sebastian Lague - Procedural Planet Generation]]

# [Level Of Detail LOD Planets in Unity](https://www.youtube.com/playlist?list=PLwRBcuYHwOZ9QVCaZWChCugGIsWuUaTZA)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLwRBcuYHwOZ9QVCaZWChCugGIsWuUaTZA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDO 
- evel Of Detail Planets in Unity #1 | Quadtrees and basics | Programming Projects 1.0
- LOD Planets in Unity #2 | Culling and Performance | Programming Projects 1.1
- LOD Planets in Unity #3 | Edge Fans | Programming Projects 1.2
- LOD Planets in Unity #4 | Terrain and Normals | Programming Projects 1.3
- LOD Planets #5 | Texturing | Programming Projects 1.4
