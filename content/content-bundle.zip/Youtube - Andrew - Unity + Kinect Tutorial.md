---
id: 01HE5EQ30CQHG9VN4AEWZGJ8SF
---
[[Youtube]]

# [Andrew - Unity + Kinect Tutorial](https://youtube.com/playlist?list=PLmc6GPFDyfw-gF4aGw4Etgo0hJSWQcrYQ&si=0Eb5zuf7ZWznYpYW)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=0Eb5zuf7ZWznYpYW&amp;list=PLmc6GPFDyfw-gF4aGw4Etgo0hJSWQcrYQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Unity + Kinect Tutorial - Setup (Pt. 1)
2. Unity + Kinect Tutorial - Joints (Pt. 2)
3. Unity + Kinect Tutorial - Interactions (Pt. 3)
4. Unity + Kinect Tutorial - Bubble Manager (Pt. 4)
