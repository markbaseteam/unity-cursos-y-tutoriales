---
id: 01HFR1ZW6SJJ6NJ0MD98MYX3TB
---
[[Youtube]]

# [Dan Pos - Using Scriptable Objects for Events in Unity | Scene Independent Event System](https://www.youtube.com/watch?v=e8WHdMI8hxk)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/e8WHdMI8hxk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
