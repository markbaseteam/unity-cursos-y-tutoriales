---
id: 01HE7G2VC7Z4AMTBVHY7V2AEYY
---
[[Youtube]]

# [Peer Play - Snowtracks Shader](https://youtube.com/playlist?list=PL3POsQzaCw53KM74XVRXv2xyesLjngfbG&si=1LWCLUvigiZ6lutO)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=1LWCLUvigiZ6lutO&amp;list=PL3POsQzaCw53KM74XVRXv2xyesLjngfbG" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Snowtracks Shader - Unity CG/C# Tutorial [Part 1 - Tesselation Theory]
2. Snowtracks Shader - Unity CG/C# Tutorial [Part 2 - Create Vertex Displacement Tesselation]
3. Snowtracks Shader - Unity CG/C# Tutorial [Part 3 - Draw to Splatmap]
4. Snowtracks Shader - Unity CG/C# Tutorial [Part 4 - Driving Car in the Snow]
5. Snowtracks Shader - Unity CG/C# Tutorial [Part 5 - Regenerating Snow]
