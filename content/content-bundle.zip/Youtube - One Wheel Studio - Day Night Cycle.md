---
id: 01HE720THMWPH87NZHQ0Z5KZY4
---
[[Youtube]]

# [One Wheel Studio - Day Night Cycle](https://youtube.com/playlist?list=PL7S-IAgf3dlVMLTHQ6U1vgLkfwtPD8P0R&si=bgRgao77UL3QhKEh)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=bgRgao77UL3QhKEh&amp;list=PL7S-IAgf3dlVMLTHQ6U1vgLkfwtPD8P0R" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
0 : Day Night Cycle - Intro
1: Day Night Cycle - Sun Movement and Color
2: Day Night Cycle - Seasonal Tilt & Time Curve
3: Day Night Cycle - Scene and Lighting Setup
4 : Day Night Cycle - Moon Module and Modular Framework
5 : Day Night Cycle - Skybox Module
6 : Day Night Cycle - Adding a Clock
