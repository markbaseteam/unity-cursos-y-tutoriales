---
id: 01HF9GFZ17S3Z5SWYNH21AKRSQ
---
[[Youtube]]

# [Humble Toymaker - Multiplayer Card Game](https://youtube.com/playlist?list=PL4j7SP4-hFDJvQhZJn9nJb_tVzKj7dR7M&si=3Y7Yy_H9Fd0Dkckg)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=3Y7Yy_H9Fd0Dkckg&amp;list=PL4j7SP4-hFDJvQhZJn9nJb_tVzKj7dR7M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Setting up card database
2. Creating a card
3. Displaying card info
4. Better List Explanation
5. Scriptable Objects
6. Loading an Image to a Card
7. Player Deck
8. Shuffle Deck
9. Card Back
10. Card Deck Part 2
11. Draw Cards to Player Hand
12. Bug Fixes
13. Turn System
14. Draw a Card at the Start of Player Turn
15. Player and Opponent Health
16. Drag and Drop Part 1
17. Drag and Drop Part 2
