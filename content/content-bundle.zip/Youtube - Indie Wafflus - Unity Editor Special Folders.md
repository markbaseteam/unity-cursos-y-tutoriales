---
id: 01HEA8NPCVMM6AAHS2JFJY6YCE
---
[[Youtube]]

# [Indie Wafflus - Unity Editor Special Folders](https://youtube.com/playlist?list=PL0yxB6cCkoWLieUyq8wkOoyFLlX8bMP6T&si=4w_oR33CvAcuruUJ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=PUFHcIR5Zw46Y1Hd&amp;list=PL0yxB6cCkoWLieUyq8wkOoyFLlX8bMP6T" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
