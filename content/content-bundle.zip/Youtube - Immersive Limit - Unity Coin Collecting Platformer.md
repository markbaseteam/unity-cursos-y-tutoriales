---
id: 01HDQKT000N3H56E582KFC1VB9
---
[[Youtube]]

# [Immersive Limit - Unity Coin Collecting Platformer](https://youtube.com/playlist?list=PLq7npTWbkgVDgy8cYVC8oa5oKB3_9Tlv2&si=6CGKAJ7P0URhQbl2)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=6CGKAJ7P0URhQbl2&amp;list=PLq7npTWbkgVDgy8cYVC8oa5oKB3_9Tlv2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Unity Coin Collecting Platformer Part 1: Welcome + New Project
- Unity Coin Collecting Platformer Part 2: Project Setup + Import
- Unity Coin Collecting Platformer Part 3: Character Setup
- Unity Coin Collecting Platformer Part 4: Character Scripting
- Unity Coin Collecting Platformer Part 5: Input Scripting
- Unity Coin Collecting Platformer Part 6: Coins
- nity Coin Collecting Platformer Part 7: Environment
- Unity Coin Collecting Platformer Part 8: Door + Platform
- Unity Coin Collecting Platformer Part 9: Miscellaneous Polish
- Unity Coin Collecting Platformer Part 10: Level Building + Play
