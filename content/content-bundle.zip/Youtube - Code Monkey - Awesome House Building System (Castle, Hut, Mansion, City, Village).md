---
id: 01HDW1A1QP6VXWKRJRGG9QPQXM
---
[[Youtube]]

# [Code Monkey - Awesome House Building System! (Castle, Hut, Mansion, City, Village)](https://www.youtube.com/watch?v=Cdcn6uK9gPo)

<iframe width="560" height="315" src="https://www.youtube.com/embed/Cdcn6uK9gPo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
