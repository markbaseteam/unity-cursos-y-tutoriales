---
id: 01HAWPVSXWTXGRFASBCRNSDC6B
---
[[Youtube]]

# [Learn C# BASICS to ADVANCED](https://www.youtube.com/playlist?list=PLzDRvYVwl53t2GGC4rV_AmH7vSvSqjVmz)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLzDRvYVwl53t2GGC4rV_AmH7vSvSqjVmz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
