---
id: 01HDTN780Y164BBXDF9C80NCE3
---
[[Youtube]]

# [Seabass - Unity RTS Tutorials](https://youtube.com/playlist?list=PLROHqCOfMPkNvsMiLFNol0NqRjl9GzwFW&si=mK8x6TTbdnfH2h_R)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=mK8x6TTbdnfH2h_R&amp;list=PLROHqCOfMPkNvsMiLFNol0NqRjl9GzwFW" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Unity RTS - Camera Tutorial
- Unity RTS - Box Selection Tutorial
- Unity RTS - Destroyed Object Tutorial
- Unity RTS - Box Selection Tutorial (addendum)
- Unity RTS - Movement Tutorial (moving units with Agents and Steering)
- Unity RTS - Boids tutorial
- Unity RTS - Building Placement Tutorial
- Unity Flowfield Utility
