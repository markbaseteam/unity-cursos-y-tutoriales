---
id: 01HE2BYHSFR376ZYE3YH8C09A0
---
[[Youtube]]

# [b3agz - Code a Game like Minecraft in Unity](https://youtube.com/playlist?list=PLVsTSlfj0qsWEJ-5eMtXsYp03Y9yF1dEn&si=myW86Lcl2RikjlEz)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=myW86Lcl2RikjlEz&amp;list=PLVsTSlfj0qsWEJ-5eMtXsYp03Y9yF1dEn" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Github Repo Files](https://github.com/b3agz/Code-A-Game-Like-Minecraft-In-Unity/tree/master)

## CONTENIDOS
- Make Minecraft in Unity 3D Tutorial - 01 - The First Voxel
- Make Minecraft In Unity 3D Tutorial - 02 - The First Chunk
- Make Minecraft in Unity 3D Tutorial - 03 - Texturing
- Make Minecraft in Unity 3D Tutorial - 04 - Chunk Generation
- Make Minecraft in Unity 3D Tutorial - 05 - Basic Terrain
- Make Minecraft in Unity 3D Tutorial - 06 - Character Controller
- Make Minecraft in Unity 3D Tutorial - 07 - Chunk Optimisation and Debug Screen
- Make Minecraft in Unity 3D Tutorial - 08 - Create and Destroy Blocks
- Make Minecraft in Unity 3D Tutorial - 09 - Scroll-able Toolbelt
- Make Minecraft in Unity 3D Tutorial - 10 - Transparent Blocks
- Make Minecraft in Unity 3D Tutorial - 11 - Trees!
- Make Minecraft in Unity 3D Tutorial - 12 - Threading
- Make Minecraft in Unity 3D Tutorial - 13- Inventory Part 1
- Make Minecraft in Unity 3D Tutorial - 14 - Inventory Part 2
- Make Minecraft in Unity 3D Tutorial - 15 - Lighting/Custom Shader
- Make Minecraft in Unity 3D Tutorial - 16 - Diffuse Lighting
- Make Minecraft in Unity 3D Tutorial - 17 - Threading Do Over
- Make Minecraft in Unity 3D Tutorial - 18 - Load Settings File
- Make Minecraft in Unity 3D Tutorial - 19 - First Build and Run
- BONUS Make Minecraft in Unity 3D Tutorial - Animated Chunk Loading
- Make Minecraft in Unity 3D Tutorial - 20 - Basic Biomes
- BONUS Make Minecraft in Unity 3D Tutorial - Texture Atlas Packer
- Make Minecraft in Unity 3D Tutorial - 21 - Main/Settings Menus
- Make Minecraft in Unity 3D Tutorial - 22 - Fast Clouds
- Make Minecraft in Unity 3D Tutorial - 23 - Fancy Clouds
- Make Minecraft in Unity 3D Tutorial - 24 - Loading/Saving World!
- Make Minecraft in Unity 3D Tutorial - 25 - Cross-Chunk Lighting
- Make Minecraft in Unity 3D Tutorial - 26 - Non-Cube Blocks
- Make Minecraft in Unity 3D Tutorial - 27 - Directional Blocks
- Make Minecraft in Unity 3D Tutorial - 28 - Basic Water
- Make Minecraft in Unity 3D Tutorial - 29 - Block Behaviours
