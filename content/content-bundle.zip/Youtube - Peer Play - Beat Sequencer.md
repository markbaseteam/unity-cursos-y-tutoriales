---
id: 01HE7GQZXC41SX9X60FD3QGHDC
---
[[Youtube]]

# [Peer Play - Beat Sequencer](https://youtube.com/playlist?list=PL3POsQzaCw53_mQUac4f2Ba2LkcDfq_bv&si=9mLmv5rgNk887cwt)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9mLmv5rgNk887cwt&amp;list=PL3POsQzaCw53_mQUac4f2Ba2LkcDfq_bv" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Beat Sequencer - Unity/C# Tutorial [Part 0 - Introduction]
2. Beat Sequencer - Unity/C# Tutorial [Part 1 - BPM Counter]
3. Beat Sequencer - Unity/C# Tutorial [Part 2 - Tapping System]
4. Beat Sequencer - Unity/C# Tutorial [Part 3 - Demo Scene]
