---
id: 01HECB8PSDC13RXQF4J8CH9NX3
---
[[Youtube]]

# [Dinesh Punni - AR Foundation & Unity](https://youtube.com/playlist?list=PL6VJLOFcTt7awvyIGIbLLPOBrW6-Y1R-J&si=MqWVAkp3SKvACAX1)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=MqWVAkp3SKvACAX1&amp;list=PL6VJLOFcTt7awvyIGIbLLPOBrW6-Y1R-J" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. AR Foundation & Unity 01: Setup for Android
2. AR Foundation & Unity 02: Setup for iOS
3. AR Foundation & Unity 03: Image Tracking
4. Unity AR Foundation Tutorial - Plane Detection
5. Unity AR Foundation Tutorial - Tap to Place Objects in AR
6. Unity AR Foundation Tutorial - Getting Started with Face Tracking
7. Learn Augmented Reality Development - My Unity ARFoundation Course is Online!!
8. Unity AR Foundation Tutorial: Filtered Planes (1/2)
9. Unity AR Foundation Tutorial: Filtered Planes (2/2)
