---
id: 01HE7G7S20RHXV958FMVAJQABH
---
[[Youtube]]

# [Peer Play - Audio Visualization](https://youtube.com/playlist?list=PL3POsQzaCw53p2tA6AWf7_AWgplskR0Vo&si=rqBWlWaSJQoQ5_8H)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=rqBWlWaSJQoQ5_8H&amp;list=PL3POsQzaCw53p2tA6AWf7_AWgplskR0Vo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Audio Visualization - Unity/C# Tutorial [Part 0 - Result]
2. Audio Visualization - Unity/C# Tutorial [Part 1 - FFT/Spectrum Theory]
3. Audio Visualization - Unity/C# Tutorial [Part 2 - GetSpectrumData in Unity]
4. Audio Visualization - Unity/C# Tutorial [Part 3 - Visualize 512 samples]
5. Audio Visualization - Unity/C# Tutorial [Part 4 - Eight Frequency Bands]
6. Audio Visualization - Unity/C# Tutorial [Part 5 - Adding Buffers]
7. Audio Visualization - Unity/C# Tutorial [Part 6 - Ranged Usable Values]
8. Audio Visualization - Unity/C# Tutorial [Part 7 - Get Average Amplitude]
9. Audio Visualization - Unity/C# Tutorial [Part 8 - Audio Profile]
10. Audio Visualization - Unity/C# Tutorial [Part 9 - Stereo Spectrumdata]
11. Audio Visualization - Unity/C# Tutorial [Part 10 - 64 Audio Bands]
12. Microphone Input Visuals - Unity/C# Tutorial [Part 0 - Introduction]
13. Microphone Input Visuals - Unity/C# Tutorial [Part 1 - Get Microphone Devices]
