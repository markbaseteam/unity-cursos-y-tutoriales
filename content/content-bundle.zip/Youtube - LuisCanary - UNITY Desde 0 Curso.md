---
id: 01HDSGMWXM68KBF52T2CAJXYQ4
---
[[Youtube]]

# [LuisCanary - UNITY Desde 0 Curso](https://youtube.com/playlist?list=PLNEAWvYbJJ9ltV9VYRjrX0_E098SZny7k&si=3yrMtrsEwzxyUOAu)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=3yrMtrsEwzxyUOAu&amp;list=PLNEAWvYbJJ9ltV9VYRjrX0_E098SZny7k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- UNITY Desde 0/Tutorial/Introducción Fácil y Sencillo/ 1-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Fisicas Y Componentes/ 2-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/UI-HUD Canvas/ 3-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Primer Script/ 4-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Movimiento Objetos/ 5-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Recoger Objetos y Prefabs/ 6-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Texto Collectibles/ 7-Capitulo/Programación Videojuegos
- UNITY Desde 0/Tutorial/Resetear y pasar de Nivel / 8 - Capitulo/Programación Videojuegos
