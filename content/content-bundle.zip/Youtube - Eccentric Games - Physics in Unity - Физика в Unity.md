---
id: 01HEA0AEE4RXAHXD9VC49VPVX4
---
[[Youtube]]

# [Eccentric Games - Physics in Unity - Физика в Unity](https://youtube.com/playlist?list=PL8C4SmiVZY0wUFQrUXKQCS3BhRk2MIs8v&si=bY9pw9YR4F8ToLw9)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=bY9pw9YR4F8ToLw9&amp;list=PL8C4SmiVZY0wUFQrUXKQCS3BhRk2MIs8v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
