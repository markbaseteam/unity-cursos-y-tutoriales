---
id: 01HEBZH5NM770KCYEZPRX2FM6K
---
[[Youtube]]

# [OttoBotCode - Programming a Chess Game in C#](https://youtube.com/playlist?list=PLFk1_lkqT8MahHPi40ON-jyo5wiqnyHsL&si=OgkPLuHUz2CmHzEx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=OgkPLuHUz2CmHzEx&amp;list=PLFk1_lkqT8MahHPi40ON-jyo5wiqnyHsL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
Part 1 - Project Setup
Part 2 - Positions & Directions
Part 3 - Pieces & The Board
Part 4 - Drawing the Board
Part 5 - Generating Moves I
Part 6 - Generating Moves II
Part 7 - Handling Moves
Part 8 - Detect Check & Legal Moves
Part 9 - Checkmate & Stalemate
Part 10 - Game Over Menu I
Part 11 - Game Over Menu II
Part 12 - Pawn Promotions
