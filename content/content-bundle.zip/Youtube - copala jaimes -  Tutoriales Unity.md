---
id: 01HE7DGXCRF1KV52WNJ2J9KQKT
---
[[Youtube]]

# [copala jaimes - copala jaimes -  Tutoriales Unity](https://youtube.com/playlist?list=PLaMhhvxY4p_8FvLI3481Vf_o4diZQRgD1&si=xPemdsvY_YhYHYJu)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=xPemdsvY_YhYHYJu&amp;list=PLaMhhvxY4p_8FvLI3481Vf_o4diZQRgD1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Videojuego - introducción Unity
2. Videojuego Riggea tu personaje con mixamo
3. Videojuego Riggea tu personaje con mixamo 1
4. Videojuegos Configuración de las animaciónes
5. Videpjuegos Personaje animado con Blend Tree
6. Videojuegos movemos con teclado el personaje
7. Videojuegos movemos con teclado el personaje 1
