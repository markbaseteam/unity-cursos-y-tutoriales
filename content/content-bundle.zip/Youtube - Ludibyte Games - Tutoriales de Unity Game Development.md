---
id: 01HDPH7VSCVM76M12NDY8T9Z1C
---
[[Youtube]]

# [Ludibyte Games - Tutoriales de Unity Game Development](https://youtube.com/playlist?list=PL6dM-wegAFwiUMbyVk9RKlJ8C0NI6-TsN&si=7N4ZPrFogQMpjt3e)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=7N4ZPrFogQMpjt3e&amp;list=PL6dM-wegAFwiUMbyVk9RKlJ8C0NI6-TsN" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
