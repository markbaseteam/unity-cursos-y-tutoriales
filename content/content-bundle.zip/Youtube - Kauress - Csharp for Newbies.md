---
id: 01HFQ0CXF4ZV209YNGA0EY6HWQ
---
[[Youtube]]

# [Kauress - Csharp for Newbies](https://youtube.com/playlist?list=PLhomwjbiyI24jcIrMQWhNQPF4XIMBGc4-&si=tQMG2zJUgAr7G37-)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=tQMG2zJUgAr7G37-&amp;list=PLhomwjbiyI24jcIrMQWhNQPF4XIMBGc4-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. 💻What? Why? How
2. Scripts! Scripts! Scripts! 📑
3. Data Types 🌌
4. Data Types - part 2 🌌
5. Variables 📦
6. Operators - Part 1 📠
7. Operators - Part 2 📠
8. Operators - Part 3 📠
9. Loops ➿
10. While Loop ➿
11. 🥑 If conditional statement
12. 🥑 else block
13. 🥑 else if statements
