---
id: 01HE7MT28CG8078AS9GVHPS6JC
---
[[Youtube]]

# [Code Master - 🔴 Introduction • Unity Game Development for Beginners](https://youtube.com/playlist?list=PLS9G7A6kaaHPC__uNE0GtJTxhGmn5PS0-&si=uobG4pKRo9OosOWK)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=uobG4pKRo9OosOWK&amp;list=PLS9G7A6kaaHPC__uNE0GtJTxhGmn5PS0-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
