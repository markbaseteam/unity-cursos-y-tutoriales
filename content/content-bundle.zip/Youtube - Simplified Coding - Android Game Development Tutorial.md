---
id: 01HFQBTHFY60HGC2402301YPZX
---
[[Youtube]]

# [Simplified Coding - Android Game Development Tutorial](https://youtube.com/playlist?list=PLk7v1Z2rk4hjD-53VX9uqX_e6lZF9wSOX&si=ExYpG4LZ6_UvxUaS)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ExYpG4LZ6_UvxUaS&amp;list=PLk7v1Z2rk4hjD-53VX9uqX_e6lZF9wSOX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
