---
id: 01HE0RDWC11YG1H3XA2979PGDR
---
[[Youtube]]

# [GameDevHQ - Unity Filebase Breakdown](https://youtube.com/playlist?list=PLadYLGMfR6LrwOANMPcnY58sk7pzeRjcA&si=wDJIZRgeTKkN1Vwp)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=wDJIZRgeTKkN1Vwp&amp;list=PLadYLGMfR6LrwOANMPcnY58sk7pzeRjcA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. How to ANIMATE a SAFE in Unity
2. How to Detonate C4 in Unity
3. Download Over $30,000 in Game Assets in UNITY! (GameDevHQ Filebase)
4. Create a Borderlands Loot Crate in Unity!
5. Master Unity3D with GDHQ Pro Membership
6. RE2 Police Station Live Build using Filebase - 03/16/2020
7. RE2 Police Station Live Build using Filebase - 03/17/2020
8. RE2 Police Station Live Build using Filebase - 03/18/2020
9. RE2 Police Station Live Build using Filebase - 03/21/2020
10. BEST OF MADE WITH UNITY #64 - Week of March 26, 2020
11. BEST OF MADE WITH UNITY #65 - Week of April 2, 2020
12. RE2 Police Station Live Build using Filebase - 03/23/2020
13. RE2 Police Station Live Build using Filebase - 03/24/2020
14. RE2 Police Station Live Build using Filebase - 04/2/2020
15. Star Wars Inspired Level Design LIVE using Filebase - 04/7/2020
16. BEST OF MADE WITH UNITY #66 - Week of April 9, 2020
17. BEST OF MADE WITH UNITY #67 - Week of April 16, 2020
18. BEST OF MADE WITH UNITY #68 - Week of April 23, 2020
19. Star Wars Inspired Level Design LIVE using Filebase - 04/10/2020
20. BEST OF MADE WITH UNITY #78 - Week of July 2, 2020
21. BEST OF MADE WITH UNITY #79 - Week of July 9, 2020
22. BEST OF MADE WITH UNITY #80 - Week of July 16, 2020
23. BEST OF MADE WITH UNITY #92 - Week of October 5, 2020
24. DISCOVERING FILEBASE - Office Den
25. DISCOVERING FILEBASE - City Streets & Graveyard
26. DISCOVERING FILEBASE - (Revisit) Space Port & Office
27. DISCOVERING FILEBASE - (Revisit) Hospital & Dungeon
28. DISCOVERING FILEBASE - Control Room
29. DISCOVERING FILEBASE - Office Den - Gabriel Perez
30. DISCOVERING FILEBASE - Corridor/Thug's Room
31. DISCOVERING FILEBASE - Flooded Room
32. DISCOVERING FILEBASE - THE ONLY UNITY ASSET PACK YOU WILL EVER NEED!
