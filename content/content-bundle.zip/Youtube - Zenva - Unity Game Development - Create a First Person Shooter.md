---
id: 01HEC0MJYEQFKF1WN7PQQH33GT
---
[[Youtube]]

# [Zenva - Unity Game Development - Create a First Person Shooter](https://youtube.com/playlist?list=PLnEt5PBXuAmtuOqL1nY49C2ns0wcPxikC&si=wL0pUx7_EOyyjiAS)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=wL0pUx7_EOyyjiAS&amp;list=PLnEt5PBXuAmtuOqL1nY49C2ns0wcPxikC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
