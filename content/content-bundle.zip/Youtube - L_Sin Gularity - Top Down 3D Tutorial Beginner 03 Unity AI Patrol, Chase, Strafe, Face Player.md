---
id: 01HDW6BT478Y2RBKTPZB7EC1YW
---
[[Youtube]]

# [L_Sin Gularity - Unity AI Patrol, Chase, Strafe, Face Player // Top Down 3D Tutorial Beginner 03](https://www.youtube.com/watch?v=kycrLIFCXIs)

<iframe width="560" height="315" src="https://www.youtube.com/embed/kycrLIFCXIs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
