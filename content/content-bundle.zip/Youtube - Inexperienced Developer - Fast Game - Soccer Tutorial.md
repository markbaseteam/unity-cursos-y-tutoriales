---
id: 01HFQ8YW8H71JEASH8G5EAZS7H
---
[[Youtube]]

# [Inexperienced Developer - Fast Game - Soccer Tutorial](https://youtube.com/playlist?list=PLb6_89J_pziKngGnDYVmu12A0vB1VhX_J&si=6_aNCE1W3DSW2X_N)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=YJwRG7hMRHBtCX9i&amp;list=PLb6_89J_pziKngGnDYVmu12A0vB1VhX_J" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
