---
id: 01HE0QX25BS5JXMQVRZ9PAKVT8
---
[[Youtube]]

# [GameDevHQ - Learn to Program Csharp Advanced Unity Tutorials](https://youtube.com/playlist?list=PLadYLGMfR6Lp0UkcG6DJWD_Qaqzm4t--w&si=OVKP0tt7RdpU_5n2)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=OVKP0tt7RdpU_5n2&amp;list=PLadYLGMfR6Lp0UkcG6DJWD_Qaqzm4t--w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Learn to Program with C# - Unity Advanced Tutorial Playlist!
Learn to Program - LISTS - Advanced Unity Tutorial
Learn to Program with C# - ENUMS - Advanced Unity Tutorial
Learn to Program with C# - STRUCTS VS CLASSES - Advanced Unity Tutorial
Learn to Program with C# - NULLABLE TYPES - Advanced Unity Tutorial
Learn to Program with C# - INTERFACES - Advanced Unity Tutorial
Learn to Program with C# - DELEGATE & EVENTS - Advanced Unity Tutorial
