---
id: 01HE7G5D8PHA1CENPT69ZV8STQ
---
[[Youtube]]

# [Peer Play - Koch Fractals](https://youtube.com/playlist?list=PL3POsQzaCw53vmvWr-Ye-R0d3NPJzp25P&si=P5cY4f5ADagy8cG8)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=P5cY4f5ADagy8cG8&amp;list=PL3POsQzaCw53vmvWr-Ye-R0d3NPJzp25P" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Koch Fractals - Unity/C# Tutorial [Part 1 - Introduction]
2. Koch Fractals - Unity/C# Tutorial [Part 2 - Initiator Shape]
3. Koch Fractals - Unity/C# Tutorial [Part 3 - Create the Generator]
4. Koch Fractals - Unity/C# Tutorial [Part 4 - Bezier Curves]
5. Koch Fractals - Unity/C# Tutorial [Part 5 - Lerping on Audio Frequencies]
6. Koch Fractals - Unity/C# Tutorial [Part 6 - Cubic Line Audio Visuals]
7. Koch Fractals - Unity/C# Tutorial [Part 7 - Trail System]
8. Koch Fractals - Unity/C# Tutorial [Part 8 - Apply Trail Behaviour]
