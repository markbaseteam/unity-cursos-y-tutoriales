---
id: 01HE6NYY1BV3BGZV7HQJH9G2QN
---
[[Youtube]]

# [DitzelGames - Unity Physics](https://youtube.com/playlist?list=PLA6Gf0nq2Gh6h8WKcB_943JzHmswV6V5x&si=TUkp1uI5HFyVbv_q)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=TUkp1uI5HFyVbv_q&amp;list=PLA6Gf0nq2Gh6h8WKcB_943JzHmswV6V5x" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. How to add Force correctly | Unity Physics 101 (1/3)
2. How to add Rotation correctly | Unity Physics 101 (2/3)
3. How to set the Center of Mass | Unity Physics 101 (3/3)
