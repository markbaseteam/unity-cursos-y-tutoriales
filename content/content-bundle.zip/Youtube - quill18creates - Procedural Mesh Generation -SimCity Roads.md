---
id: 01HD0G13JHG1FXX8FN61WY8HJD
---
[[Youtube]]

# [quill18creates - Procedural Mesh Generation SimCity Roads](https://youtube.com/playlist?list=PLu3KjkImDX2U6zV0yI6YrJdDpN8PqWylO&si=nSj01vdq_l2fg1qM)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=nSj01vdq_l2fg1qM&amp;list=PLu3KjkImDX2U6zV0yI6YrJdDpN8PqWylO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

##  CONTENIDO 
