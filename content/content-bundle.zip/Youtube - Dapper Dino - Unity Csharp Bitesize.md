---
id: 01HE52R3JCWN1PAD6HSGQNTA79
---
[[Youtube]]

# [Dapper Dino - Unity C# Bitesize](https://youtube.com/playlist?list=PLS6sInD7ThM0FSI2zS8SwJ2JsCCCWX8M4&si=py88AQttcNbDaqYY)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=py88AQttcNbDaqYY&amp;list=PLS6sInD7ThM0FSI2zS8SwJ2JsCCCWX8M4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
