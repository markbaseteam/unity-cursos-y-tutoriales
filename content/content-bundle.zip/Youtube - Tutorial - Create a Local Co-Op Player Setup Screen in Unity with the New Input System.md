---
id: 01HECZJQNJ492EF3MJNX8MDKS0
---
[[Youtube]]

# [Broken Knights Games - Tutorial - Create a Local Co-Op Player Setup Screen in Unity with the New Input System](https://www.youtube.com/watch?v=_5pOiYHJgl0)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/_5pOiYHJgl0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
