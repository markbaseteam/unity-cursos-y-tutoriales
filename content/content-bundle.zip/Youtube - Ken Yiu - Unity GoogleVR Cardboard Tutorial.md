---
id: 01HFR4B8FDRX08HFZVF7D2VVFE
---
[[Youtube]]

# [Ken Yiu - Unity GoogleVR Cardboard Tutorial](https://youtube.com/playlist?list=PL-IYv9xE-z1E3xBWbl7DtogXIEJIDXOS7&si=AWea0mXSvJuS7Zjq)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9NaMRZfmkVn51rcN&amp;list=PL-IYv9xE-z1E3xBWbl7DtogXIEJIDXOS7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
Unity VR GoogleVR Class01 - Setup Environment
Unity VR GoogleVR Class02 - GoogleVR SDK for Unity
Unity VR GoogleVR Class03 - Mapping Head Movement
Unity VR GoogleVR Class04 - Reticle Pointer
Unity VR GoogleVR Class05 - Pointer Event Trigger
Unity VR GoogleVR Class06 - C# Script
Unity VR GoogleVR Class07 - Walking in VR
Unity VR GoogleVR Class08 - Teleporting in VR
Unity VR GoogleVR Class09 - Simple Animation
Unity VR GoogleVR Class10 - Android Build
Unity VR GoogleVR Class11 - iOS Build
Unity VR GoogleVR Class12 - Invalid Android SDK
