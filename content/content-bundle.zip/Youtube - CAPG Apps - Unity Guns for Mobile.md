---
id: 01HE73RMR3W3WN4STPBG8F3HWZ
---
[[Youtube]]

# [CAPG Apps - Unity Guns for Mobile](https://youtube.com/playlist?list=PLPHGAJ3kVt9XtqAcySLOZFY-DZJp10F01&si=0GHQR4XDdZzxxdJr)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=0GHQR4XDdZzxxdJr&amp;list=PLPHGAJ3kVt9XtqAcySLOZFY-DZJp10F01" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
