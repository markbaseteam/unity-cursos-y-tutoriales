---
id: 01HEC9PQMZG3KQ0THMMCDVE3D9
---
[[Youtube]]

# [Unity Adventure - Realidad Aumentada - ARFoundation](https://youtube.com/playlist?list=PLSc07dYXbtBlXX3VXddkMXTZv8aVzGxQg&si=BKm9Faop8cNm3KGL)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BKm9Faop8cNm3KGL&amp;list=PLSc07dYXbtBlXX3VXddkMXTZv8aVzGxQg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. ¿Cómo crear Realidad Aumentada? | Unity & ARFoundation
2. Plane Detection en Realidad Aumentada | Unity ARFoundation Tutorial
3. Fotos con Movimiento Realidad Aumentada | Unity & ARFoundation
4. Sistema Solar en Realidad Aumentada | Multi Targets Unity ARFoundation
5. Face Tracking en Realidad Aumentada
6. Asistente Virtual en Realidad Aumentada – Reconocimiento de voz
7. ¿Cómo crear Realidad Aumentada en URP Unity?
8. Convertir una foto en un Image Target en tiempo real
9. Guardar un Image Target tomado en tiempo real | Tutorial Realidad Aumentada
10. ¿Cómo usar Geolocalización VPS en Realidad Aumentada? ARCore Geospatial API
11. ¿Cómo crear Realidad Aumentada en 2022? ARFoundation 5.0
12. ¿Cómo Seleccionar, Mover, Rotar y Escalar objetos en Realidad Aumentada?
13. Object Tracking en Realidad Aumentada - ARFoundation ARKit
