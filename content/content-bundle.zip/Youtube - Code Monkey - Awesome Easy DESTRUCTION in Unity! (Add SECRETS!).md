---
id: 01HE4S5AVE8NPH6RMTFN99H5S5
---
[[Youtube]]

# [Code Monkey - Awesome Easy DESTRUCTION in Unity! (Add SECRETS!)](https://www.youtube.com/watch?v=tPWMZ4Ic7PA&t=30s)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/tPWMZ4Ic7PA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
