---
id: 01HDSNT9J8FJQHY7F4215A4P7D
---
[[Youtube]]

# [KeySmash Studios - Advancing Unity's Roll-a-Ball Tutorial](https://youtube.com/playlist?list=PLAt-r11PZmRmaTqYA-JhcGpZretwRxq8z&si=8t63xAGpwmFQ2X8V)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=8t63xAGpwmFQ2X8V&amp;list=PLAt-r11PZmRmaTqYA-JhcGpZretwRxq8z" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
- Making Basic Enemies | Advancing Roll-a-Ball | Unity Tutorial
- Respawning the Player | Advancing Roll-a-Ball | Unity Tutorial
- Win and Lose States | Advancing Roll-a-Ball | Unity Tutorial
- Local Multiplayer with Split Screen | Advancing Roll-a-Ball | Unity Tutorial
- Count and Display Scores | Advancing Roll-a-Ball | Unity Tutorial
- Where to Find Free Assets | Advancing Roll-a-Ball | Unity Tutorial
- How to Pause your Game | Advancing Roll-a-Ball | Unity Tutorial
- How to Transition Levels with a Menu | Advancing Roll-a-Ball | Unity Tutorial
- How to Add Sounds to your Game | Advancing Roll-a-Ball | Unity Tutorial
