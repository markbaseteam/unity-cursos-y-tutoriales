---
id: 01HE7N54NMMKPBPCWV38KFXF60
---
[[Youtube]]

# [Zicore - Generating a Biome Map with a climate Model and Noise - Unity and Compute Shader](https://www.youtube.com/watch?v=3l0mtWhllM8&pp=ygUMYmlvbWVzIHVuaXR5)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/3l0mtWhllM8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
