---
id: 01HECMNPAF2EN42ZBCC6Y2CG5F
---
[[Youtube]]

[LlamAcademy - Unity Coding Basics - Start Here to Learn C# Programming with a Unity Focus](https://youtube.com/playlist?list=PLllNmP7eq6TTjwoyfRYAAFOH1sMHVgI1r&si=A-Y76W1JCjB2fEGr)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=MtDb2wd4PxOOAd-7&amp;list=PLllNmP7eq6TTjwoyfRYAAFOH1sMHVgI1r" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Unity Scripting Reference!](https://docs.unity3d.com/ScriptReference/Random.html)

# [C# docs - get started, tutorials, reference](https://learn.microsoft.com/en-us/dotnet/csharp/)

## CONTENIDOS 
1. Want to Start Writing Code in Unity? Start Here! Unity C# Basics Part 1 - Writing Your First Script
2. Loops and Arrays | Unity C# Basics Part 2 | Unity Tutorial
3. MonoBehaviour Lifecycle Basics - Awake OnEnable Start Update FixedUpdate | Unity C# Basics Part 3
4. Static vs Instances | Unity C# Basics Part 4
5. Delegates? Basically, UnityEvents. But Cooler | Unity C# Basics Part 5
6. Inheritance and Interfaces for Beginners | Unity C# Basics 6 | Unity Tutorial
7. Compositional Relationships - You've Already Been Using Them | Unity C# Basics 7 | Unity Tutorial
