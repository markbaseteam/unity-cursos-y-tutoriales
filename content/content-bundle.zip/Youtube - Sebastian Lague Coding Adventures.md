---
id: 01HDEAPTDN1GR061JDJRDTEK7E
---
[[Youtube]]

# [Sebastian Lague - Coding Adventures](https://youtube.com/playlist?list=PLFt_AvWsXl0ehjAfLFsp1PGaatzAwo0uK&si=LM3aR4BCM8l6DADC)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=LM3aR4BCM8l6DADC&amp;list=PLFt_AvWsXl0ehjAfLFsp1PGaatzAwo0uK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
