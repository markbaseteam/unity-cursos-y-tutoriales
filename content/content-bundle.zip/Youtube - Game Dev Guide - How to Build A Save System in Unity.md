---
id: 01HEBMVX29XBG1BAFRFNM4X8D2
---
[[Youtube]]

# [Game Dev Guide - How to Build A Save System in Unity](https://www.youtube.com/watch?v=5roZtuqZyuw)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/5roZtuqZyuw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
