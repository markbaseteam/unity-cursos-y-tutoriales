---
id: 01HDH9YRYVR3Y7FF2VWMXH55DJ
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Juego 2](https://youtube.com/playlist?list=PLNFqyZnKIlCJNDj-nSNWD-UXR7-eNylHZ&si=lr2I-61aTij4_6cG)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=lr2I-61aTij4_6cG&amp;list=PLNFqyZnKIlCJNDj-nSNWD-UXR7-eNylHZ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
