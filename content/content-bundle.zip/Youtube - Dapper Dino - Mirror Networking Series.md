---
id: 01HE52DS7QEFW9KYV55EDBHHR0
---
[[Youtube]]

# [Dapper Dino - Mirror Networking](https://youtube.com/playlist?list=PLS6sInD7ThM1aUDj8lZrF4b4lpvejB2uB&si=fEfkicEYMNWnXL9t)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=fEfkicEYMNWnXL9t&amp;list=PLS6sInD7ThM1aUDj8lZrF4b4lpvejB2uB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
## CONTENIDOS
1. How To Make A Multiplayer Game In Unity - Client-Server - Mirror Networking
2. How To Make A Multiplayer Game In Unity - Ownership & Authority
3. Wizards In Training - Behind The Scenes - Multiplayer Lobby
4. How To Make A Multiplayer Game In Unity - Chat
5. How To Make A Multiplayer Game In Unity - Lobby - Main Menu
6. How To Make A Multiplayer Game In Unity - Lobby - Readying Up
7. How To Make A Multiplayer Game In Unity - Lobby - Start Game
8. How To Make A Multiplayer Game In Unity - Spawning Players In
9. How To Make A Multiplayer Game In Unity - Camera Movement
10. Wizards In Training - Behind The Scenes - Basic Combat
11. How To Make A Multiplayer Game In Unity - Player Movement
12. How To Make A Multiplayer Game In Unity - Round System
13. How To Make A Multiplayer Game In Unity - Input Blocking
14. How To Make A Multiplayer Game In Unity - Map Handling
15. How To Sync Events - Unity Multiplayer Tutorial
16. How To Send Network Messages - Unity Multiplayer Tutorial
17. How To Connect Using Steam - Unity Multiplayer Tutorial
18. How To Display Steam Profile Pictures & Names - Unity Multiplayer Tutorial
19. How To Make A Multiplayer Game In Unity - Animation
20. How To Set Up A Dedicated Multiplayer Server - Unity PlayFab
21. How To Make A Multiplayer Game In Unity (Mirror) - Character Selection
22. How To Make A Multiplayer Game In Unity - Authentication
23. How To Make A Multiplayer Game In Unity - Matchmaking
