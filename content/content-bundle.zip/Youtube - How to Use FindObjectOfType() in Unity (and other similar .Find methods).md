---
id: 01HEBQJC6813NPAJCCFQ2Q5P4X
---
[[Youtube]]

# [Unity Game Programming For Beginners - How to Use FindObjectOfType() in Unity (and other similar .Find methods)](https://www.youtube.com/watch?v=LXX_p33C0NM)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/LXX_p33C0NM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
