---
id: 01HE2XRQK8FCBD1VRM1TT5QKXC
---
[[Youtube]]

# [Pixel Mystique Games - How to Build Low Poly Modular Dungeon Levels](https://youtube.com/playlist?list=PLs_yJ-RML1YceFhpnPnMOl1X21D2tsCxZ&si=W_dAHU9QrGeqUHej)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=W_dAHU9QrGeqUHej&amp;list=PLs_yJ-RML1YceFhpnPnMOl1X21D2tsCxZ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Level Design in Unity | Low Poly Modular Dungeon | Part 1 | Planning
2. Level Design in Unity | Low Poly Modular Dungeon | Part 2 | Floor Tiles Modeling
3. Level Design in Unity | Low Poly Modular Dungeon | Part 3 | UV Unwrap & Applying Materials
4. Level Design in Unity | Low Poly Modular Dungeon | Part 4 | Floor Tiles Assembly
