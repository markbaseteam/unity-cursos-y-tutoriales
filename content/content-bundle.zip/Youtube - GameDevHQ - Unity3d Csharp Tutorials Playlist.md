---
id: 01HE0R0HMND53ETFPRJTQK2FNA
---
[[Youtube]]

# [GameDevHQ - Unity3d C# Tutorials Playlist](https://youtube.com/playlist?list=PLadYLGMfR6LrNp-L1DcDuX2FCOSZ-uWsx&si=2c4991RIgoqGER_d)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=2c4991RIgoqGER_d&amp;list=PLadYLGMfR6LrNp-L1DcDuX2FCOSZ-uWsx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Unity3d C# Tutorials Playlist
Unity C# Basics - Part 1 - Player Movement
Unity C# Basics - Part 2 - Using OnGUI
Unity C# Basics - Part 3 - Introducing Raycasting
Unity C# Basics - Part 4 - Pausing Your Game (Part 1)
Unity C# Basics - Part 5 - Pausing Your Game (Part 2)
Unity C# Basics - Part 6 - Enemy Spawn Manager (Part 1)
Unity C# Basics - Part 7 - Enemy Spawn Manager (Part 2)
Unity C# Basics - Part 8 - Get Component (Script Communication)
Unity C# Basics - Part 9 - Universal Health System
Unity C# Basics - Part 10 - Layer Masks
Unity C# Basics - Part 11 - Monodevelop Settings
Unity C# Basics - Part 12 - What Are Quaternions?
Unity C# Basics - Part 13 - What Is Object Pooling?
Unity C# Basics - Part 14 - Tile Map Generator (Nested For loops)
Custom VR Hands
BEST OF MADE WITH UNITY #1 - Week of January 14, 2019
