---
id: 01HE4QAKJ2YH8SCNGDK9ZPZCJQ
---
[[Youtube]]

# [Code Monkey - Adding Modding to my Game with Unity UGC!](https://www.youtube.com/watch?v=PLOvBtmAZRs)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/PLOvBtmAZRs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
