---
id: 01HE567GHARZA38YPBXWAD846C
---
[[Youtube]]

# [Unity Multiplayer Guides (FishNet)](https://youtube.com/playlist?list=PLF6lFlLzb6CSuf4g8ZR1VRq-TAgC6AQWD&si=SrvkMZ7BAD3SUoGo)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=SrvkMZ7BAD3SUoGo&amp;list=PLF6lFlLzb6CSuf4g8ZR1VRq-TAgC6AQWD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

