---
id: 01HF5H7A9G8JD1S86FG8M2CZ00
---
[[Youtube]]

# [LiveOverflow - Unity Multiplayer/MMO Game - Game Devlog #3](https://www.youtube.com/watch?v=0RJQVkavFIA)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/0RJQVkavFIA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

https://github.com/JasonXuDeveloper/Unity-GUI-Redis

https://github.com/JasonXuDeveloper/JEngine


## CONTENIDOS
