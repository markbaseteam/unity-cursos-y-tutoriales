---
id: 01HE74JJEYAPJ468BPGD4T280X
---
[[Youtube]]

# [Gemuki Dev - Tutoriales de Unity](https://youtube.com/playlist?list=PLYfmTvVOMa1I84f9uH9U68swDwVsYAC1M&si=9CQlP6lTbxGDfvqa)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9CQlP6lTbxGDfvqa&amp;list=PLYfmTvVOMa1I84f9uH9U68swDwVsYAC1M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Cómo hacer EFECTOS de PARTÍCULAS en Unity | Tutorial VFX
2. ¿Cómo hacer ESCENARIOS PRE-RENDERIZADOS? | Gráficos prerenderizados con Unity
3. Cómo crear PORTALES y MAGIAS con PARTÍCULAS en Unity | Tutorial VFX #2
4. Tutorial RAYOS en Unity | Tutorial VFX #3
5. Luces 2D en Unity: CONSEJOS para iluminar
6. Animación 2D con huesos: tutorial para la nueva librería de Unity 2021
7. BRAZO ROBÓTICO con Unity usando CONSTRAINTS
8. Cómo HACER el Pong en HTML5 vs Unity
