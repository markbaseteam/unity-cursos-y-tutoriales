---
id: 01HEC0JQYST0AME1E3JB1P6QXR
---
[[Youtube]]

# [Zenva - Unity VR Game Development Course](https://youtube.com/playlist?list=PLnEt5PBXuAms1dhWjU9iUx8ay8aXSQN8F&si=GhjN3ykvNwLA9YVx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=GhjN3ykvNwLA9YVx&amp;list=PLnEt5PBXuAms1dhWjU9iUx8ay8aXSQN8F" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
