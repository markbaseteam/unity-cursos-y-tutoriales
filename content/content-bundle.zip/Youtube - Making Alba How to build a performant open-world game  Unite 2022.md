---
id: 01HCMQ696PN2ZV57MENYK1CZZT
---
[[Youtube]]

# [Making Alba: How to build a performant open-world game | Unite 2022](https://www.youtube.com/watch?v=YOtDVv5-0A4)

<iframe width="560" height="315" src="https://www.youtube.com/embed/YOtDVv5-0A4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
