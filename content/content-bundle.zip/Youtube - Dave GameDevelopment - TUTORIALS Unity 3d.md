---
id: 01HDSSG0Z02BZPRC9SX9W92T7V
---
[[Youtube]]

# [Dave GameDevelopment - TUTORIALS Unity 3d](https://youtube.com/playlist?list=PLh9SS5jRVLAleXEcDTWxBF39UjyrFc6Nb&si=znyTFQTaPyJkBbdU)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=znyTFQTaPyJkBbdU&amp;list=PLh9SS5jRVLAleXEcDTWxBF39UjyrFc6Nb" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Full WALL RUN TUTORIAL for Unity 3d
- SHOOTING with BULLETS + CUSTOM PROJECTILES || Unity 3D Tutorial (#1)
- SHOOTING with BULLETS + CUSTOM PROJECTILES || Unity 3D Tutorial (#2)
- How to make ALL kinds of GUNS with just ONE script! (Unity3d tutorial)
- Unity SINGLE, DOUBLE and LONG mouse click Tutorial || SkillBased Tutorials
- FULL PICK UP & DROP SYSTEM for WEAPONS or ITEMS || Unity3d Tutorial
- FIRST PERSON MOVEMENT in 10 MINUTES - Unity Tutorial
- SLOPE MOVEMENT, SPRINTING & CROUCHING - Unity Tutorial
- THROWING Grenades, Knives and Other Objects - Unity Tutorial
- ADVANCED SLIDING IN 9 MINUTES - Unity Tutorial
- Full CLIMBING SYSTEM in 10 MINUTES - Unity Tutorial
- Full LEDGE CLIMBING SYSTEM in 11 MINUTES - Unity Tutorial
- ADVANCED 3D DASH ABILITY in 11 MINUTES - Unity Tutorial
- ADVANCED GRAPPLING HOOK in 11 MINUTES - Unity Tutorial
- ADVANCED SWINGING in 9 MINUTES - Unity Tutorial
- ADVANCED DUAL SWINGING in 10 MINUTES - Unity Tutorial
