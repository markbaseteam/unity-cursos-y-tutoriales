---
id: 01HE9M6FHJ75F41N17S3YPWPM0
---
[[Youtube]]

# [Considera Core - IdleClicker Game Using Unity Bolt!](https://youtube.com/playlist?list=PLGSUBi8nI9v-OUNi80COVBWRGnFrCPQuA&si=hBgCsfe82A2Y5tWM)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=hBgCsfe82A2Y5tWM&amp;list=PLGSUBi8nI9v-OUNi80COVBWRGnFrCPQuA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
