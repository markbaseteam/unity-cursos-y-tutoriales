---
id: 01HE0R64CKDHG26CP2TTY5G2TG
---
[[Youtube]]

# [GameDevHQ - Coding Math](https://youtube.com/playlist?list=PLadYLGMfR6LqzKa4lhT1xjv8bBvA4WT8-&si=vTLiMM5YWsiVOqCL)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=vTLiMM5YWsiVOqCL&amp;list=PLadYLGMfR6LqzKa4lhT1xjv8bBvA4WT8-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
