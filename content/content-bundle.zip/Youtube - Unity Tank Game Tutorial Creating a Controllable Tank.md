---
id: 01HDQCMR7N24PNCN68MWM57G84
---
[[Youtube]]

# [Homebrew - Unity Tank Game Tutorial: Creating a Controllable Tank](https://www.youtube.com/watch?v=1rohOpl9Tq4)

<iframe width="560" height="315" src="https://www.youtube.com/embed/1rohOpl9Tq4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
