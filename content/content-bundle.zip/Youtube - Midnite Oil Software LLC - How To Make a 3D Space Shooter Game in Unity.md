---
id: 01HE0HVHHJYNZS7X2DQ3HD37TS
---
[[Youtube]]

# [Midnite Oil Software LLC - How To Make a 3D Space Shooter Game in Unity - Tutorial](https://youtube.com/playlist?list=PLHcOLPSLOK7PNvLAdnqicE_BeqoNH7Zwz&si=1rP8ql5y-gnUPNDE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=1rP8ql5y-gnUPNDE&amp;list=PLHcOLPSLOK7PNvLAdnqicE_BeqoNH7Zwz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
