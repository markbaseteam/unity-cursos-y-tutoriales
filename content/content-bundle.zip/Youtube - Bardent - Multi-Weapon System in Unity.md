---
id: 01HEBZZY1S9RBQBV2EFJK023JB
---
[[Youtube]]

# [Bardent - Multi-Weapon System in Unity](https://youtube.com/playlist?list=PLy78FINcVmjDeHVYh8SMjEP1B_MdSLCSz&si=lvkG7JMwhm6vmt_k)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=lvkG7JMwhm6vmt_k&amp;list=PLy78FINcVmjDeHVYh8SMjEP1B_MdSLCSz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDOS
