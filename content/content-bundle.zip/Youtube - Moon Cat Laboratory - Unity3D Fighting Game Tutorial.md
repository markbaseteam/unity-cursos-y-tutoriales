---
id: 01HE70JQB4QZGPQ872Y2F6VZ6X
---
[[Youtube]]

# [Moon Cat Laboratory - Unity3D Fighting Game Tutorial #239 Fight Camera Optional](https://youtube.com/playlist?list=PL7IxPGHreINV0cG196jVCytHeio6WXWGD&si=-HqKJ5KpmXWs6lxb)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=-HqKJ5KpmXWs6lxb&amp;list=PL7IxPGHreINV0cG196jVCytHeio6WXWGD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
