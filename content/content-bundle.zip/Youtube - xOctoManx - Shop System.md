---
id: 01HECSEEXYZKN20FW4GKCYBXGG
---
[[Youtube]]

# [xOctoManx - Shop System](https://youtube.com/playlist?list=PLj0TSSTwoqAyiZdEFqp6pQjAg17q3q4kA&si=B18IuaYY0cCXHnCk)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=B18IuaYY0cCXHnCk&amp;list=PLj0TSSTwoqAyiZdEFqp6pQjAg17q3q4kA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
