---
id: 01HAWPVRR0DV88FTQ61XTD0M6G
---
[[Youtube]]

# [Open Projects: Create small, open-source game projects](https://www.youtube.com/playlist?list=PLX2vGYjWbI0S6CnkDm0AwVgA6E6L_vJNf)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PLX2vGYjWbI0S6CnkDm0AwVgA6E6L_vJNf" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
