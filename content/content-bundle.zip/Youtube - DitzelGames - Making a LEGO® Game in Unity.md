---
id: 01HE6P2HG52J7ZJJDBV6GH5Q5Z
---
[[Youtube]]

# [DitzelGames - Making a LEGO® Game in Unity](https://youtube.com/playlist?list=PLA6Gf0nq2Gh4YGSGCX9kj7v5-ruTU87qS&si=BO01GQ33JZNij2sp)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BO01GQ33JZNij2sp&amp;list=PLA6Gf0nq2Gh4YGSGCX9kj7v5-ruTU87qS" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Making a LEGO® Game in Unity - #LegoGame 
2. Rigging a LEGO® Character in blender - #LegoGame 
3. Making a LEGO® Game in Unity - #LegoGame 
4. LEGO® Character Control - #LegoGame 
5. Character Animations Tricks - #LegoGame 
6. Making a LEGO® Brick for Unity! - #LegoGame 
7. Lego Building System - #LegoGame 
8. Make a Ring Menu in Unity - #LegoGame 
9. Delete Bricks - #LegoGame 
