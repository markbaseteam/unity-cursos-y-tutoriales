---
id: 01HE0Q657RNWDWHP6MVR4CSM6G
---
[[Youtube]]

# [quill18creates - Unity Base-Building](https://youtube.com/playlist?list=PLbghT7MmckI4_VM5q3va043FgAwRim6yX&si=Q_AucJyBnfWe8eDS)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Q_AucJyBnfWe8eDS&amp;list=PLbghT7MmckI4_VM5q3va043FgAwRim6yX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Unity Base-Building Game Tutorial - Episode 1!
2. Unity Base-Building Game Tutorial - Episode 2!
3. Unity Base-Building Game Tutorial - Episode 3!
4. Unity Base-Building Game Tutorial - Episode 4!
5. Unity Base-Building Game Tutorial - Episode 5!
6. Unity Base-Building Game Tutorial - Episode 6!
7. Unity Base-Building Game Tutorial - Episode 7!
8. Unity Base-Building Game Tutorial - Episode 7.5 - Responding to some comments!
9. Unity Base-Building Game Tutorial - Episode 8!
10. Unity Base-Building Game Tutorial - Episode 9!
11. Unity Base-Building Game Tutorial - Episode 10!
12. Unity Base-Building Game Tutorial - Episode 11! [Improving the wall-drawing code.]
13. Unity Base-Building Game Tutorial - Episode 12! [Finishing touches on Walls!]
14. Unity Base-Building Game Tutorial - Episode 13!
15. Unity Base-Building Game Tutorial - Episode 14!
16. Unity Base-Building Game Tutorial - Episode 15! [Job System]
17. Unity Base-Building Game Tutorial - Episode 16! [Job System Continued]
18. Unity Base-Building Game Tutorial - Episode 17! [Job System Continued]
19. Unity Base-Building Game Tutorial - Episode 18! [Our First Character!]
20. Unity Base-Building Game Tutorial - Episode 19! [AI for our Character!]
21. Unity Base-Building Game Tutorial - Episode 20! [Responding to Comments!]
22. Unity Base-Building Game Tutorial - Episode 21! [PATHFINDING - Part 1]
23. Unity Base-Building Game Tutorial - Episode 22! [PATHFINDING - Part 2]
24. Unity Base-Building Game Tutorial - Episode 23! [PATHFINDING - Part 3]
25. Unity Base-Building Game Tutorial - Episode 24! [PATHFINDING - Part 4]
26. Unity Base-Building Game Tutorial - Episode 25! [NOT Cutting Corners]
27. Unity Base-Building Game Tutorial - Episode 26! [Saving and Loading]
28. Unity Base-Building Game Tutorial - Episode 27! [Saving and Loading]
29. Unity Base-Building Game Tutorial - Episode 28! [Saving and Loading]
30. Unity Base-Building Game Tutorial - Episode 29! [Starting on Doors!]
31. Unity Base-Building Game Tutorial - Episode 30! [Better Saving/Loading]
32. Unity Base-Building Game Tutorial - Episode 31! [Working Door!]
33. Unity Base-Building Game Tutorial - Episode 32! [Animated Doors!]
34. Unity Base-Building Game Tutorial - Episode 33! [Room Detection]
35. Unity Base-Building Game Tutorial - Episode 34! [Flood-Fill for Rooms!]
36. Unity Base-Building Game Tutorial - Episode 35! [UI / Tooltip Work]
37. Unity Base-Building Game Tutorial - Episode 36! [Strategyizing & Refactoring]
38. Unity Base-Building Game Tutorial - Episode 37! [Inventory Items!]
39. Unity Base-Building Game Tutorial - Episode 38! [Inventory Items...continued!]
40. Unity Base-Building Game Tutorial - Episode 39! [Per-Furniture Jobs]
41. Unity Base-Building Game Tutorial - Episode 40! [Hauling Inventory]
42. Unity Base-Building Game Tutorial - Episode 41! [Hauling Inventory, Continued]
43. Unity Base-Building Game Tutorial - Episode 42! [Stockpiles!]
44. Unity Base-Building Game Tutorial - Episode 43! [Stockpiles - Debugging]
45. Unity Base-Building Game Tutorial - Episode 44! [Stockpiles - Prettifying!]
46. Unity Base-Building Game Tutorial - Episode 45! [Multi-Tile Objects!]
47. Unity Base-Building Game Tutorial - Episode 46! [Improving the UI]
48. Unity Base-Building Game Tutorial - Episode 47! [Better Building Interface]
49. Unity Base-Building Game Tutorial - Episode 48! [Getting Gassy!]
50. Unity Base-Building Game Tutorial - Episode 49! [Deconstruction]
51. Unity Base-Building Game Tutorial - Episode 50! [Merging Rooms]
52. Unity Base-Building Game Tutorial - Episode 51! [Adding our first "workbench".]
53. Unity Base-Building Game Tutorial - Episode 52! [Fixing "World", Dynamic UI Buttons]
54. Unity Base-Building Game Tutorial - Episode 53! [Repeating Jobs!]
55. Unity Base-Building Game Tutorial - Episode 54! [Saving/Loading Rooms]
56. Unity Base-Building Game Tutorial - Episode 55! [XML Data files for Furniture]
57. Unity Base-Building Game Tutorial - Episode 56! [XML Data files for Furniture]
58. Unity Base-Building Game Tutorial - Episode 57! [XML Data files for Furniture]
59. Unity Base-Building Game Tutorial - Episode 58! [LUA in Unity!]
60. Unity Base-Building Game Tutorial - Episode 59! [LUA in Unity!]
61. Unity Base-Building Game Tutorial - Episode 60! [Porting Furniture Logic to LUA]
62. Unity Base-Building Game Tutorial - Episode 61! [Just a bit more Lua]
63. Unity Base-Building Game Tutorial - Episode 62! [Loading Sprites from Disk!]
64. Unity Base-Building Game Tutorial - Episode 63! [Loading Sprites from Disk!]
65. Unity Base-Building Game Tutorial - Episode 64! [Loading Sprites from Disk!]
66. Unity Base-Building Game Tutorial - Episode 65! [Better Item Pathfinding!]
67. Unity Base-Building Game Tutorial - Episode 66! [Multiple Characters!]
68. Unity Base-Building Game Tutorial - Episode 67! [Selecting Things!]
69. Unity Base-Building Game Tutorial - Episode 68! [Interface]
70. Unity Base-Building Game Tutorial - Episode 69! [File Saving Dialog]
71. Unity Base-Building Game Tutorial - Episode 70! [File Saving Dialog]
72. Unity Base-Building Game Tutorial - Episode 71! [File Loading Dialog]
73. Unity Base-Building Game Tutorial - Episode 72! [Fine-Tuning and Bug-Fixing]
74. Unity Base-Building Game Tutorial - Facing Fix
