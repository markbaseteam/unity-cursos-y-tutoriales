---
id: 01HE73KVA1D96VDD3MRJK2H4C6
---
[[Youtube]]

# [CAPG Apps - Unity 2017 Car Setup](https://youtube.com/playlist?list=PLPHGAJ3kVt9W-aGXFW35C3tyM7R5BONYw&si=S-5k4D5L3iTsY8XS)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=S-5k4D5L3iTsY8XS&amp;list=PLPHGAJ3kVt9W-aGXFW35C3tyM7R5BONYw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
