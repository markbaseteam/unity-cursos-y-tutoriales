---
id: 01HED82ER3YFZSMKWTFD00CBQE
---
[[Youtube]]

# [Dan Pos - Survival Base Building](https://youtube.com/playlist?list=PL-hj540P5Q1hHGzbuPDrVBs2LRvgpnPkt&si=kNXpsl6hC54ET-p4)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=kNXpsl6hC54ET-p4&amp;list=PL-hj540P5Q1hHGzbuPDrVBs2LRvgpnPkt" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Episode 1 | Set Up & Build Tool Basics
- Episode 2 | Updating Materials On Build Preview
- Episode 3 | Implementing Building Prefabs
- Episode 4 | Setting Up Our UI
- Episode 5 | Finishing Up The UI
- Episode 6 | Saving And Loading Your Base
