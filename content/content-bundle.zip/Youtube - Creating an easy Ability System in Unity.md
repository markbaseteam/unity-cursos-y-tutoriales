---
id: 01HE9D2M68A8EQGFD89ZB836WF
---
[[Youtube]]

# [TIMBER - Creating an easy Ability System in Unity](https://www.youtube.com/watch?v=ry4I6QyPw4E)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/ry4I6QyPw4E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
