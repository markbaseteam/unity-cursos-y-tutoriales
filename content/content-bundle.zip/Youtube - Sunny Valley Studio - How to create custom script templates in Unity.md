---
id: 01HDDK766FTWE7HE41P5Z0G5MA
---
[[Youtube]]

# [Sunny Valley Studio - How to create custom script templates in Unity](https://youtu.be/YpKJedxBxks?si=D7QkB5qVq4Rfdocm)

<iframe width="560" height="315" src="https://www.youtube.com/embed/YpKJedxBxks?si=D7QkB5qVq4Rfdocm" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
