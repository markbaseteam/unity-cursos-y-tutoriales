---
id: 01HE2RGQFYVWKWG40W6JTMZ2CW
---
[[Youtube]]

# [Table Flip Games - Csharp Programming Getting Started](https://youtube.com/playlist?list=PL8lV_joQZ5sccEpB_GpAgRE0xwsJYBIvR&si=JnALv3AQjFUJ8oyr)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=JnALv3AQjFUJ8oyr&amp;list=PL8lV_joQZ5sccEpB_GpAgRE0xwsJYBIvR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
- Getting Started with C# | C# Beginners (Part 1) | Table Flip Games
- Your First C# Program (Hello World) | C# Beginners (Part 2) | Table Flip Games
- How to Run Visual Studio | C# Beginners (Part 3) | Table Flip Games
- How Variables Work | C# Beginners #4 | Table Flip Games
