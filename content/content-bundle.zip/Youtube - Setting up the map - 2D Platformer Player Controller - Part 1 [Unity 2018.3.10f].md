---
id: 01HEC02H5TZCD929KZS7G0AS2D
---
[[Youtube]]

# [Bardent - 2D Platformer Player Controller](https://youtube.com/playlist?list=PLy78FINcVmjA0zDBhLuLNL1Jo6xNMMq-W&si=GqMoNt79c0lF71g5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=GqMoNt79c0lF71g5&amp;list=PLy78FINcVmjA0zDBhLuLNL1Jo6xNMMq-W" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
