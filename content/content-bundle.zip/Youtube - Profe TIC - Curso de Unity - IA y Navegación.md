---
id: 01HDHAA8164K3CJVS9GTPJSDHE
---
[[Youtube]]

# [Profe TIC - Curso de Unity - IA y Navegación](https://youtube.com/playlist?list=PLNFqyZnKIlCIz9zKZBRaj_8HrYBSPJodu&si=RRNiOAFQPN5OR-42)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=RRNiOAFQPN5OR-42&amp;list=PLNFqyZnKIlCIz9zKZBRaj_8HrYBSPJodu" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
