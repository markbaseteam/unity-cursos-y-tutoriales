---
id: 01HE0QSDY2Q3YT0R9CFTTXP4XX
---
[[Youtube]]

# [GameDevHQ - Learn to Program: C# Intermediate Unity Tutorials](https://youtube.com/playlist?list=PLadYLGMfR6Lpvh3xX3a7LXbqJqY_WjIk7&si=TRiuJctw1sv3e25X)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=TRiuJctw1sv3e25X&amp;list=PLadYLGMfR6Lpvh3xX3a7LXbqJqY_WjIk7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
Learn to Program with C# - Unity Intermediate Tutorial Playlist!
Learn to Program with C# - FUNCTIONS OR METHODS - Intermediate Unity Tutorial
Learn to Program with C# - CLASSES - Intermediate Unity Tutorial
Learn to Program with C# - CONSTRUCTORS - Intermediate Unity Tutorial
Learn to Program with C# - STATIC TYPES - Intermediate Unity Tutorial
Learn to Program with C# - PROPERTIES - Intermediate Unity Tutorial
Learn to Program with C# - SINGLETON DESIGN - Intermediate Unity Tutorial
Learn to Program with C# - NAMESPACES - Intermediate Unity Tutorial
Learn to Program with C# - PRACTICAL - Intermediate Unity Tutorial
