---
id: 01HFFJQSJ1ZDNBAZRYXSZJVW9P
---
[[Youtube]]

# [Coding With Unity - Inventory System with Scriptable Objects](https://youtube.com/playlist?list=PLJWSdH2kAe_Ij7d7ZFR2NIW8QCJE74CyT&si=_HrjukDIcP90L30p)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=_HrjukDIcP90L30p&amp;list=PLJWSdH2kAe_Ij7d7ZFR2NIW8QCJE74CyT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
