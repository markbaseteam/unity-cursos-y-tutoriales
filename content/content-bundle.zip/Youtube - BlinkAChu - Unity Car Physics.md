---
id: 01HE4GQYKZDFPGX83F2JK47H74
---
[[Youtube]]

# [BlinkAChu - Unity Car Physics](https://youtube.com/playlist?list=PLcbsEpz1iFyjjddSqLxnnGSJthfCcmsav&si=uGXT-SykPVwkHIi1)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=uGXT-SykPVwkHIi1&amp;list=PLcbsEpz1iFyjjddSqLxnnGSJthfCcmsav" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
Unity Car Physics - Lesson 1 - Suspension Physics
Unity Car Physics - Lesson 2 - Ackermann Steering
Unity Car Physics - Lesson 3 - Forward and Right Forces
