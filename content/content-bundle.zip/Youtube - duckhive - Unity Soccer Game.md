---
id: 01HFQ94SW4Q1NN64N2QVPHMPW5
---
[[Youtube]]

# [duckhive - duckhive - Unity Soccer Game](https://youtube.com/playlist?list=PLwZ1kAmPIl5vmDziIU1wWGW1lRT7R8C4v&si=DFhVuAdZMLUVO-gE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=DFhVuAdZMLUVO-gE&amp;list=PLwZ1kAmPIl5vmDziIU1wWGW1lRT7R8C4v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
