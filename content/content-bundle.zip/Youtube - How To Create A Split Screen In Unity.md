---
id: 01HECZ1WWCGSW4GCZ8JBZP7JDG
---
[[Youtube]]

# [bendux - How To Create A Split Screen In Unity](https://www.youtube.com/watch?v=rw2VKAdTdgQ)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/rw2VKAdTdgQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
