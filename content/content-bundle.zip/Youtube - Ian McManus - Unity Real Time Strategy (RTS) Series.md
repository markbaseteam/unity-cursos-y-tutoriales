---
id: 01HCG49V12H3B359C0E9T0F2C8
---
[[Youtube]]

# [Ian McManus - Unity Real Time Strategy (RTS) Series](https://youtube.com/playlist?list=PLkBiJgxNbuOXdG0N6_tduD_7V0zuM3UVl&si=XmfaPia8sCHoXE8d)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=XmfaPia8sCHoXE8d&amp;list=PLkBiJgxNbuOXdG0N6_tduD_7V0zuM3UVl" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
