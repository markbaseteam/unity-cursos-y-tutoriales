---
id: 01HE2KF74MZ7B2A6ZYK49PT829
---
[[Youtube]]

# [Unity Official - Machine Learning Agents](https://youtube.com/playlist?list=PLX2vGYjWbI0R08eWQkO7nQkGiicHAX7IX&si=Os9Tj4WqLBDTvKLk)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Os9Tj4WqLBDTvKLk&amp;list=PLX2vGYjWbI0R08eWQkO7nQkGiicHAX7IX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

# [Github Repo Files](https://github.com/Unity-Technologies/ml-agents)

## CONTENIDOS
1. Machine Learning Agents - Introduction [1/10] Live 2018/4/4
2. Machine Learning Agents - Reinforcement and Imitation Learning [2/10] Live 2018/4/4
3. Machine Learning Agents - Unity ML Agents Workflow [3/10] Live 2018/4/4
4. Machine Learning Agents - ML Agents Push Block Example [4/10] Live 2018/4/4
5. Machine Learning Agents - ML Agent Brains [5/10] Live 2018/4/4
6. Machine Learning Agents - Push Block Agent Components [6/10] Live 2018/4/4
7. Machine Learning Agents - Push Agent Basic Script [7/10] Live 2018/4/4
8. Machine Learning Agents - Training Your Agent [8/10] Live 2018/4/4
9. Machine Learning Agents - Using Your Trained Brain [9/10] Live 2018/4/4
10. Machine Learning Agents - Conclusion [10/10] Live 2018/4/4
