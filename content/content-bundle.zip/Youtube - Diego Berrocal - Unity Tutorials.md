---
id: 01HE4JRQGQ38BE57BW67BHQH1F
---
[[Youtube]]

# [Diego Berrocal - Unity Tutorials](https://youtube.com/playlist?list=PLVxq4HUq7dJMbwmH8Ze6lCiTQrLPOOzSH&si=_CtCudKqUrjCYkT1)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=_CtCudKqUrjCYkT1&amp;list=PLVxq4HUq7dJMbwmH8Ze6lCiTQrLPOOzSH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Shader Graph Tutorial - Outline Effect - Unity
2. How to create a procedural terrain generator in Unity - Shaders, scripts and settings
3. Neural Network 3D Simulation
4. Orbit simulation in Unity 3D
