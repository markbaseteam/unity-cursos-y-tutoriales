---
id: 01HECNM7FCYNQD37W54WTQC59P
---
[[Youtube]]

# [Joed Lopes da Silva - Unity VR Open XR and XR Interaction Toolkit](https://youtube.com/playlist?list=PLWeYqcDl7tVsQYhovYOAdLCq5RoXvZPjM&si=NEICUMtjyHuglVRm)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=NEICUMtjyHuglVRm&amp;list=PLWeYqcDl7tVsQYhovYOAdLCq5RoXvZPjM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Open XR and XR Interaction Toolkit - Introduction
2. Create Project
3. Install Packages
4. Create Basic Scene for VR
5. Make Escape Room Game in Unity - Introduction
6. Make Escape Room Game in Unity - Creating a basic Scene
7. Make Escape Room Game in Unity - Simple XR Interactable (Push Button)
8. Make Escape Room Game in Unity - Finite State Machines
9. Lobby Scene with UI Canvas
10. Using GarageBand to generate sounds for our game
11. Recording voice with effects in GarageBand
12. Memory Game (Simon Game) in VR - Introduction
13. Memory Game - Building the Map and Using XR Grab Interaction & Trigger Event
14. Mem VR (Gameplay)
