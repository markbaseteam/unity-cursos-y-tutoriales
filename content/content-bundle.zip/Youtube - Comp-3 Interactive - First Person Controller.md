---
id: 01HE4X68Y8ZGKTEZ6VNA2NQ9N8
---
[[Youtube]]

# [Comp-3 Interactive - First Person Controller](https://youtube.com/playlist?list=PLfhbBaEcybmgidDH3RX_qzFM0mIxWJa21&si=jEVj8gZheUj2sHFq)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=jEVj8gZheUj2sHFq&amp;list=PLfhbBaEcybmgidDH3RX_qzFM0mIxWJa21" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. First Person Controller - Basic Movement and Mouse Input (EP01) [Unity Tutorial]
2. First Person Controller - Sprinting (EP02) [Unity Tutorial]
3. First Person Controller - Jumping (EP03) [Unity Tutorial]
4. First Person Controller - Crouching (EP04) [Unity Tutorial]
5. First Person Controller - Headbob (EP05) [Unity Tutorial]
6. First Person Controller - Slope Sliding (EP06) [Unity Tutorial]
7. First Person Controller - Zoom/ADS (EP07) [Unity Tutorial]
8. First Person Controller - Interaction (EP08) [Unity Tutorial]
9. First Person Controller - Footsteps (EP09) [Unity Tutorial]
10. First Person Controller - Health System (EP10) [Unity Tutorial]
11. First Person Controller - Stamina System (EP11) [Unity Tutorial]
12. First Person Controller - Using Doors (EP12) [Unity Tutorial]
