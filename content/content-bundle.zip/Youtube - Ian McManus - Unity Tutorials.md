---
id: 01HED9KTN6BB188PA4FESR54X8
---
[[Youtube]]

# [Iain McManus - Unity Tutorials](https://youtube.com/playlist?list=PLkBiJgxNbuOUf3dzZn2nkkahLHShQ2ghf&si=D-rCft-S8yZ5pIOL)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=D-rCft-S8yZ5pIOL&amp;list=PLkBiJgxNbuOUf3dzZn2nkkahLHShQ2ghf" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
