---
id: 01HE52FD4Y5X6K6KCHDH6X3RXQ
---
[[Youtube]]

# [Dapper Dino - RPG Systems Series](https://youtube.com/playlist?list=PLS6sInD7ThM3pM-9_f9TBWVvYjoP9uDhO&si=J--hyoFdJ1dLkbws)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=J--hyoFdJ1dLkbws&amp;list=PLS6sInD7ThM3pM-9_f9TBWVvYjoP9uDhO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. How To Create RPG Systems - Part 1 - Player Blend Tree
2. How To Create RPG Systems - Part 2 - Player Movement Controller
3. How To Create RPG Systems - Part 3 - Interaction System
4. How To Create RPG Systems - Part 4 - Data Containers
5. How To Create RPG Systems - Part 5 - Item Pickups
6. How To Create RPG Systems - Part 6 - Inventory Refactor
7. How To Create RPG Systems - Part 7 - Npc Logic
8. How To Create RPG Systems - Part 8 - Npc UI
9. How To Create RPG Systems - Part 9 - Vendor UI
10. How To Create RPG Systems - Part 10 - Vendor Data On UI
11. How To Create RPG Systems - Part 11 - Selecting Items To Trade
12. How To Create RPG Systems - Part 12 - Buying And Selling Items
13. How To Create RPG Systems - Part 13 - Finishing The Vendor System
14. How To Create RPG Systems - Part 14 - Starting The Combat System
