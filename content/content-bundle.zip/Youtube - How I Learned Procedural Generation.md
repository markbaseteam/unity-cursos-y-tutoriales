---
id: 01HE4K7C9WCS58KCBAZFBF6199
---
[[Youtube]]

# [Lejynn - How I Learned Procedural Generation](https://www.youtube.com/watch?v=XpG3YqUkCTY&t=25s)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/XpG3YqUkCTY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
