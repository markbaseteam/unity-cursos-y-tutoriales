---
id: 01HE77J474ZQ4Q25M7YWYF4AX2
---
[[Youtube]]

# [Omar A. Balfaqih - Timeline](https://youtube.com/playlist?list=PLaqp5z-4pFi4Lwxb7sURkFrkVfKpGfCgL&si=z152RXwnoDWZ1Nk6)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=z152RXwnoDWZ1Nk6&amp;list=PLaqp5z-4pFi4Lwxb7sURkFrkVfKpGfCgL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
