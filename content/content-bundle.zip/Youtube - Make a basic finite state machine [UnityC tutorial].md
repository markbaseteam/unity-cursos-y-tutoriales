---
id: 01HCGX8NHMENK0J4A52DWVDAFY
---
[[Youtube]]

# [Make a basic finite state machine [Unity/C# tutorial]](https://www.youtube.com/watch?v=-VkezxxjsSE)

<iframe width="560" height="315" src="https://www.youtube.com/embed/-VkezxxjsSE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
