---
id: 01HE6XAW56Y4Y6EXYA2VJF56AA
---
[[Youtube]]

#  [Soul's Game Dev Journey - Learn to Create a Turn-Based Strategy with Unity](https://youtube.com/playlist?list=PLHaBJbUxcrnnUAIB_z5mRprsRwt5ZRCdb&si=8_h9Ub8FL4S7QZ5k)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=8_h9Ub8FL4S7QZ5k&amp;list=PLHaBJbUxcrnnUAIB_z5mRprsRwt5ZRCdb" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDOS 
1. Learn to Create a Turn-Based Strategy with Unity
2. Connect Unity with GitHub: A Beginner's Guide to Unity Project Setup & Linking with GitHub/GitLab
3. How to Make a Hex Grid in Unity - Basic Setup
4. TBS in Unity - Custom Editor and Procedural Mesh Generation
5. Unity Tutorial: Convert Mouse Clicks to Hex Grid in Turn-Based Strategy Game Creation (FIXED)
6. Creating a Hexagonal Map in Unity: Dive into Scriptable Objects, IEnumerator, Tasks & Multithreading
7. Mastering Terrain Generation: Perlin Noise in Unity | Game Dev Tutorial
8. Unity Input System - Interacting with the world
9. Setting up Cinemachine for Top-Down and Orbit Cameras in Unity | Souls Game Dev Journey
