---
id: 01HE4270VPKYG2SQW828B322BB
---
[[Youtube]]

# [Programming with Mosh - C# Tutorial For Beginners - Learn C# Basics in 1 Hour](https://www.youtube.com/watch?v=gfkTfcpWqAY)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/gfkTfcpWqAY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
