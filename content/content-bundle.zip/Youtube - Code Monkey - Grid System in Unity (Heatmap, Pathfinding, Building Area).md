---
id: 01HAWPVSFJ3K91DYRA0SK4ZKFG
---
[[Youtube]]

# [Grid System in Unity (Heatmap, Pathfinding, Building Area)](https://youtube.com/playlist?list=PLzDRvYVwl53uhO8yhqxcyjDImRjO9W722&si=o6IgE6scsZuJFq3b)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=o6IgE6scsZuJFq3b&amp;list=PLzDRvYVwl53uhO8yhqxcyjDImRjO9W722" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDOS 
1. Grid System in Unity (Heatmap, Pathfinding, Building Area)
2. Powerful Generics Added! Grid System in Unity (Terraria, Minesweeper, Tilemap)
3. A* Pathfinding in Unity
4. Cool Heatmap in Unity
5. Awesome Grid Building System! (City Builder, RTS, Factorio, Survival)
6. Custom Tilemap in Unity with Saving and Loading (Level Editor)
7. Making Minesweeper in Unity (Simple 2D game for Beginners)
8. Grid Combat System! (Turn-Based, XCOM)
9. I Made a Factory Game in 20 HOURS!
10. Awesome House Building System! (Castle, Hut, Mansion, City, Village)
11. Awesome Inventory Tetris System! (Resident Evil 4, Escape from Tarkov)
12. House Building System like Rust/Valheim! (First/Third Person | Unity Tutorial)
13. How to DRAW Pixel Art INSIDE Unity! (Modding, Unity Tutorial)
14. I made XCOM in 25 HOURS! (plus Special Announcement!)
15. How to Test if a POINT is inside a HEX! (No Raycasts, Just Simple Math)
16. How to make a Hex Grid System Unity Tutorial! (Like Civilization, Opus Magnum, Gloomhaven)
17. Unity Pathfinding on a Hex Grid System!
