---
id: 01HE5FH6RW83XERYPX2Q9K9DED
---
[[Youtube]]

# [I'm Sunny - Unity 3D Kinect Tutorial](https://youtube.com/playlist?list=PLt4cr24rjC_RJMMQtX4YrO_a31vWNGwTd&si=kxAVFJn2iGF6Pjuj)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=kxAVFJn2iGF6Pjuj&amp;list=PLt4cr24rjC_RJMMQtX4YrO_a31vWNGwTd" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
