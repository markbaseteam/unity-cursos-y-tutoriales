---
id: 01HECE4QWYMHYSZ03X6HQ4373B
---
[[Youtube]]

# [Ludic Worlds - Set up Unity's new XR Hands Package - OpenXR based Hand Tracking](https://www.youtube.com/watch?v=PYMoAsOtevQ)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/PYMoAsOtevQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
