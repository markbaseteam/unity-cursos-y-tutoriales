---
id: 01HE73YCKZ931PCPQJ88ZR7J50
---
[[Youtube]]

# [CAPG Apps - Unity Tank Battle Game Player Controls for Mobile](https://youtube.com/playlist?list=PLPHGAJ3kVt9WcWgAGYj8oRpcDVZya_MHR&si=BNNXJgScyJkEMT50)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=BNNXJgScyJkEMT50&amp;list=PLPHGAJ3kVt9WcWgAGYj8oRpcDVZya_MHR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
