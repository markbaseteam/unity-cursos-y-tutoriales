---
id: 01HEA7DWFG5FE50K2YAQ6WCRVN
---
[[Youtube]]

# [Angus Fan - Turn Based Strategy Games Card Games](https://youtube.com/playlist?list=PLH-LoTIQnuZuLbto7pqYQBT1-9zEgYjpK&si=iiKfQiHye4hfTu7w)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=iiKfQiHye4hfTu7w&amp;list=PLH-LoTIQnuZuLbto7pqYQBT1-9zEgYjpK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
