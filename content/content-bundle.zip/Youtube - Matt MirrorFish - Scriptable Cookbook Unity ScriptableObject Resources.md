---
id: 01HE6R3VWAM9J6T5SKS7BXH6VK
---
[[Youtube]]

# [Matt MirrorFish - Scriptable Cookbook Unity ScriptableObject Resources](https://youtube.com/playlist?list=PLuldlT8dkudpCEkYQJb_H26BcbE7ozisX&si=6VLNrZ-rNXyXGpaC)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=6VLNrZ-rNXyXGpaC&amp;list=PLuldlT8dkudpCEkYQJb_H26BcbE7ozisX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
1. Scriptable Cookbook: Scriptable Object Variables and Actions
2. Unite Austin 2017 - Game Architecture with Scriptable Objects
3. Stop Using Singletons With Runtime Set ScriptableObjects (Unity Tutorial)
4. Live Training 8th August 2016 - Ability System with Scriptable Objects
5. How To Use Scriptable Objects in Unity
6. Unite 2016 - Overthrowing the MonoBehaviour Tyranny in a Glorious Scriptable Object Revolution
7. SCRIPTABLE OBJECTS en Unity
8. Unite '17 Seoul - ScriptableObjects What they are and why to use them
9. Pluggable AI With Scriptable Objects - Finite State AI [2/10] Live 2017/3/08
10. Setup Guide for Strata Easy 2D Level Generator For Unity
11. Creating a Text Based Adventure - Introduction and Goals [1/8] Live 2017/3/22
12. Scriptable Cookbook: Damage Type System With ScriptableObject Enums (Unity Tutorial)
