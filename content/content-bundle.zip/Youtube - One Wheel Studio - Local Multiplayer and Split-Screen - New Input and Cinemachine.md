---
id: 01HECZ5T3D04S9YCJQ0JSGHVY6
---
[[Youtube]]

# [One Wheel Studio - Local Multiplayer and Split-Screen - New Input and Cinemachine](https://www.youtube.com/watch?v=l9HrraxtdGY)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/l9HrraxtdGY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

# [Github Code](https://github.com/onewheelstudio/Adventures-in-C-Sharp/tree/main/Split%20Screen)
## CONTENIDOS
