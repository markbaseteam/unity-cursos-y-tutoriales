---
id: 01HB1WBJ8VKW18EKAC33RA4DGP
---
[[Youtube]]

# [The Ultimate Multiplayer Tutorial for Unity - Netcode for GameObjects](https://www.youtube.com/watch?v=swIM2z6Foxk&t=1465s)

<iframe width="560" height="315" src="https://www.youtube.com/embed/swIM2z6Foxk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
