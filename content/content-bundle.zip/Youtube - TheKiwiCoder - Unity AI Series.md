---
id: 01HE53D81AREGHPV18KQP0XF9D
---
[[Youtube]]

# [TheKiwiCoder - Unity AI Series](https://youtube.com/playlist?list=PLyBYG1JGBcd009lc1ZfX9ZN5oVUW7AFVy&si=EDTP7wcPBj3PXFzz)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=EDTP7wcPBj3PXFzz&amp;list=PLyBYG1JGBcd009lc1ZfX9ZN5oVUW7AFVy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
