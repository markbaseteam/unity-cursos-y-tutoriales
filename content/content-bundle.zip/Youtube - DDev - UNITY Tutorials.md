---
id: 01HE6BWDQ1BZFC29D705Y92AGT
---
[[Youtube]]

# [/<DDev - UNITY Tutorials](https://youtube.com/playlist?list=PLZeoJfXLvdRoKSNFnMFZzkMo37s6FfJ4R&si=69fkuZIIzCruv77Z)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=69fkuZIIzCruv77Z&amp;list=PLZeoJfXLvdRoKSNFnMFZzkMo37s6FfJ4R" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. How to make a Weapon System in UNITY | Tutorial
2. How to make an EXPLOSION in Unity | Tutorial
3. How to GENERATE a MESH in UNITY | Unity Tutorial
