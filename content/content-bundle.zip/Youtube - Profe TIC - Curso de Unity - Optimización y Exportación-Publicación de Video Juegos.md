---
id: 01HDHAD14QGWEX4JDZ8C0Z0WNS
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Optimización y Exportación-Publicación de Video Juegos](https://youtube.com/playlist?list=PLNFqyZnKIlCKKzheO0X2qdNbcV50r7HZt&si=nny_mGLWTbVG1QEh)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=nny_mGLWTbVG1QEh&amp;list=PLNFqyZnKIlCKKzheO0X2qdNbcV50r7HZt" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
