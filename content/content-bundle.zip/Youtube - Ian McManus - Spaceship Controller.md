---
id: 01HED9V3PEHH3M2QZ87FGGY96F
---
[[Youtube]]

# [Ian McManus - Spaceship Controller](https://youtube.com/playlist?list=PLkBiJgxNbuOW99YuKp8gCBjeLOVJvtZtL&si=8rMJNrjiu6MosP0_)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=8rMJNrjiu6MosP0_&amp;list=PLkBiJgxNbuOW99YuKp8gCBjeLOVJvtZtL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
1. Unity Tutorial: Simple Spaceship (Part 1 - Movement and Effects)
2. Unity Tutorial: Simple Spaceship (Part 2 - UI and Auto-Levelling)
3. Unity Tutorial: Simple Spaceship (Part 3 - AutoLanding and Input Switching)
4. Unity Tutorial: Simple Spaceship (Part 4 - Landing Camera and Polish)
5. Unity Tutorial: Simple Spaceship (Part 5 - Damage and Repairs)
6. Unity Tutorial: Simple Spaceship (Part 6 - Variable Gravity)
7. Unity Tutorial: Simple Spaceship (Part 7 - Landing and Braking Polish)
