---
id: 01HDW6BB26BC6XZYJX0G45Z4WH
---
[[Youtube]]

# [L_Sin Gularity - Unity Shooting bullets and applying damage to enemy // Top Down 3D Tutorial Beginner 02](https://www.youtube.com/watch?v=pxG68lK2VYc)

<iframe width="560" height="315" src="https://www.youtube.com/embed/pxG68lK2VYc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
