---
id: 01HDSG3SP2DS3C2N07BXAF1RS2
---
[[Youtube]]

# [freeCodeCamp.org - C# Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=GhQdlIFylQ8&t=0s)

<iframe width="560" height="315" src="https://www.youtube.com/embed/GhQdlIFylQ8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
