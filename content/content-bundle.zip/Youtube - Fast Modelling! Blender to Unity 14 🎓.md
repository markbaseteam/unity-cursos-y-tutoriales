---
id: 01HE6QFV6SJHDQCNFN846ZGTQ6
---
[[Youtube]]

# [DitzelGames - Blender to Unity](https://youtube.com/playlist?list=PLA6Gf0nq2Gh4AVFeqUL7xUfoxASM6izh5&si=9CtOx2YdyOvDglVJ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9CtOx2YdyOvDglVJ&amp;list=PLA6Gf0nq2Gh4AVFeqUL7xUfoxASM6izh5" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Fast Modelling! Blender to Unity 1/4 🎓
2. Fast Rigging! Blender to Unity 2/4 🎓
3. Animation explained fast! Blender to Unity 3/4 🎓
4. Import and Use Models! Blender to Unity 4/4 🎓
5. Create an Animal Ragdoll in Unity
