---
id: 01HEDTDASPMZ0E8STXMDGYT7MN
---
[[Youtube]]

# [GMGStudio - Advanced Tutorials](https://youtube.com/playlist?list=PLB8RAOcCIoiyxv6zYQi3KY-YUxUGubquW&si=IygoAbr4nJXlZKui)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=IygoAbr4nJXlZKui&amp;list=PLB8RAOcCIoiyxv6zYQi3KY-YUxUGubquW" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
1. Map Generator in EditMode
2. Using all Cores in Unity [Multithreading] | GMGStudio
3. Faster Coding in Unity | Assembly Definitions
4. Map Generator 2
5. Map Generator 3 | Spawn on Terrain
6. 3D Track Generator | Generate/Expand Mesh
7. 3D Track Generator | Generate Looping
8. 3D Rope in Unity | Hinge Joint
9. Move on 3D Sphere | DomeCannon
10. Suspension Bridge in Unity
11. Save and Load JSON | JsonUtility
12. Call native iOS Code with arguments from Unity with Swift Packages! Working! 🛠
13. Ai for Games | GMGStudio
14. Pathfinding in Unity
15. Place Objects in 3D Scene| GMGStudio
16. Gathering Resources with NPCs
17. Queue NPCs
