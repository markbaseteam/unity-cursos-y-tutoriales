---
id: 01HEA8G9VRXMQ6Y7Q2TYN0S3CN
---
[[Youtube]]

# [Indie Wafflus - Genshin Impact Movement in Unity | Full Video - Movement System](https://youtu.be/kluTqsSUyN0?si=Ci3XN9rGKjD7NCZp)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/kluTqsSUyN0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
Useful Links:

● GitHub Repository: https://github.com/Wafflus/unity-gens...
● Small Videos Tutorial Series (Youtube Link):    • Genshin Impact Movement in Unity | #0...  
● Starting Project (Github): https://github.com/Wafflus/resources/...
● Kenney's Prototype Textures (Website): https://www.kenney.nl/assets/prototyp...
● Mixamo (Website):  https://www.mixamo.com
● Rest of the Links (Pastebin): https://pastebin.com/SRrrzaS7