---
id: 01HEBWSZVY0SYHVQSBQW2ARGRG
---
[[Youtube]]

# [CodeLikeMe_Unity - Unity Open World](https://youtube.com/playlist?list=PLhV8ko8eImFe2lW_JKdN_gg2XKNFnohiQ&si=orWmjQl_OSUZr4TX)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=orWmjQl_OSUZr4TX&amp;list=PLhV8ko8eImFe2lW_JKdN_gg2XKNFnohiQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
