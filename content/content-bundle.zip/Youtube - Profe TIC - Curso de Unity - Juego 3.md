---
id: 01HDHA2YQFHQNW24GYBX5VC5G2
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Juego 3](https://youtube.com/playlist?list=PLNFqyZnKIlCJXbsInHPRe0L8twHE6XXcP&si=Q_yNcmZLGOP2VK7M)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Q_yNcmZLGOP2VK7M&amp;list=PLNFqyZnKIlCJXbsInHPRe0L8twHE6XXcP" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
