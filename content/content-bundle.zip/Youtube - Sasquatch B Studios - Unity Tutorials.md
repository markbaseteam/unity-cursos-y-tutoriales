---
id: 01HEC11JA4TJ48CWF35PY2GTMP
---
[[Youtube]]

# [Sasquatch B Studios - Unity Tutorials](https://youtube.com/playlist?list=PLfmYNuLHEy-PQ6j6kki9kmM3Z5CayRSI0&si=Obt4F5YtnbMri-gY)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Obt4F5YtnbMri-gY&amp;list=PLfmYNuLHEy-PQ6j6kki9kmM3Z5CayRSI0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
