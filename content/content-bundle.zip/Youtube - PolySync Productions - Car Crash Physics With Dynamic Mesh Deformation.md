---
id: 01HEA0W7Q8ZHE0RPP4ZTJG8ZBQ
---
[[Youtube]]

# [PolySync Productions - Car Crash Physics With Dynamic Mesh Deformation C#](https://www.youtube.com/watch?v=-dsRIyzAcqg)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/-dsRIyzAcqg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
