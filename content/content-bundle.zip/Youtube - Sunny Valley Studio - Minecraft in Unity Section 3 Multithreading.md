---
id: 01HE291SN2GA4JJHJN1CJFWD53
---
[[Youtube]]

# [Sunny Valley Studio - Minecraft in Unity Section 3 Multithreading](https://youtube.com/playlist?list=PLcRSafycjWFceHTT-m5wU51oVlJySCJbr&si=VnhiJs4OQsbLHdPF)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=VnhiJs4OQsbLHdPF&amp;list=PLcRSafycjWFceHTT-m5wU51oVlJySCJbr" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 



## CONTENIDO 
Create MINECRAFT in Unity - S3 - P1 Intro to multithreading
Create MINECRAFT in Unity - S3 - P2 Async & Await in Unity
Create MINECRAFT in Unity - S3 - P3 Making our code multithreaded P1
Create MINECRAFT in Unity - S3 - P4 Making our code multithreaded P2
Create MINECRAFT in Unity - S3 - P5 Stopping async Tasks
Create MINECRAFT in Unity - S3 - P6 Object Pooling chunks
Create MINECRAFT in Unity - S3 - P7 Adding Trees P1
Create MINECRAFT in Unity - S3 - P8 Adding Trees P2
Create MINECRAFT in Unity - S3 - P9 Adding Trees P3
Create MINECRAFT in Unity - S3 - P10 Digging logic fix
Create MINECRAFT in Unity - S3 - P11 Different biomes theory
Create MINECRAFT in Unity - S3 - P12 Creating desert biome
Create MINECRAFT in Unity - S3 - P13 Biome selection algorithm P1
Create MINECRAFT in Unity - S3 - P14 Biome selection algorithm P2
