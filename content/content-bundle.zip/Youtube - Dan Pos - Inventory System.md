---
id: 01HED7YF7SY8R1WY1P2P747AH8
---
[[Youtube]]

# [Dan Pos - Inventory System](https://youtube.com/playlist?list=PL-hj540P5Q1hLK7NS5fTSNYoNJpPWSL24&si=97nyqwF3KNpVK-40)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=97nyqwF3KNpVK-40&amp;list=PL-hj540P5Q1hLK7NS5fTSNYoNJpPWSL24" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
