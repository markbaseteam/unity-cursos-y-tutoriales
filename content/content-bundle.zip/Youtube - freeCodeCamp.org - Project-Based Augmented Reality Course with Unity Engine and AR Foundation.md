---
id: 01HEC9BQ2BXMPZN9KSWXAT2R6D
---
[[Youtube]]

# [freeCodeCamp.org - Project-Based Augmented Reality Course with Unity Engine and AR Foundation](https://www.youtube.com/watch?v=FJAO6jDYljs)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/FJAO6jDYljs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
