---
id: 01HE6QZBG58TSA7CW0E1A99C88
---
[[Youtube]]

# [Matt MirrorFish - Procedural Generation For Beginners Series](https://youtube.com/playlist?list=PLuldlT8dkudoNONqbt8GDmMkoFbXfsv9m&si=tp5iaUXTTxU6gY6f)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=tp5iaUXTTxU6gY6f&amp;list=PLuldlT8dkudoNONqbt8GDmMkoFbXfsv9m" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Procedural Generation For Beginners: Pick a Random Item from an Array
2. Procedural Generation For Beginners: Randomize Object Placement
3. Procedural Generation For Beginners: Randomize Rotation
4. Procedural Spawning With Raycasts [unity tutorial c# scripting for beginners]
5. Procedural Generation Basics: Prevent Overlap Spawns With Boxcasts In C# [Unity Tutorial]
6. Procedural Generation Basics: Spawn A Grid In C# [Unity Tutorial]
7. Procedural Generation Basics: Position Variation [Unity3D C# Tutorial]
8. Setting A Random Seed In Unity3d : Procedural Generation (C# Game Development Programming Tutorial)
9. Unity Procedural Forest: Procedural Generation Basics (C# Programming Tutorial)
10. How To Combine Meshes: Unity Procedural Generation Optimization Tutorial In c#
11. Random Colors And Materials In Unity (Procedural Generation Basics Tutorial)
12. Generating Color Palettes With ScriptableObjects (Unity Tutorial)
13. Procedural Generation For Scene Colors (Tutorial)
