---
id: 01HAWPVRQ43PHE3SFZ9FC3F1X5
---
[[Youtube]]

# [Unity Soccer Game](https://www.youtube.com/playlist?list=PLwZ1kAmPIl5vmDziIU1wWGW1lRT7R8C4v)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PLwZ1kAmPIl5vmDziIU1wWGW1lRT7R8C4v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
