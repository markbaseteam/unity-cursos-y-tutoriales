---
id: 01HE6NTZ654EK890DES7QBCEWZ
---
[[Youtube]]

# [Alexander Zotov - How To Change Color Of 3D Object In Unity Game | Change Material Color Pressing UI Button Script](https://www.youtube.com/watch?v=vhZtjL4Buik)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/vhZtjL4Buik" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
