---
id: 01HF9GRMXJDKZQJ06BNX7CZRPY
---
[[Youtube]]

# [SocketWeaver - Unity Multiplayer Turn-based Card Game](https://youtube.com/playlist?list=PLciOnwoWoI0tMJMhSyGvGAutJy-OSDYH4&si=JJMmeGaPzzizkNcc)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=JJMmeGaPzzizkNcc&amp;list=PLciOnwoWoI0tMJMhSyGvGAutJy-OSDYH4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Introduction
2. Lobby and Matchmaking
3. Online Game Scene & Server Connection
4. Shuffle and Deal Cards
5. Turn Rotation and Card Selection
6. Completing the Online Gameplay
7. Encrypting the Game Data
8. Restore the Game State
