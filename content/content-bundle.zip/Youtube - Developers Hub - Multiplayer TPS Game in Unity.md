---
id: 01HEZTW4VNXT7ADP8RMHYA53S2
---
[[Youtube]]

# [Developers Hub - Creating a Multiplayer TPS Game in Unity](https://youtube.com/playlist?list=PLfLOlXy59QoqaRLD_eSSCb8tSiloOnpt4&si=L9DF-iSben4AaNWz)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=L9DF-iSben4AaNWz&amp;list=PLfLOlXy59QoqaRLD_eSSCb8tSiloOnpt4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
