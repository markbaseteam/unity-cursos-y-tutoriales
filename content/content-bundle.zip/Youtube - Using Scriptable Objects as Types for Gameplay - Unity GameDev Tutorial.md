---
id: 01HEBERMMR2EWDQ9QJGCTK5FC0
---
[[Youtube]]

# [Chris' Tutorials - Using Scriptable Objects as Types for Gameplay - Unity GameDev Tutorial](https://www.youtube.com/watch?v=szTPWbVh2YE)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/szTPWbVh2YE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
