---
id: 01HEBXK530ZG7CNZ0E0MXPEMTH
---
[[Youtube]]

# [Press Start - Enemies Series](https://youtube.com/playlist?list=PLcRqUlHX9rGL9RE9GqEeXp4n-ZnwIl8Oh&si=XeRQXglX3wAAiAVt)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=XeRQXglX3wAAiAVt&amp;list=PLcRqUlHX9rGL9RE9GqEeXp4n-ZnwIl8Oh" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Unity - Point and Shoot Tutorial
2. Mobile Joystick Movement + Shoot in Unity
3. Unity - Shooting Enemies with Projectiles
4. Spawning Objects in Unity [Using Instantiate]
5. Unity - Enemy Follows Player [Beginner Tutorial]
