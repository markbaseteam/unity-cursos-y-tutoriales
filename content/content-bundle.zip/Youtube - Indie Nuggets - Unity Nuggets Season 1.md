---
id: 01HE51G5YWCZJWYPQPKX0DFXKN
---
[[Youtube]]

# [Indie Nuggets - Unity Nuggets Season 1](https://youtube.com/playlist?list=PL6u6sBoUcsZUEyqlMBxmKgN13ct7JRxoH&si=gnlcoo617cjP3bET)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=gnlcoo617cjP3bET&amp;list=PL6u6sBoUcsZUEyqlMBxmKgN13ct7JRxoH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. How to do a Floating / Popup Text with Unity
2. Unity Nuggets: How to "Look At" Mouse in 2D Game
3. Wavy Text Effect using Sequential Animation with Unity
4. Simple 2D Drop Shadows in Unity using Unlit Shader
5. Unity Nuggets: How to Add Target Indicator Arrow in 2D Game
6. Drop Loot Auto Flyback to Player with Unity
7. Unity Nuggets: How to do "Hit Pause" or "Screen Freeze" in games
8. Atomic Components: Camera BG Color Cycler for Unity
9. Two Simple Ways to Add Muzzle Flash in 2D Guns with Unity
10. How to make Objects or Text Wobble and Float in 2D Game
11. Atomic Components: Creating a Reusable Timer for Unity
