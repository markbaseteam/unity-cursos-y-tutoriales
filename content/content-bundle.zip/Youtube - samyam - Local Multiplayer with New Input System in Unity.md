---
id: 01HED0Q76C776A2RQSNEVNM7KS
---
[[Youtube]]

# [samyam - Local Multiplayer with New Input System in Unity](https://youtube.com/playlist?list=PLKUARkaoYQT1H1jOpLmuowo1d03sGrf3T&si=xfpkk69foBnlAUWx)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=xfpkk69foBnlAUWx&amp;list=PLKUARkaoYQT1H1jOpLmuowo1d03sGrf3T" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## CONTENIDOS
