---
id: 01HE4MA47ZEW0R3ZS82737JFF3
---
[[Youtube]]

# [Sweden Game Arena - SGC21- Oskar Stålberg - Beyond Townscapers](https://www.youtube.com/watch?v=Uxeo9c-PX-w)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/Uxeo9c-PX-w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
