---
id: 01HE7M7GHHZ7961GS9CJYCSEYR
---
[[Youtube]]

# [Berkay Taşçı - Unity 2D Biomes: Voronoi Noise + Perlin Noise](https://www.youtube.com/watch?v=iGr_NXnKxgk)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/iGr_NXnKxgk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


