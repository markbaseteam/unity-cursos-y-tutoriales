---
id: 01HE7FTKB56ZA08PWGWZYJ9B06
---
[[Youtube]]

# [Peer Play - Procedural Phyllotaxis](https://youtube.com/playlist?list=PL3POsQzaCw53Y_gDwFbfqQoLdi2udfWqS&si=0vfnrdkzq4DQauyy)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=0vfnrdkzq4DQauyy&amp;list=PL3POsQzaCw53Y_gDwFbfqQoLdi2udfWqS" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Procedural Phyllotaxis - Unity/C# Tutorial [Part 1 - The Formula]
2. Procedural Phyllotaxis - Unity/C# Tutorial [Part 2 - Lerping Trails]
3. Procedural Phyllotaxis - Unity/C# Tutorial [Part 3 - Trails Lerping on Audio]
4. Procedural Phyllotaxis - Unity/C# Tutorial [Part 4 - Scale on Audio]
5. Procedural Phyllotaxis - Unity/C# Tutorial [Part 5 - 3D Tunnel]
6. Vogel - Music Visualization [UnityC#]
7. Phýllon - Music Visualization [UnityC#]
8. Phyllotaxis Trail Pro [Patreon Exclusive]
