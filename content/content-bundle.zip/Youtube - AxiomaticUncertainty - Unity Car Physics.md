---
id: 01HE4GC5XSNSNZQ4Z9XR1AHB9V
---
[[Youtube]]

# [AxiomaticUncertainty - Unity Car Physics](https://youtube.com/playlist?list=PLAQtztBIl8pjcAFh-s-lTLVJXCv9q8cDC&si=5cpbciDR8m1mpdBa)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=5cpbciDR8m1mpdBa&amp;list=PLAQtztBIl8pjcAFh-s-lTLVJXCv9q8cDC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS 
