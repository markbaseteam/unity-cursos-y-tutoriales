---
id: 01HEBY32F313X868Z3W20SA9V2
---
[[Youtube]]

# [BLANKdev - Unity Tutorials](https://youtu.be/5ZBynjAsfwI?si=M2Kki1mr0o1u0Yps)

<iframe width="560" height="315" src="https://www.youtube.com/embed/5ZBynjAsfwI?si=M2Kki1mr0o1u0Yps" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
How To Draw a Line in Unity | Line Renderer Tutorial 1
How to Detect COLLISIONS on a Line Renderer in Unity
How to Draw Shapes in Unity | Line Renderer Unity Tutorial 3
How to Draw UI Lines in Unity in 5 Minutes | Line Renderer Tutorial 2
Save time in Unity with COLOR GROUPS 
Does your Jump in Unity feel terrible? Try this!
YOU are Jumping WRONG in Unity 
Randomisation in Unity in 30 Seconds! 
Why do we NEED 3D for 2D rotations? 
Save time in Unity with Blender Single Exports!
I wish I knew this sooner about lists in Unity 
