---
id: 01HEBXFQYQ3ECSHZ8WW3D4AFRX
---
[[Youtube]]

# [Press Start - Unity Movement Series](https://youtube.com/playlist?list=PLcRqUlHX9rGJxS4ptbivglKme7ysyGbUO&si=jnPHRHYD4wmM1JMd)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=jnPHRHYD4wmM1JMd&amp;list=PLcRqUlHX9rGJxS4ptbivglKme7ysyGbUO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Unity Movement [RigidBody vs Translate]
2. Mobile Joystick Movement + Shoot in Unity
3. Super Mario Maker 2 - How to Recreate the Key Door in Unity
4. Unity - Keeping The Player Within Screen Boundaries
5. Pinch to Zoom and Panning on Mobile in Unity
6. Unity - Mobile Panning with a Perspective Camera
7. Unity: Mobile Joystick Tutorial [NO PLUGINS]
8. Unity - Enemy Follows Player [Beginner Tutorial]
9. Dust Effect when Running & Jumping in Unity [Particle Effect]
