---
id: 01HDH9TYREJYNDV0P4EXCC8FC6
---
[[Youtube]]

# [Profe TIC - Curso de Unity - Juego 1](https://youtube.com/playlist?list=PLNFqyZnKIlCKaIWxkYK8CKwH7ERqsEi1d&si=LzYkZAjVUyHX_mWc)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=LzYkZAjVUyHX_mWc&amp;list=PLNFqyZnKIlCKaIWxkYK8CKwH7ERqsEi1d" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
