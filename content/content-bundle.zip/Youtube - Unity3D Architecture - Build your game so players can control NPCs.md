---
id: 01HFH8NS4VWXDM4B1AW0VQ7D8M
---
[[Youtube]]

# [Jason Weimann - Unity3D Architecture - Build your game so players can control NPCs](https://www.youtube.com/watch?v=zAKZwAdMAek&t=49s)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/zAKZwAdMAek" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
