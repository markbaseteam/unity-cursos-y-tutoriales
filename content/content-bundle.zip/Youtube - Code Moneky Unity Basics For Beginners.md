---
id: 01HB1RPT4QNJ0VJ19JS6XYDD5D
---
[[Youtube]]

# [Code Moneky Unity Basics For Beginners](https://youtube.com/playlist?list=PLzDRvYVwl53vxdAPq8OznBAdjf0eeiipT&si=ogZCeh202sEIN2DG)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=ogZCeh202sEIN2DG&amp;list=PLzDRvYVwl53vxdAPq8OznBAdjf0eeiipT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

