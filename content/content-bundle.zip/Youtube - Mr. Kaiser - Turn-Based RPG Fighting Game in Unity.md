---
id: 01HECRZXZ8EJ2SX2TV0KG1DV9K
---
[[Youtube]]

# [Mr. Kaiser - Turn-Based RPG Fighting Game in Unity](https://youtube.com/playlist?list=PLbsvRhEyGkKcF6TDBhEqYA6cCOjFpV0YM&si=4WmBKJflr1irr1RY)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=4WmBKJflr1irr1RY&amp;list=PLbsvRhEyGkKcF6TDBhEqYA6cCOjFpV0YM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
