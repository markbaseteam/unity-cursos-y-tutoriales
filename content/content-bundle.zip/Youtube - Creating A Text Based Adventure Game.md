---
id: 01HAWPVRS8KMEDZB90H5S70F9C
---
[[Youtube]]

# [Creating A Text Based Adventure Game](https://www.youtube.com/playlist?list=PLX2vGYjWbI0RfcpqpKlmLEy7NteIog8g4)

<iframe width="560" height="315" src="https://www.youtube.com/embed/playlist?list=PLX2vGYjWbI0RfcpqpKlmLEy7NteIog8g4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
