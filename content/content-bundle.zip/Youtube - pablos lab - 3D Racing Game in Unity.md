---
id: 01HE6PYK7YH3JV9DBNC0915DZC
---
[[Youtube]]

# [pablos lab - 3D Racing Game in Unity](https://youtube.com/playlist?list=PLhWBaV_gmpGXxscZr8PIcreyYkw8VlnKn&si=9HnuSCIx5vudarok)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=9HnuSCIx5vudarok&amp;list=PLhWBaV_gmpGXxscZr8PIcreyYkw8VlnKn" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
