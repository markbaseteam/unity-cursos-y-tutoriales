---
id: 01HE3NWEKQ8417HV58T10TDMYF
---
[[Youtube]]

# [Code Monkey - Unity Shader Graph Tutorials](https://youtube.com/playlist?list=PLzDRvYVwl53tpvp6CP6e-Mrl6dmxs9uhx&si=NG7e3PDNTa6XzVvw)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=NG7e3PDNTa6XzVvw&amp;list=PLzDRvYVwl53tpvp6CP6e-Mrl6dmxs9uhx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
1. Make Awesome Effects with Shader Graph in Unity!
2. Hades: Transition Effect (Quick How It's Made | Unity Tutorial)
3. Shader Graph in Unity 2021! (changes from 2020 | URP 10)
4. Simple Wind Shader Effect in Unity!
5. Awesome Building Construction Shader Effect! (Shader Graph)
6. Sprite Outline (Animated!) - 2D Shader Graph Tutorial
7. Sprite Blur - 2D Shader Graph Tutorial
8. Pixelate Effect - Shader Graph Tutorial
9. Sprite Dissolve - 2D Shader Graph Tutorial
10. How to make Awesome Post Processing Effects!
11. Shield Force Field - Shader Graph Tutorial
12. Sprite Tint - 2D Shader Graph Tutorial
