---
id: 01HECSH05T3TWSS25B1BEJEN97
---
[[Youtube]]

# [xOctoManx - Quest System](https://youtube.com/playlist?list=PLj0TSSTwoqAy0abF90Ov3H7SDDj9jcpGD&si=zMDV6gFIasO4Cztf)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=zMDV6gFIasO4Cztf&amp;list=PLj0TSSTwoqAy0abF90Ov3H7SDDj9jcpGD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
