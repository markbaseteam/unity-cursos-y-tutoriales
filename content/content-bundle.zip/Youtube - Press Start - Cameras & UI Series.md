---
id: 01HEBXSKJMQMFTXEXM3GT15HNR
---
[[Youtube]]

# [Press Start - Cameras & UI Series](https://youtube.com/playlist?list=PLcRqUlHX9rGIaJtPy2iwtIE7FO0Cda4I3&si=v6vAbqI5JR96bC5E)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=v6vAbqI5JR96bC5E&amp;list=PLcRqUlHX9rGIaJtPy2iwtIE7FO0Cda4I3" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. 2D Perspective Effect with an Orthographic Camera (Parallax)
2. Scrolling Repeating Background in Unity
3. Swiping Pages in Unity
4. Pinch to Zoom and Panning on Mobile in Unity
5. Understanding Orthographic Size in Unity
6. Unity - Mobile Panning with a Perspective Camera
7. Working with Time in Unity
8. Unity - Creating a Level Select Screen in C#
