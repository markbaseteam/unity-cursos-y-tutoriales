---
id: 01HFQCK6ATC72ATGNNRM8V49PM
---
[[Youtube]]

# [Shrine - Unity + Mirror Networking Tutorials](https://youtube.com/playlist?list=PLXEG2omgKgCapAmGe20XBgd87rmxFdKhK&si=x3ssooJa64BGZnpK)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=x3ssooJa64BGZnpK&amp;list=PLXEG2omgKgCapAmGe20XBgd87rmxFdKhK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## [Github Repo Files](https://github.com/ShrineGames/UnityMirrorTutorials)
## CONTENIDOS
