---
id: 01HDPV6ATPXYQAARKETHW4S61G
---
[[Youtube]]

# [about game making - Unity Tutorials](https://youtube.com/playlist?list=PLD70Y1kRAQXJryvM2Vs9MaON90jfJJIA2&si=7ylyS1Yy1EsQMcp6)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=7ylyS1Yy1EsQMcp6&amp;list=PLD70Y1kRAQXJryvM2Vs9MaON90jfJJIA2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- Unity UI : Canvas Scaler
- Unity UI : Adjusting image corners and Dealing with Rectangle Image
- Unity : Sprite animation on 3D Objects
- Unity : Standard Shader
- Unity : Camera and Tips
- Unity : Optimizing Audio Source
- Unity : Why the resolution of images should be a power of two.
- Unity : 3D UI in World Space
- Unity : Post Process in Built-in Render Pipeline
- Unity : Light Probe Group
- Unity Optimization : reducing 3D objects' draw calls
- Unity Character Animation Setup : Transition and Blending
- Unity : A simple way to make your game background look pretty
- Unity UI : How to set UI for various screen ratios
