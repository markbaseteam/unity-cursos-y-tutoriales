---
id: 01HEBDW2EKDZQ0CH9GTBR2X7Y0
---
[[Youtube]]

# [Lawless Games - Scriptable Object Event Systems In Unity 2022](https://www.youtube.com/watch?v=uXKX5O8wiac)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/uXKX5O8wiac" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
