---
id: 01HEBZN8BFA0JFYBZ8G8VTZ38X
---
[[Youtube]]

# [OttoBotCode - Programming a Tetris Game in C#](https://youtube.com/playlist?list=PLFk1_lkqT8MZIdAd8b-rBm1HO8-bM0d05&si=1pmnnvoNOCkstTRU)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=1pmnnvoNOCkstTRU&amp;list=PLFk1_lkqT8MZIdAd8b-rBm1HO8-bM0d05" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Programming a Tetris Game in C# - Full Guide
2. Programming a Tic-Tac-Toe Game in C# - Full Guide
3. Programming a Snake Game in C# - Full Guide
