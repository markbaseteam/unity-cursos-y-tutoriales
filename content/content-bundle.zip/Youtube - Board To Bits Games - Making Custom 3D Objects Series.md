---
id: 01HDN82YGWWQ88RHX7HKKHBN8Y
---
[[Youtube]]

# [Board To Bits Games - Making Custom 3D Objects Series](https://youtube.com/playlist?list=PL5KbKbJ6Gf9-d303Lk8TGKCW-t5JsBdtB&si=YEq1hnl6o7vobsF5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=YEq1hnl6o7vobsF5&amp;list=PL5KbKbJ6Gf9-d303Lk8TGKCW-t5JsBdtB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 


## CONTENIDOS 
1. Mesh Basics
2. Let's Make a Triangle!
3. Let's Make a Quad
4. All About Vertices
5. Board To Bits Games
6. Procedural Grid (Setup)
7. Procedural Grid (Discrete Cells)
8. Procedural Grid (Contiguous Cells)
9. Cube Basics
10. Cube Scale & Position
11. BVoxels (The Easy Way)
12. Voxels (The Right Way, Part 1)
13. Voxels (The Right Way, Part 2)
