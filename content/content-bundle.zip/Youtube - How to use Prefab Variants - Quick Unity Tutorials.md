---
id: 01HE5162EXEFWNHC4JXRHWD9B3
---
[[Youtube]]

# [toficofi - How to use Prefab Variants - Quick Unity Tutorials](https://www.youtube.com/watch?v=pv30sE_Vsis)

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/pv30sE_Vsis" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## CONTENIDOS
