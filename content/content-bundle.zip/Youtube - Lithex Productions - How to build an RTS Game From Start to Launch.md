---
id: 01HDTND7Z07D520N6806QMNDXW
---
[[Youtube]]

# [Lithex Productions - How to build an RTS Game From Start to Launch](https://youtube.com/playlist?list=PLQPhaRCbpx5U0kcamApy727XC0v1bF0PK&si=WMBZFUziLgPjNOiJ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=WMBZFUziLgPjNOiJ&amp;list=PLQPhaRCbpx5U0kcamApy727XC0v1bF0PK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
- BUILDING A GAME AT THE VIEWERS' MERCY in UNITY (How to / Tutorial Announcement)
- How to BUILD and LAUNCH an RTS Game in UNITY - ep1. NameSpaces & Scriptable Objects
- How to BUILD and LAUNCH an RTS Game in UNITY - ep2. RTS style UNIT SELECTION ft. Singletons
- How to BUILD and LAUNCH an RTS Game in UNITY - ep2.5 RTS style DRAG SELECTION ft Singletons & OnGUI
- How to BUILD and LAUNCH an RTS Game in UNITY - ep3. Moving RTS Units ft NavMeshAgent
- How to BUILD and LAUNCH an RTS Game in UNITY - ep4 Customizing Editor & Units ft Scriptable Objects
- How to BUILD and LAUNCH an RTS Game in UNITY - ep5. Enemy AI (Part1: Aggro) ft NavMeshAgent
- How to BUILD and LAUNCH an RTS Game in UNITY - ep6. Enemy AI Part 2: COMBAT
- How to BUILD and LAUNCH an RTS Game in UNITY - ep7. Refactoring your Code ft. Health Bars
- How to BUILD and LAUNCH an RTS Game in UNITY - ep8. Adding RTS Buildings in Unity
- How to BUILD and LAUNCH an RTS Game in UNITY - ep9. Spawning Units ft. Inheritance (Part 1)
- How to BUILD and LAUNCH an RTS Game in UNITY - ep9.5 SPAWNING RTS Units (Part 2) Ft UI HUD Creation
- How to BUILD and LAUNCH an RTS Game in UNITY - ep10 SPAWNING RTS Units (Part 3) Ft Coroutines
- How to BUILD and LAUNCH an RTS Game in UNITY - ep11. SET SPAWN LOCATION - ft nothing special
- It Took Me 4 YEARS To Solve This Mystery!!
- THE PINK WARD SHACO MOVIE! (SHOWING YOU HOW TO CARRY WITH AP SHACO)
