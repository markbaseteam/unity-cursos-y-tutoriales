---
id: 01HE7GFTB3M7G5W41HR4B0Z09M
---
[[Youtube]]

# [Peer Play - Underwater World Shaders](https://youtube.com/playlist?list=PL3POsQzaCw51Cvlnery3cIabH-YqQtMpa&si=7XxJ6mIDNBZ3z3C5)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=7XxJ6mIDNBZ3z3C5&amp;list=PL3POsQzaCw51Cvlnery3cIabH-YqQtMpa" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Underwater World Shaders - Unity CG/C# Tutorial [Part 0 - Introduction]
2. Underwater World Shaders - Unity CG/C# Tutorial [Part 1 - Noise Theory]
3. Underwater World Shaders - Unity CG/C# Tutorial [Part 2 - Noise Ground Shader]
4. Underwater World Shaders - Unity CG/C# Tutorial [Part 3 - Recalculating Vertex Normals]
5. Underwater World Shaders - Unity CG/C# Tutorial [Part 4 - Directional Noise Image Effect]
6. Underwater World Shaders - Unity CG/C# Tutorial [Part 5 - Camera Depth Fog]
7. Underwater World Shaders - Unity CG/C# Tutorial [Part 5 - Camera Depth Fog]
8. Underwater World Shaders - Unity CG/C# Tutorial [Part 6 - Depth Based Underwater Effect]
9. Raymarching Shader - Unity CG/C# Tutorial _Chapter[1] = "Shader Theory"; //PeerPlay
