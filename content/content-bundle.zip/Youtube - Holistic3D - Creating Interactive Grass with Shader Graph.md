---
id: 01HDH8GZ8PB1TNVBQ91YHVB7Y3
---
[[Youtube]]

# [Holistic3D - Creating Interactive Grass with Shader Graph](https://youtube.com/playlist?list=PLi-ukGVOag_1TBSekcp_y8TKkROFpgd-X&si=Vfw0khTRKY6b5uZH)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=Vfw0khTRKY6b5uZH&amp;list=PLi-ukGVOag_1TBSekcp_y8TKkROFpgd-X" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
