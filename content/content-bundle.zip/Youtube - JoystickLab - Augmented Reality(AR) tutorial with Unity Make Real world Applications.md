---
id: 01HECB022VB2SNNCPGJ3EEW3PW
---
[[Youtube]]

# [JoystickLab - Augmented Reality(AR) tutorial with Unity Make Real world Applications](https://youtube.com/playlist?list=PLb1h4A0yB978SQuAeBsxup--7ITPCashH&si=2TDWVSxNYv-fHM54)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=2TDWVSxNYv-fHM54&amp;list=PLb1h4A0yB978SQuAeBsxup--7ITPCashH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. Make a tile e-Commerce App - Part 1
2. Make a tile e-Commerce App - Part 2 (Custom plane texture)
3. Make a tile e-Commerce App - Part 3
4. Make an AR app like IKEA Place ** PART 1 -Placing an AR Object
5. Make an AR app like IKEA Place ** PART 2 -Select object to spawn
6. Make an AR app like IKEA Place **PART 3 Block AR input from UI touch
7. Make an AR app like IKEA Place **PART4 Crosshair Interaction in AR
8. Make an AR app like IKEA Place **PART5 Advanced UI Scrolling
9. Make an AR app like IKEA Place **PART6 Finalize the UI Scrolling
10. Make an AR app like IKEA Place **PART7 Handle AR objects dynamically with scriptable objects.
11. How to Create an IKEA AR clone with Unity - Loading assets using Addressables.(Part 8)
12. How to Create an IKEA AR clone with Unity - Use Addressables with Google Cloud (Part 9)
13. How to Create an IKEA AR clone with Unity - Migrate Project to Unity 2020- Part 10
14. How to Create an IKEA AR clone with Unity - Placing Object using XR Interaction Toolkit (Part 11)
15. How to make IKEA AR app with Unity -Object Manipulation (Select, Rotate, Translate, Scale) - Part 12
