---
id: 01HEA1FV9TKWM5E5RY57PG3ZAQ
---
[[Youtube]]

# [Jimmy Vegas - HOW TO MAKE A GAME - LEARN GAME DEVELOPMENT](https://youtube.com/playlist?list=PLZ1b66Z1KFKiAq5OOtLIgXN2LK12xKxHK&si=vJf33ghkJPSgMvPJ)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=vJf33ghkJPSgMvPJ&amp;list=PLZ1b66Z1KFKiAq5OOtLIgXN2LK12xKxHK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
1. GETTING STARTED (E01/12)
2. BASIC ENGINE LAYOUT (E02/12)
3. VERSIONS & PLATFORMS (E03/12)
4. GAME OBJECTS (E04/12)
5. CAMERAS (E05/12)
6. C# PROGRAMMING (E06/12)
7. ASSETS (E07/12)
8. SIMPLE PHYSICS (E08/12)
9. UI OVERLAY (E09/12)
10. SCENES (E10/12)
11. ANIMATION (E11/12)
12. WHERE TO LEARN MORE (E12/12)
