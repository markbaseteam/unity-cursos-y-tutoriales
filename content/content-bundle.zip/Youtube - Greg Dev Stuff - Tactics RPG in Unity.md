---
id: 01HE0TTDPE1MX5NJJ259KBWBJY
---
[[Youtube]]

# [Greg Dev Stuff - Tactics RPG in Unity](https://youtube.com/playlist?list=PL0GUZtUkX6t4JrdjOoAF2ayH-ksVtgpqy&si=Wyh-lbp8WethDozP)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=OlYfBSjYEj2c_N-U&amp;list=PL0GUZtUkX6t4JrdjOoAF2ayH-ksVtgpqy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 
## CONTENIDOS
