---
id: 01HECDGNSTXGAEX3PWGKKV0N2Q
---
[[Youtube]]

# [Ludic Worlds - Unity's XR Interaction Toolkit](https://youtube.com/playlist?list=PLWcLPdrF6kOmwlF8mOx8bY6HfYnV3NPqq&si=o6xnrHIvJOLu32p9)

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=o6xnrHIvJOLu32p9&amp;list=PLWcLPdrF6kOmwlF8mOx8bY6HfYnV3NPqq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> 

## CONTENIDOS
Part 1: Import & Setup
Part 2: XR Rig Setup
Part 3: Action-based Input
Part 4: Grabbing Objects
Part 5: XR Direct Interactor
Part 6: XR Grab Interactable
XR Interaction Toolkit Version 2.3 Released (Unity)
